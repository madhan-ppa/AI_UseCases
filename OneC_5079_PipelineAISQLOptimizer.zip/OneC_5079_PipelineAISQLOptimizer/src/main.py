"""
AI SQL Optimizer — Main Pipeline (Daily Cron Entry Point)

Designed to run as a GKE CronJob (e.g. daily at 2 AM).

Pipeline stages:
  Stage 1: Fetch slow stored procedures from AppDynamics for every active app
           and upsert them directly into ado_defect_tracker (no snapshot table).
  Stage 2: Login to AppD ONCE, then fetch + analyze execution plans for every
           pending SP via pure REST APIs (no UI clicks) — in memory only, no
           files written to disk.
  Stage 3: Decision Gate — for each SP that passes the 8-state gate:
              - Resolve org-specific GitHub token + extract SP code & schemas
              - Run LangChain multi-task optimization
              - Create ADO Bug under "AISQLOptimization_Suggestions" user story
              - Update defect_id + defect_status in ado_defect_tracker

Resilience guarantees:
  - Each stage is wrapped in try/except — one failure does not abort the others.
  - Within Stages 2 & 3, per-SP failures are isolated; the loop continues with
    the next SP and marks the failed one with defect_status='Failed' so it is
    automatically retried on the next pipeline run.

Credentials:
  - Loaded from `.env` (local dev) — never hardcoded.
  - In production: sourced from Kubernetes Secrets via envFrom in the CronJob.
"""

import os
import sys
import traceback

from optimizer.config import get_config
get_config()  # Populate os.environ from .env BEFORE other modules are imported.
              # Several modules (github_python_navigator, fetch_slow_sps, appd_downloader)
              # evaluate _GITHUB_SSL_VERIFY / _APPD_SSL_VERIFY at module-import time via
              # os.getenv(), so .env must be loaded first or those vars fall back to 'true'.
from optimizer.decision.decision_gate import DecisionGate
from optimizer.models import init_db
from optimizer.scheduled_monitor.appd_execution_plan_downloader import AppDExecutionPlanDownloader
from optimizer.scheduled_monitor.fetch_slow_sps_for_active_apps import ActiveAppSPFetcher
from optimizer.utils.audit_logger import log_audit, log_pipeline_error
from optimizer.utils.data_retention import purge_expired_error_logs
from optimizer.ado_integration.ado_defect_tracker import main as run_ado_defect_tracker

def run_pre_pipeline_defect_tracker():
    """Runs ADO defect tracker before main pipeline."""
    print("\n" + "=" * 100)
    print("RUNNING: ADO Defect Tracker (pre-pipeline)")
    print("=" * 100)
    try:
        run_ado_defect_tracker()
    except Exception as e:
        # NOTE: Per-SP errors are already logged inside ado_defect_tracker.py.
        # This catches only CATASTROPHIC failures (DB connection, import errors, etc.)
        error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
        print(f"[PRE-PIPELINE ERROR] ADO Defect Tracker failed: {e}")
        traceback.print_exc()
        log_pipeline_error(
            error_type='STAGE_ERROR',
            error=error_text,
            sp_name='(main: pre-pipeline defect_tracker CATASTROPHIC)',
        )
    print("=" * 100 + "\n")

def _run_stage(name, func, *args, **kwargs):
    """
    Run a stage with isolation: any exception is logged but does not abort the
    rest of the pipeline. Returns the function's result, or None on failure.
    
    NOTE: Per-SP/per-app errors are already logged inside worker modules.
    This catches only STAGE-LEVEL catastrophic failures.
    """
    print("\n" + "=" * 100)
    print(f"STAGE: {name}")
    print("=" * 100)
    try:
        return func(*args, **kwargs)
    except Exception as e:
        error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
        print(f"\n[Stage Error] {name} raised {type(e).__name__}: {e}")
        traceback.print_exc()
        log_pipeline_error(
            error_type='STAGE_ERROR',
            error=error_text,
            sp_name=f'(main: {name} CATASTROPHIC)',
        )
        return None


def stage_1_fetch_and_sync():
    """Fetch slow SPs from AppDynamics and upsert directly into ado_defect_tracker."""
    fetcher = ActiveAppSPFetcher()
    inserted, updated = fetcher.run()
    print(f"   Sync complete: {inserted} new SPs, {updated} updated SPs")


def stage_2_download_and_analyze_plans(config):
    """
    Pure-API batch download + analysis for every pending SP.
    Returns {sp_name: {'analysis_result': ...}} — kept in memory, nothing written to disk.
    Stage 3 consumes this dict so execution plans never touch the filesystem.
    """
    if config.APPD_SKIP_PLAN_FETCH:
        print("   APPD_SKIP_PLAN_FETCH=true — skipping plan download.")
        print("   Stage 3 will run on SP code + schemas only.")
        log_audit(
            "PLAN_SKIPPED",
            sp_name="(stage-level)",
            message="Stage 2 skipped via APPD_SKIP_PLAN_FETCH=true; pipeline will optimize using SP code + schemas only.",
        )
        return {}
    downloader = AppDExecutionPlanDownloader()
    return downloader.download_all_execution_plans()


def stage_3_optimize_and_create_ado(config, plan_results=None):
    """Decision gate -> GitHub -> LangChain -> ADO Bug per eligible SP."""
    agent = DecisionGate(
        github_token=config.GITHUB_TOKEN,
        ado_org_url=config.ADO_ORG_URL,
        ado_project=config.ADO_PROJECT,
        ado_pat_token=config.ADO_PAT_TOKEN,
        is_test_ado=config.IS_TEST_ADO,
        ado_base_url=config.ADO_BASE_URL,
        env_region=config.ENV_REGION,
    )
    agent.run(plan_results=plan_results or {})


def main():
    """Pipeline entry point. Returns exit code 0 on completion (even with per-SP failures)."""
    try:
        config = get_config()
        init_db()
        purge_expired_error_logs()

        print("\n" + "=" * 100)
        print("AI SQL OPTIMIZER — DAILY PIPELINE")
        print("=" * 100)
        print(f"   LLM Provider : {config.LLM_PROVIDER}")
        print(f"   AppD URL     : {config.APPD_CONTROLLER_URL}")
        print(f"   ADO Project  : {config.ADO_PROJECT}")
        print(f"   Headless     : {config.APPD_HEADLESS}")
        print("=" * 100)

        _run_stage("1/3 — Fetch slow SPs from AppDynamics + sync to defect tracker", stage_1_fetch_and_sync)
        plan_results = _run_stage("2/3 — Download + analyze execution plans (pure API, in-memory)",
                                  stage_2_download_and_analyze_plans, config) or {}
        _run_stage("3/3 — Optimize via LangChain + create ADO bugs",
                   stage_3_optimize_and_create_ado, config, plan_results)

        print("\n" + "=" * 100)
        print("PIPELINE COMPLETE")
        print("=" * 100)
        print("   - Slow SPs upserted directly into ado_defect_tracker")
        print("   - Execution plans fetched + analyzed in memory for eligible SPs")
        print("   - ADO bugs created under 'AISQLOptimization_Suggestions' user story")
        print("   - defect_id + defect_status updated in DB")
        print("   - Failed SPs (if any) will retry automatically on next run")
        print("=" * 100)
        return 0
    
    except Exception as e:
        error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
        print("\n" + "=" * 100)
        print(f"CATASTROPHIC PIPELINE FAILURE: {type(e).__name__}: {e}")
        print("=" * 100)
        traceback.print_exc()
        log_pipeline_error(
            error_type='STAGE_ERROR',
            error=error_text,
            sp_name='(main: catastrophic pipeline failure)',
        )
        print("=" * 100)
        return 1  # Non-zero exit code for catastrophic failure


if __name__ == "__main__":
    run_pre_pipeline_defect_tracker()
    sys.exit(main())
