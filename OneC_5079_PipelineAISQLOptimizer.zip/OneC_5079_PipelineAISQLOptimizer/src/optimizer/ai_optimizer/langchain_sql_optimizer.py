"""LangChain SQL Optimizer - Sequential Chain System
Orchestrates 5 sequential LLM calls for comprehensive SQL optimization

Steps:
1. SQL Performance Analyst - Analyzes execution plans
2. Database Architect - Reviews schema and suggests indexes
3. SQL Query Optimizer - Rewrites SQL for better performance
4. Code Reviewer - Validates functional equivalence
5. Documentation Specialist - Creates comprehensive reports

Token Optimization Strategy:
- SP code is passed ONLY to Step 1 (Performance) and Step 3 (Optimizer)
- Step 2 (Architect) gets SP code via context from Step 1 (when no execution plan)
- Step 4 (Reviewer) gets original SP via context from Step 3 (which received it)
- Step 5 (Documentation) gets all outputs via context — never receives raw SP code
- After all steps run, the optimized SP from Step 3 is stitched into the final report
  to guarantee zero truncation of the SQL code block"""

import os
import logging
import re
import sys
import traceback
from typing import Dict, Any, Union
from datetime import datetime
from zoneinfo import ZoneInfo

_IST = ZoneInfo("Asia/Kolkata")

from langchain_core.messages import SystemMessage, HumanMessage

for _noisy_logger in (
    "langchain", "langchain_core", "langchain_openai",
    "langchain_anthropic", "openai", "httpx", "httpcore",
):
    logging.getLogger(_noisy_logger).setLevel(logging.WARNING)

try:
    from ..config import get_config
    from ..utils.audit_logger import log_audit, log_pipeline_error
except ImportError:
    _project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    if _project_root not in sys.path:
        sys.path.insert(0, _project_root)
    os.chdir(_project_root)
    from optimizer.config import get_config
    from optimizer.utils.audit_logger import log_audit, log_pipeline_error

def _estimate_tokens(text: str) -> int:
    """Rough token estimate: ~4 chars per token for English/SQL mixed content"""
    return len(text) // 4 if text else 0

class LangChainSQLOptimizer:
    """
    Sequential LLM-based SQL optimization system using LangChain.
    Supports Azure OpenAI and Vertex AI (Claude via Workload Identity).
    LLM provider is determined by LLM_PROVIDER in .env / ConfigMap.
    """

    def __init__(self):
        config = get_config()
        self.llm_provider = config.LLM_PROVIDER

        print(f"\n{'='*100}")
        print(f"LANGCHAIN LLM CONFIGURATION")
        print(f"{'='*100}")

        if self.llm_provider == 'azure_openai':
            self._init_azure_openai(config)
        elif self.llm_provider == 'vertex_ai':
            self._init_vertex_ai(config)
        else:
            raise ValueError(
                f"Unsupported LLM_PROVIDER='{self.llm_provider}'. "
                "Valid values: 'azure_openai', 'vertex_ai'."
            )

    def _init_azure_openai(self, config):
        from langchain_openai import AzureChatOpenAI

        api_key = config.AZURE_OPENAI_API_KEY
        endpoint = config.AZURE_OPENAI_ENDPOINT
        deployment = config.AZURE_OPENAI_DEPLOYMENT
        api_version = config.AZURE_OPENAI_API_VERSION

        print(f"Provider: Azure OpenAI")
        print(f"Endpoint: {endpoint}")
        print(f"Deployment: {deployment}")
        print(f"API Version: {api_version}")
        print(f"{'='*100}\n")

        self.llm = AzureChatOpenAI(
            azure_deployment=deployment,
            azure_endpoint=endpoint,
            api_key=api_key,
            api_version=api_version,
            max_tokens=32768,
            max_retries=5,  # Increased retries for large SPs
            request_timeout=600,  # Increased to 10 minutes for very large SPs (48K+ chars)
        )

    def _init_vertex_ai(self, config):
        """
        Initialize Claude on Vertex AI using the official LangChain
        ChatAnthropicVertex integration.

        This replaces the older:

            ChatAnthropic(client=AnthropicVertex(...))

        pattern which causes:

            TypeError:
            Messages.create() got an unexpected keyword argument 'client'

        on newer anthropic/langchain versions.
        """

        from langchain_google_vertexai.model_garden import ChatAnthropicVertex

        vertex_project = config.VERTEX_PROJECT_ID
        vertex_location = config.VERTEX_LOCATION
        claude_model = config.CLAUDE_MODEL
        max_tokens = config.CLAUDE_MAX_TOKENS
        temperature = config.CLAUDE_TEMPERATURE

        print(f"Provider: Vertex AI (Claude)")
        print(f"Model: {claude_model}")
        print(f"Vertex Project: {vertex_project}")
        print(f"Vertex Location: {vertex_location}")
        print(f"Max Tokens: {max_tokens}")
        print(f"Temperature: {temperature}")
        print(f"{'=' * 100}\n")

        self.llm = ChatAnthropicVertex(
            model_name=claude_model,
            project=vertex_project,
            location=vertex_location,
            max_tokens=max_tokens,
            temperature=temperature,
            max_retries=5,
        )

      

    def _invoke_llm(self, system_prompt: str, human_prompt: str, step_name: str = "") -> str:
        """Send system + human message pair to the LLM and return text output with timeout retry logic."""
        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=human_prompt),
        ]

        # For very large inputs, retry with extended timeout on first failure
        max_attempts = int(os.getenv('LLM_MAX_RETRY_ATTEMPTS', '2'))
        attempt = 0

        while attempt < max_attempts:
            attempt += 1
            try:
                response = self.llm.invoke(messages)
                return response.content or ""
            except Exception as e:
                error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"

                # Check if this is a timeout error
                is_timeout = any(term in str(e).lower() for term in ['timeout', 'timed out', 'time out'])
                
                if is_timeout and attempt < max_attempts:
                    print(f"   [LLM TIMEOUT] {step_name}: Request timed out, retrying with extended timeout (attempt {attempt}/{max_attempts})...")
                    continue  # Retry once for timeout errors
                
                print(f"   [LLM ERROR] {step_name}: {e}")

                log_pipeline_error(
                    error_type='LLM_API_ERROR',
                    error=error_text,
                    sp_name=step_name,
                )
                raise
 
    def optimize_sql(self,
                     sp_name: str,
                     sp_code: str,
                     table_schemas: Union[Dict[str, str], str],
                     execution_plan_analysis: str) -> Dict[str, Any]:

        """
        Optimize SQL using sequential LLM calls.
        Uses token-efficient prompt design and post-processing stitch to guarantee
        complete output even with LLM output token limits.
        """

        print(f"\n{'='*100}")
        print(f"LANGCHAIN MULTI-STEP SQL OPTIMIZATION")
        print(f"{'='*100}")
 
        has_plan = (execution_plan_analysis and execution_plan_analysis.strip()
                    and execution_plan_analysis.strip().lower() != "no execution plan available")
 
        sp_tokens = _estimate_tokens(sp_code)
        schemas_text = self._format_table_schemas(table_schemas)
        schema_tokens = _estimate_tokens(schemas_text)
        plan_tokens = _estimate_tokens(execution_plan_analysis) if has_plan else 0

        total_input_tokens = sp_tokens + schema_tokens + plan_tokens
 
        print(f"SP Name: {sp_name}")

        print(f"SP Code: ~{sp_tokens:,} tokens ({len(sp_code):,} chars)")

        print(f"Table Schemas: ~{schema_tokens:,} tokens")

        print(f"Execution Plan: {'~' + str(plan_tokens) + ' tokens' if has_plan else 'Not available (code-analysis mode)'}")

        print(f"Total Input Estimate: ~{total_input_tokens:,} tokens")
        print(f"LLM Provider: {self.llm_provider.upper()}")
        print(f"Max Output Tokens: {'32,768 (GPT-4.1)' if self.llm_provider == 'azure_openai' else '128,000 (Claude)'}")
        print(f"Tasks: 5 (Performance Analyst, Database Architect, Query Optimizer, Code Reviewer, Documentation)")
        print(f"{'='*100}\n")

        print("Starting multi-task optimization workflow...")

        # Task 1: Performance Analysis
        perf_prompt = self._build_performance_prompt(sp_name, sp_code, execution_plan_analysis, has_plan)
        perf_result = self._invoke_llm(

            "You are an expert SQL Performance Analyst with 15+ years of experience "
            "in analyzing query execution plans. You specialize in identifying performance bottlenecks, "
            "understanding cost metrics, and pinpointing inefficient operations like table scans, "
            "index seeks with high costs, and expensive sorting operations. You can read XML execution "
            "plans and translate technical metrics into actionable insights.\n\n"
            "Only reference columns, tables, and indexes that appear in the provided SP code or schema — "
            "never invent one, even if it sounds plausible. If no execution plan is provided, state that "
            "clearly and base analysis on static code review only. Do not state numeric performance "
            "improvements unless calculated from real execution plan metrics provided to you; otherwise "
            "describe impact qualitatively. Do not use index hints (WITH (INDEX=...)) unless that index "
            "is defined in your own output and marked as required before deployment.\n\n"
            "Your goal: Analyze execution plans and identify top 5 performance bottlenecks with root cause analysis.",
            perf_prompt,
            step_name=f"Task 1: Performance Analysis ({sp_name})"
        )

        # Task 2: Schema & Index Analysis
        arch_prompt = self._build_architect_prompt(sp_name, sp_code, schemas_text, execution_plan_analysis, has_plan, perf_result)
        arch_result = self._invoke_llm(
            "You are a seasoned Database Architect with deep expertise in SQL Server "
            "database design. You understand indexing strategies, table partitioning, normalization, "
            "and denormalization. You can analyze table schemas and recommend the perfect index "
            "combination (clustered, non-clustered, covering indexes) to optimize query performance. "
            "You consider cardinality, selectivity, and index overhead in your recommendations.\n\n"
            "Only recommend indexes on columns that actually appear in the table schema provided to you — "
            "never invent a column name. Every recommended index must list only real column names copied "
            "directly from the schema text. If a schema was not provided for a referenced table, state that "
            "explicitly instead of guessing its structure.\n\n"
            "Never assert that a specific named index already exists unless it was explicitly given to you "
            "in the input. Label every recommended index clearly as 'NEW — must be created before deployment' "
            "so downstream steps do not reference it as if it already exists. Never recommend dropping a "
            "named index unless that exact name was provided to you in the input.\n\n"
            "Before finalizing your recommendations, check for redundancy — do not recommend both a unique "
            "index and a unique constraint on the same columns, since a constraint creates its own index.\n\n"
            "Your goal: Review table schemas and recommend optimal indexing strategies and table structures.",
            arch_prompt,
            step_name=f"Task 2: Schema & Index Analysis ({sp_name})"
        )

        # Task 3: Query Optimization (CRITICAL — must output COMPLETE SP)
        opt_prompt = self._build_optimizer_prompt(sp_name, sp_code, perf_result, arch_result)
        opt_result = self._invoke_llm(
            "You are a SQL Query Optimization specialist with master-level knowledge "
            "of T-SQL and query tuning. You can rewrite complex stored procedures to eliminate "
            "performance issues while maintaining 100% functional equivalence. You understand "
            "query plans, join strategies, set-based operations, and can transform cursor-based "
            "code into efficient set-based operations. You write clean, maintainable, optimized SQL.\n\n"
            "CRITICAL: You ALWAYS output the COMPLETE optimized SP from CREATE PROCEDURE to END. "
            "You NEVER use shortcuts like '...' or 'rest remains same'.\n\n"
            "🚨 ABSOLUTE RULES - NEVER VIOLATE THESE:\n"
            "1. NEVER change WHERE clause filters - all filter conditions must remain identical\n"
            "2. NEVER change TOP/LIMIT/OFFSET values - result set size must remain same\n"
            "3. NEVER add or remove columns from SELECT lists\n"
            "4. NEVER change JOIN types unless semantically identical (INNER ↔ WHERE-based)\n"
            "5. NEVER change ORDER BY logic - sort order must remain identical\n"
            "6. NEVER change parameter usage - if a parameter is used in original WHERE, keep it\n"
            "7. NEVER change the scope of queries - if original filters by specific criteria, preserve that\n"
            "8. Performance improvements are ONLY allowed if result set is IDENTICAL\n\n"
            "Only use index hints (WITH (INDEX=...)) if that exact index name was provided to you by the "
            "Database Architect step as an existing or newly-created index. Never invent an index name. If "
            "no index was given for a join/filter, write the query without a hint and let the optimizer choose.\n\n"
            "When multiple valid optimization patterns exist for the same problem (e.g. MERGE vs. "
            "UPDATE-then-conditional-INSERT for an upsert), always prefer the simplest correct pattern "
            "(UPDATE-then-conditional-INSERT) unless the SP explicitly requires atomic upsert under proven "
            "high-concurrency access. Do not switch patterns arbitrarily between runs of the same SP.\n\n"
            "If your rewrite changes ANY observable behavior versus the original — including return codes, "
            "error values, rollback behavior, output formatting, result set size, or filtered rows — you MUST "
            "list each such change explicitly in your response and mark it as BLOCKING. A performance gain means "
            "nothing if the results are wrong.\n\n"
            "Your goal: Rewrite SQL stored procedures for optimal performance while preserving EXACT business logic. "
            "Output the FULL COMPLETE procedure — never truncate.",
            opt_prompt,
            step_name=f"Task 3: Query Optimization ({sp_name})"
        )

        # Task 4: Code Review
        review_prompt = self._build_review_prompt(sp_name, sp_code, opt_result)
        review_result = self._invoke_llm(
            "You are a meticulous Code Reviewer with expertise in SQL validation "
            "and testing. You compare original and optimized SQL side-by-side to ensure no business "
            "logic is lost, modified, or broken. You check parameter handling, output columns, "
            "error handling, transaction logic, and edge cases. You create validation reports "
            "and only approve SQL that is functionally identical to the original.\n\n"
            "🚨 CRITICAL CHECKS - Flag as BLOCKING if ANY of these are violated:\n"
            "1. WHERE clause filters changed (added, removed, or modified conditions)\n"
            "2. TOP/LIMIT/OFFSET values changed (different result set size)\n"
            "3. SELECT column list changed (added, removed, or renamed columns)\n"
            "4. Parameter usage changed (e.g., @AssociateId removed from WHERE clause)\n"
            "5. JOIN logic changed in a way that affects result rows\n"
            "6. ORDER BY changed (different sort order)\n"
            "7. Result set scope changed (e.g., from user-specific to all users)\n\n"
            "Do not assign a numeric confidence score (e.g. '99%') to your verdict — confidence scores "
            "invented without real testing are misleading. Instead, list every assumption or unverified "
            "element under a section titled 'Requires Manual Verification Before Deployment'.\n\n"
            "Explicitly check whether the optimized SQL references any index name, column name, or table "
            "structure that does not appear in the original SQL or the provided schema. If it does, flag "
            "this as a BLOCKING issue, not a minor concern — do not mark the SP as PASS if it contains "
            "unverified index hints or invented columns, since these can cause runtime failures.\n\n"
            "If the optimized SQL changes any observable behavior versus the original — including return "
            "codes, error values, rollback behavior, or NULL handling — flag it explicitly even if the "
            "optimized version is arguably better. Never state 'behavior is unchanged' if any deviation exists.\n\n"
            "Do not accept vague or unquantified performance claims from prior steps without noting that "
            "they are estimates, not measurements, unless real execution plan metrics were provided.\n\n"
            "Your goal: Validate that optimized SQL maintains 100% functional equivalence with original code, "
            "and clearly separate what you have actually verified from what still requires manual confirmation.",
            review_prompt,
            step_name=f"Task 4: Code Review ({sp_name})"
        )

        # Task 5: Documentation
        doc_prompt = self._build_doc_prompt(sp_name, perf_result, arch_result, opt_result, review_result)
        doc_result = self._invoke_llm(
            "You are a Documentation Specialist who excels at technical writing. "
            "You create clear, detailed optimization reports that explain what changed, why it "
            "changed, and the expected performance impact. You use markdown formatting, include "
            "index recommendations, and provide actionable deployment instructions. "
            "Your reports are ready for ADO bug work items.\n\n"
            "Before writing any claim, verify it against the actual ORIGINAL and OPTIMIZED SQL given to "
            "you — not from memory of what you intended to change. If you cannot point to the exact line "
            "that supports a claim, do not write it.\n\n"
            "Never use placeholder text such as '[2024-06-XX]' or '[Specialist Name]' — use the real date/"
            "details given, or omit the field.\n\n"
            "State numeric performance improvements only if real benchmark or execution-plan data was "
            "provided to you; otherwise describe impact qualitatively (e.g. 'avoids a table scan') and say "
            "plainly that no baseline measurement exists.\n\n"
            "Do not assign a numeric confidence score. Use a verdict like 'PASS — Conditional' or 'Requires "
            "Manual Verification', and list unresolved risks or assumptions explicitly.\n\n"
            "Only name columns, indexes, or tables that appear in the SQL or schema info you were given. "
            "If you're unsure whether something exists, say so — never present a guess as fact, especially "
            "in CREATE/DROP/ALTER statements.\n\n"
            "Before finalizing, re-check your own report for internal consistency: your Validation section "
            "must not claim something is 'unchanged' if any other part of your analysis found it changed. "
            "If you're not sure a behavior is identical, say so instead of asserting it.\n\n"
            "If you found nothing wrong and everything is verified, say so plainly — do not manufacture "
            "caveats or lower your own confidence just to appear thorough.\n\n"
            "Your goal: a report a senior engineer could fact-check line by line against the real code and "
            "find zero unsupported claims — not one that merely sounds authoritative.",
            doc_prompt,
            step_name=f"Task 5: Documentation ({sp_name})"
        )

        # Extract the FULL optimized SP from Task 3 (Query Optimizer) output
        optimized_sp_code = self._extract_optimized_sp_from_output(opt_result, sp_name)

        # If no SQL code was produced, return error result — decision_gate will
        # mark as Failed, log to error_log, and skip Bug creation
        if not optimized_sp_code:
            error_msg = (
                f"LangChain optimization produced no SQL code for '{sp_name}'. "
                "Task 3 (Query Optimizer) output was empty or contained no ```sql``` block — "
                "most likely caused by max_tokens truncation before the code section. "
                "SP will be retried on the next run."
            )
            return {
                'success': False,
                'sp_name': sp_name,
                'error': error_msg,
                'timestamp': datetime.now(_IST).isoformat()
            }
 
        # Stitch: ensure doc report has the complete optimized SP
        final_report = self._stitch_report(doc_result, optimized_sp_code, sp_name)
 
        # Save report output (in-memory validation only, no file writes)
        output_file = self._save_optimization_result(sp_name, final_report)
 
        print(f"\n{'='*100}")
        print(f"LANGCHAIN OPTIMIZATION COMPLETE")
        print(f"{'='*100}")
        print(f"Report saved: {output_file}")
        print(f"Report size: {len(final_report):,} chars (~{_estimate_tokens(final_report):,} tokens)")
        print(f"{'='*100}\n")
 
        return {
            'success': True,
            'sp_name': sp_name,
            'result': final_report,
            'output_file': output_file,
            'timestamp': datetime.now(_IST).isoformat()
        }
 
    def _format_table_schemas(self, table_schemas) -> str:
        """Format table schemas for step consumption - handles both dict and string"""
        if not table_schemas:
            return "No table schemas provided."
        if isinstance(table_schemas, str):
            return "TABLE SCHEMAS:\n" + "="*80 + "\n\n" + table_schemas
        formatted = "TABLE SCHEMAS:\n" + "="*80 + "\n\n"
        for table_name, schema in table_schemas.items():
            formatted += f"Table: {table_name}\n"
            formatted += "-" * 80 + "\n"
            formatted += schema + "\n\n"
        return formatted
 
    def _build_performance_prompt(self, sp_name, sp_code, execution_plan_analysis, has_plan):
        if has_plan:
            return f"""You are a senior SQL Server Performance Analyst. Analyze the execution plan for stored procedure '{sp_name}' and identify the top 5 performance bottlenecks with forensic precision.

            EXECUTION PLAN ANALYSIS:
            {execution_plan_analysis}

            STORED PROCEDURE CODE:
            {sp_code}

            Your analysis MUST include:
            1. **Top 5 performance issues** ranked by severity (High/Medium/Low impact)
            2. **Quantified cost** - Include actual metrics: CPU ms, I/O reads, estimated cost %, row counts
            3. **Root cause analysis** - Explain WHY this is happening at the database engine level
            4. **Specific line/section** in the SP code where the issue occurs
            5. **Concrete recommendations** - Exact changes needed (add index, rewrite JOIN, etc.)

            FOCUS AREAS TO ANALYZE:
            - Table/Index Scans vs Seeks (quantify rows scanned)
            - Missing Indexes (identify exact columns for key + include)
            - Implicit conversions causing index non-usage
            - Nested loops on large datasets
            - Sort/Hash operations spilling to tempdb
            - Key lookups after non-covering index seeks
            - Parameter sniffing or statistics issues
            - Blocking/locking patterns

            Format your response as:
            ## Performance Bottlenecks Identified

            ### 1. [Issue Name] - Cost: X% | Impact: High
            **Severity:** High / Medium / Low
            **Quantified Cost:** X ms CPU, Y logical reads, Z% of total cost
            **Location in Code:** Line X-Y or [specific section description]
            **Root Cause:** [Detailed technical explanation - why the query optimizer chose this plan, what's causing inefficiency]
            **Recommendation:** [Specific actionable fix with exact syntax when applicable]
            **Expected Improvement:** [Estimated performance gain after fix]

            (Repeat for all 5 issues with decreasing severity)
            """
        else:
            return f"""You are a senior SQL Server Performance Analyst. Analyze the stored procedure '{sp_name}' code and identify the top 5 performance bottlenecks using code pattern analysis and SQL Server best practices.

            STORED PROCEDURE CODE:
            {sp_code}

            Your analysis MUST include:
            1. **Top 5 performance issues** ranked by severity (High/Medium/Low impact)
            2. **Code smell identification** - Anti-patterns, inefficient constructs
            3. **Root cause analysis** - Explain WHY this pattern causes performance problems
            4. **Specific line/section** in the SP code where the issue occurs
            5. **Concrete recommendations** - Exact code changes needed

            FOCUS AREAS TO ANALYZE:
            - **Missing indexes** - Identify columns used in JOINs, WHERE, ORDER BY
            - **Non-sargable WHERE clauses** - Functions on columns, implicit conversions, OR conditions
            - **Cursor/loop usage** - Can this be replaced with set-based operations?
            - **Scalar functions** in SELECT/WHERE - Causes row-by-row execution
            - **SELECT *** - Retrieves unnecessary columns
            - **Missing transaction handling** - Risk of partial commits
            - **Excessive temp table usage** - Can CTEs or table variables work better?
            - **Implicit conversions** - Data type mismatches in JOINs/WHERE
            - **Correlated subqueries** - Should be JOINs or window functions
            - **No pagination** - Large result sets without TOP/OFFSET-FETCH

            Format your response as:
            ## Performance Bottlenecks Identified

            ### 1. [Issue Name] - Impact: High
            **Severity:** High / Medium / Low
            **Location in Code:** Line X-Y or [specific section description]
            **Root Cause:** [Detailed technical explanation - why this code pattern is inefficient, what SQL Server does internally]
            **Current Implementation:** [Show the problematic code snippet if short]
            **Recommendation:** [Specific actionable fix with code example]
            **Expected Improvement:** [Estimated performance gain - "Reduce CPU by 40%", "Eliminate table scan", etc.]

            (Repeat for all 5 issues with decreasing severity)
            """
 
    def _build_architect_prompt(self, sp_name, sp_code, schemas_text, execution_plan_analysis, has_plan, perf_result):
        if has_plan:
            return f"""Review the table schemas used by stored procedure '{sp_name}' and recommend
            optimal indexing strategies.

            {schemas_text}

            EXECUTION PLAN INSIGHTS:
            {execution_plan_analysis}

            PERFORMANCE ANALYSIS CONTEXT (from Performance Analyst):
            {perf_result}

            Provide:
            1. Missing indexes that would improve performance
            2. Index type (Clustered/Non-Clustered/Covering)
            3. Key columns and included columns
            4. Expected performance improvement
            5. Any schema optimization suggestions

            Format your response as:
            ## Index Recommendations
            1. [Table Name] - [Index Type]
               - Key Columns: ...
               - Included Columns: ...
               - Reason: ...
               - Expected Improvement: ...
            """
        else:
            return f"""Review the table schemas used by stored procedure '{sp_name}' and recommend
            optimal indexing strategies based on the SP code and schema structure.

            {schemas_text}

            PERFORMANCE ANALYSIS CONTEXT (from Performance Analyst):
            {perf_result}

            STORED PROCEDURE CODE:
            {sp_code}

            Infer index needs from the SP's JOIN conditions, WHERE clauses, ORDER BY,
            and GROUP BY usage.

            Provide:
            1. Missing indexes that would improve performance
            2. Index type (Clustered/Non-Clustered/Covering)
            3. Key columns and included columns
            4. Expected performance improvement
            5. Any schema optimization suggestions

            IMPORTANT: Do NOT mention in your response whether or not an execution plan
            was available. Write the recommendations as a standard schema/index review.

            Format your response as:
            ## Index Recommendations
            1. [Table Name] - [Index Type]
               - Key Columns: ...
               - Included Columns: ...
               - Reason: ...
               - Expected Improvement: ...
            """
 
    def _build_optimizer_prompt(self, sp_name, sp_code, perf_result, arch_result):
        return f"""Rewrite stored procedure '{sp_name}' to eliminate ALL performance issues while maintaining 100% functional equivalence.

ORIGINAL SP:
{sp_code}

PERFORMANCE ISSUES TO FIX:
{perf_result}

INDEX RECOMMENDATIONS TO LEVERAGE:
{arch_result}

🚨 NON-NEGOTIABLE: Result set must be IDENTICAL - preserve WHERE filters, TOP/LIMIT, SELECT columns, parameter usage (including OUTPUT params), JOIN types, ORDER BY, RETURN values. Performance gains are worthless if results are wrong.

🚨 PRESERVE EDGE CASES: Keep exact NULL handling (ISNULL/COALESCE/IS NULL), empty string vs NULL logic, zero vs NULL in calculations, column computation behavior.

🚨 PRESERVE CONTROL FLOW: Keep RAISERROR/THROW error numbers and messages, temp table structures (#temp/@table), dynamic SQL logic (EXEC/sp_executesql), MERGE WHEN conditions, cursor result order if converting to set-based, XML/JSON processing logic, recursive CTE structure, TVF calls (table-valued functions).

REQUIREMENTS:
1. Maintain interface (parameters incl OUTPUT, output columns, types, RETURN codes), business logic, error handling
2. Fix performance issues using set-based ops, sargable predicates, inline comments
3. TRY/CATCH: Add ROLLBACK TRANSACTION in CATCH before logging/raising errors
4. Cache GETDATE() once into @CurrentDateTime at start, reuse throughout
5. Remove WITH (NOLOCK) hints, make predicates sargable

**OUTPUT THE COMPLETE SP FROM CREATE PROCEDURE TO END - NO TRUNCATION, NO "...", NO PLACEHOLDERS**

Apply these optimizations where applicable:
- Replace scalar subqueries with JOINs/CTEs
- Eliminate cursors → set-based JOINs/window functions
- Fix non-sargable predicates (move functions outside WHERE)
- Remove SELECT * → select only needed columns
- Use EXISTS instead of COUNT for existence checks
- Batch multiple queries to reduce round trips
- Add ROLLBACK TRANSACTION in CATCH blocks before error handling
- Cache GETDATE() into variable, reuse for all date operations

Format as:
## Optimized SQL Code

```sql
-- =====================================================
-- Optimized Version of {sp_name}
-- Key improvements: [list 3-5 major changes]
-- =====================================================

CREATE PROCEDURE {sp_name}
(
    [Complete parameter list with exact same names, types, defaults]
)
AS
BEGIN
    [COMPLETE optimized stored procedure code with inline comments explaining optimizations]
END
```

## Key Changes Made

### 1. [Optimization Name] - Lines X-Y
**Before:** [brief description]
**After:** [brief description]
**Why:** [performance benefit]

### 2. [Optimization Name] - Lines X-Y
(Repeat for each major change)
"""
 
    def _build_review_prompt(self, sp_name, sp_code, opt_result):
        return f"""Compare original and optimized SQL for '{sp_name}' and validate functional equivalence.

ORIGINAL SP:
{sp_code}

OPTIMIZED VERSION:
{opt_result}

🚨 BLOCKING: Flag if WHERE filters, TOP/LIMIT, SELECT columns, parameter usage (incl OUTPUT), JOIN types, ORDER BY, or RETURN values changed. Wrong results > performance.

🚨 EDGE CASES: Compare NULL handling (ISNULL/COALESCE/IS NULL), empty string vs NULL, zero vs NULL calculations, column computation logic. Flag as CONCERN if differs.

🚨 CONTROL FLOW: Validate RAISERROR/THROW error numbers/messages unchanged, temp table structures preserved, dynamic SQL logic (EXEC/sp_executesql) identical, MERGE WHEN conditions preserved, cursor-to-set conversion maintains result order, XML/JSON processing logic unchanged, recursive CTE structure preserved, TVF calls identical.

🚨 INCOMPLETE: Flag if CATCH block missing ROLLBACK TRANSACTION, or GETDATE() called multiple times instead of cached in @CurrentDateTime.

VALIDATE: Parameters (count/names/types/OUTPUT), output columns, RETURN codes, business logic, error handling, transactions, invented elements (flag as BLOCKING).

Check for invented elements (index names, columns not in original/schema) - flag as BLOCKING issues.

Format as:
## Validation Report

**Verdict:** PASS/FAIL

### Verified Aspects
- [Aspect 1: specific details]
- [Aspect 2: specific details]

### Concerns or Blocking Issues
- [Any concerns - be specific]

### Requires Manual Verification Before Deployment
- [Unverified assumptions or elements]

### Testing Recommendations
1. [Specific test scenario]
2. [Specific test scenario]
"""
 
    def _build_doc_prompt(self, sp_name, perf_result, arch_result, opt_result, review_result):

        return f"""Create a comprehensive, production-ready SQL optimization report for '{sp_name}'.

CONTEXT:
===== PERFORMANCE ANALYST =====
{perf_result}

===== DATABASE ARCHITECT =====
{arch_result}

===== QUERY OPTIMIZER =====
{opt_result}

===== CODE REVIEWER =====
{review_result}

CRITICAL RULES:
- NO metadata headers (no "Work Item Type", "Date", "Prepared By", "Priority")
- NO markdown tables - use headings, bullets, numbered lists
- Be SPECIFIC with line numbers, table names, column names, metrics
- QUANTIFY everything (use numbers, percentages)
- For "## Optimized SQL Code" section, write ONLY: [OPTIMIZED_SP_CODE_PLACEHOLDER]

🚨 PERFORMANCE CLAIMS: Without baseline metrics (logical reads/execution times/plan costs), use "Expected" or "Projected" improvement. Separate SQL rewrite benefits from index benefits. Say "up to X% WITH indexes" not "X% improvement". No specific % without measurements.

REQUIRED STRUCTURE (use these EXACT headings):

# SQL Optimization Report: {sp_name}

## Executive Summary
[4-6 sentences: SP purpose, why optimize, issues count by severity, solutions applied, honest expected results - distinguish measured vs projected vs index-dependent]

## Performance Issues Identified

### 1. [Issue Name from Performance Analyst]
**Severity:** High/Medium/Low
**Location in Code:** [specific lines/section]
**What's Wrong (Root Cause):** [3-4 sentences: what code does, WHY it's a problem, impact, scalability concern]
**Example of Current Bad Code:**
```sql
[2-5 line snippet showing problem]
```
**How It Was Fixed:** [3-4 sentences: what change was made, WHY it's faster, what SQL Server can now do]
```sql
[2-5 line snippet showing solution]
```
**Performance Impact:** [quantified improvement]

[Repeat for all 5 issues]

## Recommended Indexes

### Index 1: [Descriptive Name]
**Table:** [schema].[table]
**Why This Index Is Needed:** [3-4 sentences: query pattern, problem solved, how optimizer benefits, additional benefit]
**Index Structure:**
- **Key Columns:** [columns] - [WHY explanation]
- **Included Columns:** [columns] - [WHY explanation]
**Create Index SQL:**
```sql
CREATE NONCLUSTERED INDEX [...];
```
**Expected Performance Improvement:** [quantified benefit]
**Maintenance Considerations:** [disk space, insert/update impact, rebuild schedule]

[Repeat for each index]

## Optimized SQL Code

**Introduction:** [2-3 sentences about complete optimized SP, business logic preserved, inline comments explain optimizations]

**Summary of Key Changes:**
1. **[Optimization Name]** - [brief description]
2. **[Optimization Name]** - [brief description]
[List 5-10 major changes]

[OPTIMIZED_SP_CODE_PLACEHOLDER]

## Validation Status

**Verdict:** [PASS/FAIL from Code Reviewer]

**What Was Verified:**
✅ **Parameter Signature:** [details: count, names, types, defaults]
✅ **Output Columns:** [details: count, names, types, order]
✅ **Business Logic:** [details: IF/ELSE, CASE, calculations, filtering]
✅ **Error Handling:** [details: TRY/CATCH, error messages, codes]
✅ **Transaction Boundaries:** [details: BEGIN TRAN/COMMIT/ROLLBACK]
✅ **Edge Cases:** [details: NULL handling, empty results, boundary values]

**Differences (Optimizations Only):** [list intentional performance changes only]

**Risks and Mitigation:**
[If risks exist, list each as: Risk → Likelihood → Mitigation]
[If no risks: "✅ No significant risks identified. All changes are performance-only optimizations."]

## Deployment Steps

**CRITICAL: Follow in order. Test in DEV → QA → PROD.**

### Step 1: Pre-Deployment Backup
**What to backup:** SP definition, index definitions, sample query results
**Backup commands:**
```sql
SELECT OBJECT_DEFINITION(OBJECT_ID('{sp_name}'));
-- Save output to: {sp_name}_backup_YYYYMMDD.sql

SELECT i.name, OBJECT_NAME(i.object_id), i.type_desc
FROM sys.indexes i
WHERE OBJECT_NAME(i.object_id) IN ([list affected tables]);
-- Save output to: indexes_backup_YYYYMMDD.txt

SET STATISTICS IO, TIME ON;
EXEC {sp_name} @param1 = 'test_value';
SET STATISTICS IO, TIME OFF;
-- Save output to: baseline_performance_YYYYMMDD.txt
```

### Step 2: Create Recommended Indexes
**Index creation order:** [timing guidance]
**Commands:**
```sql
[List all CREATE INDEX statements from "Recommended Indexes" section]

-- Verify indexes created
SELECT name, type_desc FROM sys.indexes WHERE object_id = OBJECT_ID('[table_name]');
```

### Step 3: Deploy Optimized Stored Procedure
**Deployment window:** During low-traffic period if possible
**Commands:**
```sql
DROP PROCEDURE IF EXISTS {sp_name};
GO
-- [Paste complete optimized SP code from "Optimized SQL Code" section above]
GO

-- Verify SP created
SELECT OBJECT_NAME(object_id), create_date, modify_date
FROM sys.procedures WHERE name = '{sp_name.split('.')[-1]}';
```

### Step 4: Validation Testing

**A. Functional Testing (Output Correctness)**
```sql
-- Test 1: Typical inputs
EXEC {sp_name} @param1 = 'common_value', @param2 = 123;
-- Compare output to baseline backup - should match exactly

-- Test 2: Edge cases
EXEC {sp_name} @param1 = NULL, @param2 = 0;  -- NULL handling
EXEC {sp_name} @param1 = '', @param2 = -1;    -- Empty/negative values

-- Test 3: Empty result set
EXEC {sp_name} @param1 = 'nonexistent';
```

**B. Performance Testing (Speed Improvement)**
```sql
SET STATISTICS IO, TIME ON;
EXEC {sp_name} @param1 = 'test_value', @param2 = 123;
SET STATISTICS IO, TIME OFF;
-- Compare CPU time, elapsed time, logical reads, scan count to baseline
```

**C. Execution Plan Verification**
```sql
SET SHOWPLAN_XML ON;
EXEC {sp_name} @param1 = 'test_value';
SET SHOWPLAN_XML OFF;
-- Verify: Index Seeks vs Table Scans, new indexes used, no warnings, lower costs
```

### Step 5: Post-Deployment Monitoring
**Monitor for 48-72 hours:**

**A. Performance Metrics**
```sql
SELECT execution_count,
       total_elapsed_time / 1000000.0 AS total_elapsed_sec,
       (total_elapsed_time / execution_count) / 1000.0 AS avg_elapsed_ms,
       total_logical_reads / execution_count AS avg_logical_reads
FROM sys.dm_exec_procedure_stats
WHERE object_id = OBJECT_ID('{sp_name}');
```

**B. Error Monitoring**
```sql
-- Check application error logs and SQL Server error log
SELECT * FROM sys.dm_exec_requests WHERE blocking_session_id > 0;
```

**C. Index Usage Verification**
```sql
SELECT i.name, s.user_seeks, s.user_scans, s.last_user_seek
FROM sys.indexes i
JOIN sys.dm_db_index_usage_stats s ON i.object_id = s.object_id AND i.index_id = s.index_id
WHERE i.object_id = OBJECT_ID('[table_name]') AND s.user_seeks > 0;
```

**D. Rollback Plan**
If issues arise:
```sql
-- Restore original SP from backup
-- [Execute backed up SP definition from Step 1]
-- Optionally drop new indexes if causing issues
DROP INDEX [IX_IndexName] ON [schema].[table];
```

## Expected Benefits

**Performance Improvements:**
1. **Execution Time:** Current: [X]s → Expected: [Y]s ([Z]% reduction)
2. **CPU Utilization:** Current: [X]ms → Expected: [Y]ms ([Z]% reduction)
3. **I/O Reduction:** Current: [X] reads → Expected: [Y] reads ([Z]% reduction)
4. **Memory Efficiency:** [description of benefit]

**Scalability Improvements:** [how optimization helps as data grows - e.g., "Performance remains constant as table grows from 500K to 5M rows"]

**Resource Savings:** [infrastructure impact: CPU load reduction, tempdb pressure, memory grants]

**Business Impact:** [user experience improvements, availability gains, cost savings, capacity increase]
"""

    def _extract_optimized_sp_from_output(self, opt_output: str, sp_name: str = "unknown") -> str:
        """
        Extract the complete optimized SP code from Task 3 (Query Optimizer) output.
        This is the authoritative source for the full optimized SP.
        """
        try:
            if not opt_output:
                print("   WARNING: Could not extract optimizer task output")
                log_audit(
                    "TOKEN_OVERFLOW",
                    sp_name=sp_name,
                    message="LangChain Task 3 (Query Optimizer) produced empty output — likely truncated by max_tokens. Final report will lack the optimized SP code.",
                    agent="Query Optimizer",
                    task_index=2,
                )
                return ""

            sql_blocks = re.findall(r'```sql\s*\n(.*?)```', opt_output, re.DOTALL)
            if not sql_blocks:
                print("   WARNING: No SQL code block found in optimizer output")
                log_audit(
                    "TOKEN_OVERFLOW",
                    sp_name=sp_name,
                    message="LangChain Task 3 (Query Optimizer) output contained no ```sql``` block — response likely truncated before the code section was reached.",
                    agent="Query Optimizer",
                    output_chars=len(opt_output),
                    output_tail=opt_output.strip()[-120:],
                )
                return ""

            longest_block = max(sql_blocks, key=len)
            print(f"   Extracted optimized SP: {len(longest_block):,} chars (~{_estimate_tokens(longest_block):,} tokens)")

            if not re.search(r'\bEND\b\s*(?:;?\s*GO\b)?\s*$', longest_block.strip(), re.IGNORECASE):
                print("   WARNING: Optimized SP may be truncated (no END/GO terminator found at tail)")
                log_audit(
                    "TOKEN_OVERFLOW",
                    sp_name=sp_name,
                    message="LangChain Task 3 (Query Optimizer) SQL block has no END/GO terminator at its tail — SP body likely truncated by max_tokens. Report stitched with partial code.",
                    agent="Query Optimizer",
                    extracted_chars=len(longest_block),
                    tail_snippet=longest_block.strip()[-120:],
                )

            return longest_block.strip()

        except Exception as e:
            error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
            print(f"   WARNING: Error extracting optimized SP from output: {e}")
            log_pipeline_error(
                error_type='LLM_API_ERROR',
                error=error_text,
                sp_name=sp_name,
            )
            return ""
 
    def _stitch_report(self, doc_report: str, optimized_sp_code: str, sp_name: str = "unknown") -> str:
        """
        Replace the placeholder in the doc report with the actual complete optimized SP.
        If no placeholder found, append the optimized SP to the Optimized SQL Code section.
        """
        if not optimized_sp_code:
            print("   WARNING: No optimized SP code to stitch — report may be incomplete")
            return doc_report

        sql_block = f"```sql\n{optimized_sp_code}\n```"

        if '[OPTIMIZED_SP_CODE_PLACEHOLDER]' in doc_report:
            stitched = doc_report.replace('[OPTIMIZED_SP_CODE_PLACEHOLDER]', sql_block)
            print("   Stitched: Replaced [OPTIMIZED_SP_CODE_PLACEHOLDER] with full optimized SP")
            return stitched

        existing_blocks = re.findall(r'```sql\s*\n(.*?)```', doc_report, re.DOTALL)
        if existing_blocks:
            longest_existing = max(existing_blocks, key=len)
            if len(longest_existing) >= len(optimized_sp_code) * 0.85:
                print("   Stitch: Doc specialist included complete SP — no replacement needed")
                return doc_report
            else:
                log_audit(
                    "TOKEN_OVERFLOW",
                    sp_name=sp_name,
                    message=(
                        f"LangChain Task 5 (Documentation Specialist) SQL block is truncated: "
                        f"{len(longest_existing):,} chars vs optimizer's {len(optimized_sp_code):,} chars "
                        f"({len(longest_existing)/len(optimized_sp_code)*100:.0f}% of full SP). "
                        f"Stitch replaced it with the complete code from Task 3."
                    ),
                    agent="Documentation Specialist",
                    doc_block_chars=len(longest_existing),
                    optimizer_block_chars=len(optimized_sp_code),
                )
                truncated_block = f"```sql\n{longest_existing}```"
                stitched = doc_report.replace(truncated_block, sql_block)
                print(f"   Stitched: Replaced truncated SP ({len(longest_existing):,} chars) with complete SP ({len(optimized_sp_code):,} chars)")
                return stitched

        marker = "## Optimized SQL Code"
        if marker in doc_report:
            idx = doc_report.index(marker) + len(marker)
            next_newline = doc_report.find('\n', idx)
            if next_newline != -1:
                stitched = doc_report[:next_newline + 1] + f"\n{sql_block}\n" + doc_report[next_newline + 1:]
                print("   Stitched: Inserted full optimized SP after '## Optimized SQL Code' heading")
                return stitched

        print("   WARNING: Could not find insertion point — appending optimized SP at end")
        return doc_report + f"\n\n## Optimized SQL Code\n\n{sql_block}\n"
 
    def _save_optimization_result(self, sp_name: str, final_report: str) -> str:
        """Report is kept in memory only — no disk write, no folder creation.

        Returns empty string; callers use the `result` key from optimize_sql().
        """
        # Validate report completeness
        expected_sections = ['## Executive Summary', '## Performance Issues', '## Recommended Indexes',
                             '## Optimized SQL Code', '## Validation Status', '## Deployment Steps', '## Expected Benefits']
        missing_sections = [s for s in expected_sections if s not in final_report]
        
        if missing_sections:
            print(f"\n   WARNING: Report may be incomplete! Missing sections: {', '.join(missing_sections)}")
            log_audit(
                "TOKEN_OVERFLOW",
                sp_name=sp_name,
                message=(
                    f"LangChain final report is missing {len(missing_sections)} expected section(s) — "
                    f"Documentation Specialist output likely truncated by max_tokens."
                ),
                agent="Documentation Specialist",
                missing_sections=missing_sections,
                report_chars=len(final_report),
            )
        
        return ""  # No file written
 
 
if __name__ == "__main__":

    print("LangChain SQL Optimizer initialized successfully!")

    print("This module orchestrates 5 sequential LLM calls for SQL optimization.")
