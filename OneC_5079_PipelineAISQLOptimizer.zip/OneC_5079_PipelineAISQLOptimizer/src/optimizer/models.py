﻿"""
Database Access Layer for AI SQL Optimizer

All DB interactions use plain SQLAlchemy text() queries directly against the tables.
This module NEVER calls stored procedures or stored functions.

Table schema is managed exclusively by the DB pipeline (schema.sql).
This module NEVER creates or alters tables.

Schema: 5079_dbo (all tables live in this schema)

Tables used:
  app_config         — registered applications monitored by the pipeline
  ado_defect_tracker — slow SP lifecycle (detect → ADO Bug → close)
  error_log          — all pipeline / API / SP-level failures
"""

import os
from contextlib import contextmanager
from datetime import datetime
from typing import Generator, List, Optional

from sqlalchemy import create_engine, text
from sqlalchemy.orm import Session, sessionmaker

# ---------------------------------------------------------------------------
# Engine / session setup
# ---------------------------------------------------------------------------

DATABASE_URL = os.getenv('DATABASE_URL')
if not DATABASE_URL:
    raise RuntimeError(
        "[DB ERROR] DATABASE_URL is not set. "
        "Please ensure all required secrets are available."
    )

if DATABASE_URL.startswith("sqlite"):
    _connect_args = {"check_same_thread": False}
else:
    # sslmode=disable is required for Cloud SQL Proxy local connections (127.0.0.1).
    # The proxy handles encryption to Cloud SQL — the local hop does not use SSL.
    # This overrides any PGSSLMODE env var that libpq might pick up from the OS.
    _connect_args = {"sslmode": "disable"}

engine = create_engine(
    DATABASE_URL,
    echo=False,
    pool_pre_ping=True,
    connect_args=_connect_args,
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# ---------------------------------------------------------------------------
# Schema constant — read from VG env var DB_SCHEMA (default: '5079_dbo')
# ---------------------------------------------------------------------------
DB_SCHEMA = os.getenv('DB_SCHEMA', '5079_dbo')


# ---------------------------------------------------------------------------
# ORM class stubs — kept as documentation / type hints only.
# No ORM queries are performed on these classes anywhere in this module.
# ---------------------------------------------------------------------------

class AppConfig:
    """
    Mirrors app_config table columns.
    One row per application monitored by AppDynamics.
    Schema managed by DB pipeline (schema.sql).

    Columns: id, Appd_AppID, Organization_Name, app_name, Query_Threshold,
             Page_Execution_TimeinMillis, is_active, db_server_name, repo_name,
             ado_collection, ado_project, ado_area_path, ado_iteration_path
    """


class ADODefectTracker:
    """
    Mirrors ado_defect_tracker table columns.
    Central lifecycle table — one row per (app_id, sp_name).
    Schema managed by DB pipeline (schema.sql).

    defect_status state machine:
        NULL        -> New SP detected, never processed yet  -> ALLOW
        Active      -> ADO Bug open, not started             -> BLOCK
        InProgress  -> App team working on it                -> BLOCK
        Closed      -> Fixed and closed normally             -> ALLOW next cycle
        Rejected    -> Closed, biz logic changed             -> ALLOW next cycle
        Exempt      -> Closed 'default functionality'        -> BLOCK forever
        Deferred    -> Snoozed (check snooze_end_date)       -> BLOCK until end date
        Failed      -> Pipeline crashed mid-way              -> RETRY next run
    """


class ErrorLog:
    """
    Mirrors error_log table columns.
    Append-only pipeline error log.
    Schema managed by DB pipeline (schema.sql).

    error_type constants:
        STAGE_ERROR, SP_PIPELINE_ERROR, APPD_API_ERROR, GITHUB_API_ERROR,
        ADO_API_ERROR, LLM_API_ERROR, DB_ERROR
    """


# ---------------------------------------------------------------------------
# Session context manager
# ---------------------------------------------------------------------------

@contextmanager
def get_session() -> Generator[Session, None, None]:
    """Context-managed session with automatic commit/rollback."""
    session = SessionLocal()
    try:
        yield session
        session.commit()
    except Exception as e:
        session.rollback()
        from optimizer.utils.audit_logger import log_pipeline_error
        log_pipeline_error(
            error_type='DB_ERROR',
            error=f"{type(e).__name__}: {e}",
        )
        raise e
    finally:
        session.close()


def get_db_session() -> Session:
    """Manual session — caller must close."""
    try:
        return SessionLocal()
    except Exception as e:
        from optimizer.utils.audit_logger import log_pipeline_error
        log_pipeline_error(
            error_type='DB_ERROR',
            error=f"{type(e).__name__}: {e}",
        )
        raise


# ---------------------------------------------------------------------------
# DB initialisation / health check
# ---------------------------------------------------------------------------

def init_db():
    """
    Verify connectivity and confirm all required tables exist in the 5079_dbo schema.
    NEVER creates or alters tables — that is the DB pipeline's job.
    """
    required_tables = {'app_config', 'ado_defect_tracker', 'error_log'}
    with engine.connect() as conn:
        conn.execute(text("SELECT 1"))  # basic connectivity check
    from sqlalchemy import inspect
    existing = set(inspect(engine).get_table_names(schema=DB_SCHEMA))
    missing = required_tables - existing
    if missing:
        raise RuntimeError(
            f"[DB ERROR] Required table(s) not found in schema '{DB_SCHEMA}': {missing}. "
            f"Run schema.sql via the DB pipeline before starting the application pipeline."
        )
    print(f"Database connection verified. Required tables present in '{DB_SCHEMA}': {sorted(required_tables)}")


# ---------------------------------------------------------------------------
# Read functions — plain SQL queries directly against 5079_dbo tables
# ---------------------------------------------------------------------------

def get_active_apps() -> List[tuple]:
    """
    Get active apps as tuples:
    (Appd_AppID, app_name, Query_Threshold, Page_Execution_TimeinMillis).
    """
    with get_session() as session:
        result = session.execute(
            text(
                f'SELECT "Appd_AppID", app_name, "Query_Threshold", "Page_Execution_TimeinMillis" '
                f'FROM "{DB_SCHEMA}".app_config WHERE is_active = 1'
            )
        )
        return result.fetchall()


def get_active_apps_objects() -> List[dict]:
    """Get active apps as row-dicts (all columns)."""
    with get_session() as session:
        result = session.execute(
            text(f'SELECT * FROM "{DB_SCHEMA}".app_config WHERE is_active = 1')
        )
        rows = result.fetchall()
        keys = result.keys()
        return [dict(zip(keys, row)) for row in rows]


def get_app_by_id(appd_app_id: int) -> Optional[dict]:
    """
    Get app config by AppDynamics App ID.
    Returns a dict of all columns, or None if not found.
    """
    with get_session() as session:
        result = session.execute(
            text(f'SELECT * FROM "{DB_SCHEMA}".app_config WHERE "Appd_AppID" = :appd_app_id'),
            {"appd_app_id": appd_app_id},
        )
        row = result.fetchone()
        if row:
            return dict(zip(result.keys(), row))
        return None


def get_defect_by_sp(app_id: int, sp_name: str) -> Optional[dict]:
    """
    Get defect record for a specific (app_id, sp_name) pair.
    Returns a dict of all columns, or None if not found.
    """
    with get_session() as session:
        result = session.execute(
            text(
                f'SELECT * FROM "{DB_SCHEMA}".ado_defect_tracker '
                f'WHERE app_id = :app_id AND sp_name = :sp_name'
            ),
            {"app_id": app_id, "sp_name": sp_name},
        )
        row = result.fetchone()
        if row:
            return dict(zip(result.keys(), row))
        return None


def clear_defect_tracker_table():
    """Clear all records from ado_defect_tracker."""
    with get_session() as session:
        session.execute(text(f'DELETE FROM "{DB_SCHEMA}".ado_defect_tracker'))
    print("Defect tracker table cleared")


def get_defect_count() -> int:
    """Return total row count of ado_defect_tracker."""
    with get_session() as session:
        result = session.execute(
            text(f'SELECT COUNT(*) FROM "{DB_SCHEMA}".ado_defect_tracker')
        )
        row = result.fetchone()
        return int(row[0]) if row else 0


def validate_db_connection() -> bool:
    """Verify DB is reachable and app_config has at least one row."""
    try:
        with get_session() as session:
            result = session.execute(
                text(f'SELECT COUNT(*) FROM "{DB_SCHEMA}".app_config')
            )
            row = result.fetchone()
            count = int(row[0]) if row else 0
            print(f"Database connection validated. Found {count} app configs.")
            return True
    except Exception as e:
        print(f"Database connection failed: {e}")
        from optimizer.utils.audit_logger import log_pipeline_error
        log_pipeline_error(
            error_type='DB_ERROR',
            error=f"{type(e).__name__}: {e}",
        )
        return False


def print_db_stats():
    print("\n" + "=" * 80)
    print("DATABASE STATISTICS")
    print("=" * 80)
    with get_session() as session:
        app_count = session.execute(
            text(f'SELECT COUNT(*) FROM "{DB_SCHEMA}".app_config')
        ).scalar()
        active_app_count = session.execute(
            text(f'SELECT COUNT(*) FROM "{DB_SCHEMA}".app_config WHERE is_active = 1')
        ).scalar()
        defect_count = session.execute(
            text(f'SELECT COUNT(*) FROM "{DB_SCHEMA}".ado_defect_tracker')
        ).scalar()
        print(f"App Configs: {app_count} (Active: {active_app_count})")
        print(f"Defects: {defect_count}")
    print("=" * 80 + "\n")


if __name__ == "__main__":
    init_db()
    if validate_db_connection():
        print_db_stats()
