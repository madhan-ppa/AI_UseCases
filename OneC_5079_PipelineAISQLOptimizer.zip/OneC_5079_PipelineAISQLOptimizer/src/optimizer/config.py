"""
Configuration Manager - Secure Credential Management
Loads sensitive credentials from .env file following security best practices
"""
import os
from pathlib import Path
from typing import Optional
from urllib.parse import quote_plus
import warnings


# ── GCP Secret Manager secret names used by this project ───────────────────
# Global pipeline secrets (fetched once at startup via Config._load_credentials)
# Only needed in GKE mode (when GCP_PROJECT_ID is set). In local dev  - values
# come directly from the .env file — no GCP SM calls are made.
GCP_SECRET_GITHUB_TOKEN       = '5079_GITHUB_TOKEN'          # default GitHub PAT
GCP_SECRET_AZURE_OPENAI_KEY   = '5079_AZURE_OPENAI_API_KEY'
GCP_SECRET_ADO_PAT_TOKEN      = '5079_ADO_PAT_TOKEN'         # global ADO PAT
GCP_SECRET_APPD_API_TOKEN     = '5079_APPD_API_TOKEN'
GCP_SECRET_APPD_PASSWORD      = '5079_APPD_PASSWORD'
# Per-org secrets (fetched at runtime in decision_gate.py)
# GitHub : 5079_<<OrgName-spaces-as-hyphens>>_GitRepo  e.g. 5079_HR-Services-IT-Systems_GitRepo
# ADO    : single shared secret '5079_ADO_PAT_TOKEN' used across all environments (DEV/SIT/PROD)


def get_gcp_secret(secret_name: str, project_id: str = None) -> Optional[str]:
    """
    Fetch the latest version of a secret from GCP Secret Manager.

    Returns None and prints an error when:
      - GCP_PROJECT_ID is not set
      - the secret does not exist in Secret Manager
      - google-cloud-secret-manager package is not installed
      - any GCP API error occurs

    NEVER falls back to environment variables — caller must handle None.
    In GKE the pod Workload Identity SA needs: roles/secretmanager.secretAccessor
    """
    try:
        from google.cloud import secretmanager  # type: ignore
        pid = project_id or os.getenv('GCP_PROJECT_ID', '')
        if not pid:
            print(f"[GCP SM ERROR] GCP_PROJECT_ID not set — cannot fetch secret '{secret_name}'")
            return None
        client = secretmanager.SecretManagerServiceClient()
        resource = f"projects/{pid}/secrets/{secret_name}/versions/latest"
        response = client.access_secret_version(request={"name": resource})
        return response.payload.data.decode("utf-8").strip()
    except Exception as exc:
        print(f"[GCP SM ERROR] Secret '{secret_name}' not found in project '{project_id or os.getenv('GCP_PROJECT_ID', '?')}': {exc}")
        return None


class Config:
    """
    Centralized configuration management with secure credential loading
    
    Usage:
        from config import Config
        
        config = Config()
        github_token = config.GITHUB_TOKEN
        azure_endpoint = config.AZURE_OPENAI_ENDPOINT
    """
    
    def __init__(self, env_file: str = ".env"):
        """
        Initialize configuration by loading from .env file
        
        Args:
            env_file: Path to .env file (default: .env in current directory)
        """
        self.env_file = env_file
        self._load_env_file()
        self._load_credentials()
        self._validate_critical_credentials()
    
    def _load_env_file(self):
        """Load environment variables from .env file"""
        env_path = Path(self.env_file)
        
        if not env_path.exists():
            warnings.warn(
                f"\n⚠️  WARNING: {self.env_file} file not found!\n"
                f"   Create {self.env_file} file from {self.env_file}.example template\n"
                f"   Some features may not work without proper credentials.",
                UserWarning
            )
            return
        
        # Read and parse .env file
        with open(env_path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                
                # Skip empty lines and comments
                if not line or line.startswith('#'):
                    continue
                
                # Parse KEY=VALUE format
                if '=' in line:
                    key, value = line.split('=', 1)
                    key = key.strip()
                    value = value.strip()
                    
                    # Set environment variable if not already set
                    if key and not os.getenv(key):
                        os.environ[key] = value
    
    def _load_credentials(self):
        """
        Dual-mode credential loading:

        LOCAL mode  (GCP_PROJECT_ID not set):
            Secrets are read directly from os.environ, which was already populated
            from the .env file by _load_env_file(). No GCP SM calls are made.
            SQLite (DATABASE_PATH) is used — POSTGRES_HOST is not set locally.

        GKE mode  (GCP_PROJECT_ID is set via ConfigMap):
            All secrets are fetched exclusively from GCP Secret Manager via
            Workload Identity. No env-var fallback — a missing secret is logged
            and the pipeline continues with an empty value.
            DATABASE_URL is constructed from POSTGRES_* ConfigMap vars +
            5079_DATABASE_PASSWORD from GCP SM.
        """
        # --- ENVIRONMENT REGION LOGIC ---
        self.ENV_REGION = os.getenv('ENV_REGION', 'DEV').upper().strip()  # DEV, SIT, PROD
        # Set GCP project for secrets based on region
        if self.ENV_REGION == 'PROD':
            self.GCP_PROJECT_ID = os.getenv('GCP_PROJECT_ID_PROD', os.getenv('GCP_PROJECT_ID', ''))
        else:
            self.GCP_PROJECT_ID = os.getenv('GCP_PROJECT_ID_NONPROD', os.getenv('GCP_PROJECT_ID', ''))
        self._missing_secrets: list = []
        _gke_mode = bool(self.GCP_PROJECT_ID)

        def _secret(secret_name: str, local_env_key: str = '') -> str:
            if _gke_mode:
                val = get_gcp_secret(secret_name, project_id=self.GCP_PROJECT_ID)
                if not val:
                    self._missing_secrets.append(secret_name)
                    print(f"[SECRET MISSING] '{secret_name}' not found in GCP Secret Manager — pipeline will not work correctly.")
                return val or ''
            else:
                return os.getenv(local_env_key, '') if local_env_key else ''

        # --- REGION-BASED URL/SECRET LOGIC ---
        # Use the same VG variable names for all environments; values are set per environment in Azure DevOps UI
        self.ADO_ORG_URL = os.getenv('ADO_ORG_URL', '')
        self.ADO_PROJECT = os.getenv('ADO_PROJECT', '')
        self.ADO_BASE_URL = os.getenv('ADO_BASE_URL', '')
        self.APPD_CONTROLLER_URL = os.getenv('APPD_CONTROLLER_URL', '')
        # Set IS_TEST_ADO flag based on region for logic elsewhere
        self.IS_TEST_ADO = self.ENV_REGION in ('DEV', 'SIT')

        # --- Sensitive secrets ---
        self.GITHUB_TOKEN         = _secret(GCP_SECRET_GITHUB_TOKEN,      'GITHUB_TOKEN')
        self.AZURE_OPENAI_API_KEY = _secret(GCP_SECRET_AZURE_OPENAI_KEY,  'AZURE_OPENAI_API_KEY')
        self.ADO_PAT_TOKEN        = _secret(GCP_SECRET_ADO_PAT_TOKEN,     'ADO_PAT_TOKEN')
        self.APPD_API_TOKEN       = _secret(GCP_SECRET_APPD_API_TOKEN,    'APPD_API_TOKEN')
        self.APPD_PASSWORD        = _secret(GCP_SECRET_APPD_PASSWORD,     'APPD_PASSWORD')

        # ── DATABASE_URL ──────────────────────────────────────────────────────
        # POSTGRES_USE_IAM=true  (GKE):
        #   Cloud SQL IAM / Workload Identity auth — no password.
        #   URL: postgresql://user@host:port/db
        #
        # POSTGRES_USE_IAM=false (local dev, default):
        #   No PostgreSQL — models.py uses SQLite via DATABASE_PATH.
        #
        # The built URL is injected into os.environ so models.py picks it up.
        _use_iam = os.getenv('POSTGRES_USE_IAM', 'false').lower() in ('true', '1', 'yes')
        if _use_iam:
            _pg_host = os.getenv('POSTGRES_HOST', '127.0.0.1').strip() or '127.0.0.1'
            _pg_port = os.getenv('POSTGRES_PORT', '5432').strip() or '5432'
            _pg_db   = os.getenv('POSTGRES_DATABASE', '').strip()
            _pg_user = os.getenv('POSTGRES_USER', '').strip()
            if not _pg_db or not _pg_user:
                print("[DB ERROR] POSTGRES_DATABASE/POSTGRES_USER missing for IAM mode")
            else:
                _pg_user_enc = quote_plus(_pg_user)
                _pg_db_enc   = quote_plus(_pg_db)
                _db_url = f"postgresql+psycopg2://{_pg_user_enc}@{_pg_host}:{_pg_port}/{_pg_db_enc}"
                os.environ['DATABASE_URL'] = _db_url
                print(f"[DB] Using IAM/Workload Identity auth via proxy at {_pg_host}:{_pg_port}")

        # ── Propagate secrets into os.environ for LiteLLM / LangChain internals ─
        for env_key, val in [
            ('GITHUB_TOKEN',         self.GITHUB_TOKEN),
            ('AZURE_OPENAI_API_KEY', self.AZURE_OPENAI_API_KEY),
            ('ADO_PAT_TOKEN',        self.ADO_PAT_TOKEN),
            ('APPD_API_TOKEN',       self.APPD_API_TOKEN),
            ('APPD_PASSWORD',        self.APPD_PASSWORD),
        ]:
            if val:
                os.environ[env_key] = val

        # ── Non-sensitive configuration — K8s ConfigMap / .env ────────────────
        self.GITHUB_BASE_URL          = os.getenv('GITHUB_BASE_URL', 'https://github.cognizant.com/api/v3')
        self.GIT_DEFAULT_BRANCH       = os.getenv('GIT_DEFAULT_BRANCH', 'develop')
        # LLM_PROVIDER: 'vertex_ai' (GKE default) or 'azure_openai' (local / fallback)
        self.LLM_PROVIDER             = os.getenv('LLM_PROVIDER', 'azure_openai').lower().strip()
        # Azure OpenAI (used when LLM_PROVIDER=azure_openai)
        self.AZURE_OPENAI_ENDPOINT    = os.getenv('AZURE_OPENAI_ENDPOINT', '')
        self.AZURE_OPENAI_DEPLOYMENT  = os.getenv('AZURE_OPENAI_DEPLOYMENT', 'gpt-4.1')
        self.AZURE_OPENAI_API_VERSION = os.getenv('AZURE_OPENAI_API_VERSION', '2025-01-01-preview')
        # Vertex AI / Claude (used when LLM_PROVIDER=vertex_ai)
        self.VERTEX_PROJECT_ID        = os.getenv('VERTEX_PROJECT_ID', '')
        self.VERTEX_LOCATION          = os.getenv('VERTEX_LOCATION', 'us-east5')
        self.CLAUDE_MODEL             = os.getenv('CLAUDE_MODEL', 'claude-opus-4-6')
        self.CLAUDE_MAX_TOKENS        = int(os.getenv('CLAUDE_MAX_TOKENS', '64000'))
        self.CLAUDE_TEMPERATURE       = float(os.getenv('CLAUDE_TEMPERATURE', '0.1'))
        self.ADO_USER_STORY_NAME      = os.getenv('ADO_USER_STORY_NAME', 'AISQLOptimization_Suggestions')
        self.ADO_API_VERSION          = os.getenv('ADO_API_VERSION', '7.0')
        self.APPD_ACCOUNT_NAME        = os.getenv('APPD_ACCOUNT_NAME', '')
        self.APPD_USERNAME            = os.getenv('APPD_USERNAME', '')
        self.APPD_TIME_RANGE_MINS     = int(os.getenv('APPD_TIME_RANGE_MINS', '1440'))
        self.APPD_EXPERIENCE_FILTER   = os.getenv('APPD_EXPERIENCE_FILTER', 'VERY_SLOW,SLOW')
        self.APPD_HEADLESS            = os.getenv('APPD_HEADLESS', 'false').lower() == 'true'
        self.APPD_SKIP_PLAN_FETCH     = os.getenv('APPD_SKIP_PLAN_FETCH', 'false').lower() == 'true'
        self.DATABASE_PATH            = os.getenv('DATABASE_PATH', 'AI_SQL_Optimizer.db')
        self.LANGCHAIN_MAX_ITER       = int(os.getenv('LANGCHAIN_MAX_ITER', '3'))
        self._gke_mode                = _gke_mode
    
    def _validate_critical_credentials(self):
        """Print a consolidated error summary for any secrets missing from GCP SM (GKE mode only)."""
        if self._missing_secrets and self._gke_mode:
            print("\n" + "=" * 80)
            print("[CRITICAL] The following secrets were NOT found in GCP Secret Manager:")
            for s in self._missing_secrets:
                print(f"           • {s}")
            print(f"           GCP Project: {self.GCP_PROJECT_ID}")
            print("           Add the missing secrets to GCP SM and redeploy before running the pipeline.")
            print("=" * 80 + "\n")
    
    def is_github_configured(self) -> bool:
        """Check if GitHub credentials are configured"""
        return bool(self.GITHUB_TOKEN)

    def is_llm_configured(self) -> bool:
        """Check if the selected LLM provider is properly configured"""
        if self.LLM_PROVIDER == 'azure_openai':
            return bool(self.AZURE_OPENAI_API_KEY and self.AZURE_OPENAI_ENDPOINT)
        if self.LLM_PROVIDER == 'vertex_ai':
            # Vertex AI uses Workload Identity — no API key needed, just a project ID
            return bool(self.VERTEX_PROJECT_ID)
        return False
    
    def is_ado_configured(self) -> bool:
        """Check if Azure DevOps credentials are configured"""
        return bool(self.ADO_ORG_URL and self.ADO_PROJECT and self.ADO_PAT_TOKEN)


# Singleton instance for easy import
_config_instance: Optional[Config] = None


def get_config(env_file: str = ".env") -> Config:
    """
    Get or create the configuration singleton instance
    
    Args:
        env_file: Path to .env file
    
    Returns:
        Config instance
    
    Usage:
        from config import get_config
        
        config = get_config()
        github_token = config.GITHUB_TOKEN
    """
    global _config_instance
    
    if _config_instance is None:
        _config_instance = Config(env_file)
    
    return _config_instance
