﻿"""
AppDynamics Execution Plan Downloader — REST API only, GKE-friendly
====================================================================
Downloads SQL Server execution plans from AppD via the public REST API
authenticated with an API Bearer token. No Selenium, no manual cookies.

Per-SP flow:
  1. getAllConsolidatedDatabases  -> dbServerId + nodeId + is_mi
  2. queryListData                -> queryHashCode (+ caches queryText)
  3. getCachedExecutionPlanList   -> plan handle list (newest-first)
  4. Path A: getQueryPlans        -> plan XML (Bearer-only, fast)
  5. Path B (fallback): startDBMonOperation -> poll getData -> plan XML
                                              (Bearer-only attempt; works for
                                              some servers, returns 204 for
                                              SQL MI without browser SSO cookies)

When BOTH paths fail (typically SQL MI), the SP is skipped gracefully with
an audit log entry and the caller (Decision Gate) proceeds with SP code +
table schemas only — LangChain handles missing-plan case natively.

Plans are NEVER written to disk: the plan XML is kept as an in-memory
string, analyzed, and discarded — no temp files, no persistent storage.

Required in .env:
  APPD_API_TOKEN
  APPD_CONTROLLER_URL
  APPD_ACCOUNT_NAME
"""

import os
import re
import sys
import time
import uuid
import traceback

import requests
import urllib3
_APPD_SSL_VERIFY = os.getenv('APPD_SSL_VERIFY', 'true').lower() not in ('false', '0', 'no')
if not _APPD_SSL_VERIFY:
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

try:
    from ..models import get_session, DB_SCHEMA
    from ..config import get_config
    from ..sql_analyzer.advanced_sql_plan_analyzer import AdvancedSQLPlanAnalyzer
    from ..utils.audit_logger import log_audit, log_pipeline_error
    from ..utils.http_session import build_http_session, RateLimiter
except ImportError:
    _root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    if _root not in sys.path:
        sys.path.insert(0, _root)
    os.chdir(_root)
    from optimizer.models import get_session
    from optimizer.config import get_config
    from optimizer.sql_analyzer.advanced_sql_plan_analyzer import AdvancedSQLPlanAnalyzer
    from optimizer.utils.audit_logger import log_audit, log_pipeline_error
    from optimizer.utils.http_session import build_http_session, RateLimiter


class AppDExecutionPlanDownloader:
    """
    Pure REST execution-plan downloader. Bearer token only — no cookies,
    no Selenium, no browser session. Each SP uses its app-specific DB
    server from AppConfig.db_server_name. Plans are kept in memory only;
    no files are written to disk (GKE-safe).
    """

    def __init__(self):
        cfg = get_config()
        self.controller_url = cfg.APPD_CONTROLLER_URL
        self.account_name   = cfg.APPD_ACCOUNT_NAME
        self.api_token      = cfg.APPD_API_TOKEN
        self.api_session    = None  # lazy-initialized on first call
        self._rate_limiter  = RateLimiter()

    # ──────────────────────────────────────────────────────────────────
    # Database helpers — SP / DB-server discovery from optimization queue
    # ──────────────────────────────────────────────────────────────────

    def get_all_pending_sps(self):
        """All SPs awaiting optimization, joined to their app-specific DB server.
        
        Includes SPs with status: NULL, empty string, Failed, Rejected, or Closed.
        This aligns with Decision Gate's eligibility filter to ensure execution
        plans are fetched for all SPs that will be processed in Stage 3.
        """
        from sqlalchemy import text
        with get_session() as session:
            result = session.execute(
                text(
                    f'SELECT adt.sp_name, adt.app_id, adt.app_name, '
                    f'       ac.db_server_name, adt.occurrence_count, ac.repo_name '
                    f'FROM "{DB_SCHEMA}".ado_defect_tracker adt '
                    f'JOIN "{DB_SCHEMA}".app_config ac '
                    '  ON adt.app_id = ac."Appd_AppID" AND adt.app_name = ac.app_name '
                    'WHERE ac.is_active = 1 '
                    '  AND (adt.defect_status IS NULL '
                    '       OR adt.defect_status = \'\' '
                    '       OR adt.defect_status = \'Null\' '
                    '       OR adt.defect_status = \'Failed\' '
                    '       OR adt.defect_status = \'Rejected\' '
                    '       OR adt.defect_status = \'Closed\') '
                    'ORDER BY adt.occurrence_count DESC'
                )
            )
            rows = result.fetchall()
        return [
            {
                "sp_name":          r[0],
                "app_id":           r[1],
                "app_name":         r[2],
                "db_server_name":   r[3].split(".")[0] if r[3] else r[3],
                "occurrence_count": r[4],
                "repo_name":        r[5],
            }
            for r in rows
        ]

    def get_current_processing_sp(self):
        """Highest-priority pending SP (single record), or None."""
        rows = self.get_all_pending_sps()
        return rows[0] if rows else None

    def get_sp_and_db_server(self, sp_name=None, db_server_name=None):
        """Resolve SP + server: use args if given, else next pending SP."""
        if sp_name and db_server_name:
            return sp_name, db_server_name
        current = self.get_current_processing_sp()
        if not current:
            print("   No SP currently pending for optimization.")
            return None, None
        resolved_sp = sp_name        or current["sp_name"]
        resolved_db = db_server_name or current["db_server_name"]
        print(f"   Auto-detected: SP={resolved_sp}  DB={resolved_db}  App={current['app_name']}")
        return resolved_sp, resolved_db

    # ──────────────────────────────────────────────────────────────────
    # AppD REST session — Bearer token only
    # ──────────────────────────────────────────────────────────────────

    def _build_session(self):
        """
        Create requests.Session authenticated with Bearer token only.
        NO cookies, NO browser session — every REST call carries the
        Authorization: Bearer <token> header and that is the only auth.
        """
        if self.api_session is not None:
            return self.api_session
        if not self.api_token:
            raise RuntimeError("APPD_API_TOKEN is not set in .env.")

        s = build_http_session(verify_ssl=_APPD_SSL_VERIFY)
        s.headers.update({
            "Accept":        "application/json, text/plain, */*",
            "Content-Type":  "application/json;charset=UTF-8",
            "Authorization": f"Bearer {self.api_token}",
            # 'adrum' is a static HTTP HEADER (not a cookie). AppD requires
            # it on AJAX-style REST calls or some endpoints return HTML.
            "adrum":         "isAjax:true",
        })
        print(f"   [session] Bearer-only session ready")
        self.api_session = s
        return s

    def _api_post(self, endpoint, payload):
        """POST helper. Returns parsed JSON or None on failure."""
        s = self._build_session()
        try:
            self._rate_limiter.check_request()
            r = s.post(f"{self.controller_url}{endpoint}", json=payload, timeout=30)
            if not r.ok:
                print(f"   [api] POST {endpoint} -> HTTP {r.status_code}")
                return None
            return r.json()
        except Exception as exc:
            error_text = f"{type(exc).__name__}: {exc}\n{traceback.format_exc()}"
            print(f"   [api] POST {endpoint} failed: {exc}")
            log_pipeline_error(
                error_type='APPD_API_ERROR',
                error=error_text,
                sp_name=f'(AppD API: {endpoint})',
            )
            return None

    # ──────────────────────────────────────────────────────────────────
    # DB server resolution (with name-suffix tiebreaker + MI detection)
    # ──────────────────────────────────────────────────────────────────

    def _resolve_db_server(self, db_server_name):
        """Return {dbServerId, nodeId, configId, name, is_mi} or None."""
        print(f"   [db] Resolving '{db_server_name}'...")
        result = self._api_post(
            "/controller/databasesui/databases/getAllConsolidatedDatabases", []
        )
        if result is None:
            return None
        servers = result if isinstance(result, list) else result.get("data") or []

        target = db_server_name.lower().strip()
        pat = re.compile(rf"(?:^|[^a-z0-9]){re.escape(target)}(?:[^a-z0-9]|$)", re.I)
        matches = [
            srv for srv in servers
            if isinstance(srv, dict) and any(
                isinstance(srv.get(k), str) and pat.search(srv[k])
                for k in ("host", "name", "uniqueHostId")
            )
        ]
        # Tiebreaker: prefer server whose AppD `name` ends with the exact
        # search term after the last ' - '. Disambiguates Azure server names.
        if len(matches) > 1:
            exact = [
                s for s in matches
                if isinstance(s.get("name"), str)
                and s["name"].split(" - ")[-1].strip().lower() == target
            ]
            if len(exact) == 1:
                matches = exact

        def _to_info(srv):
            is_mi = any(
                p.get("key") == "MSSQLType"
                and "MANAGED_INSTANCE" in str(p.get("value", ""))
                for p in (srv.get("metadataProps") or [])
            )
            return {
                "dbServerId": srv.get("id"),
                "nodeId":     srv.get("nodeId"),
                "configId":   srv.get("configId", -1),
                "name":       srv.get("name"),
                "is_mi":      is_mi,
            }

        if len(matches) == 0:
            print(f"   [db] No matches for '{db_server_name}'.")
            return None

        if len(matches) > 1:
            print(f"   [db] {len(matches)} match(es) for '{db_server_name}' — will probe each to find SP:")
            for m in matches[:5]:
                print(f"        id={m.get('id')} | name={m.get('name')}")
            return [_to_info(srv) for srv in matches]

        info = _to_info(matches[0])
        flag = "SQL_MI" if info["is_mi"] else "SQL_DB"
        print(f"   [db] Resolved: id={info['dbServerId']}, nodeId={info['nodeId']} ({flag})")
        return info

    # ──────────────────────────────────────────────────────────────────
    # SP discovery: queryHashCode + queryText + database name
    # ──────────────────────────────────────────────────────────────────

    def _find_query_hash(self, db_server_id, sp_name):
        """Find the SP in AppD's recent query history; returns hash or None.
        Caches queryText on self for Path B's startDBMonOperation body."""
        sp_core = sp_name.replace("[", "").replace("]", "").strip()
        if "." in sp_core:
            sp_core = sp_core.split(".")[-1]
        sp_core = sp_core.strip().lower()
        if not sp_core:
            return None
        print(f"   [sp] Searching for '{sp_core}'...")

        now_ms = int(time.time() * 1000)
        for label, ms in [("1h", 3600 * 1000),
                          ("24h", 24 * 3600 * 1000),
                          ("7d", 7 * 24 * 3600 * 1000)]:
            body = {
                "dbConfigId": -1, "dbServerId": db_server_id,
                "field": "query-id", "size": 200, "filterBy": "time",
                "endTime": now_ms, "startTime": now_ms - ms,
                "useTimeBasedCorrelation": False, "waitStateIds": [],
            }
            result = self._api_post(
                "/controller/databasesui/databases/queryListData", body
            )
            if result is None:
                continue
            queries = result if isinstance(result, list) else (
                result.get("queries") or result.get("data") or [])
            best = fallback = None
            for q in queries:
                if not isinstance(q, dict):
                    continue
                text = (q.get("queryText") or "").lower()
                if sp_core not in text or not q.get("queryHashCode"):
                    continue
                if "create procedure" in text or "create proc " in text:
                    best = q
                    break
                if fallback is None:
                    fallback = q
            match = best or fallback
            if match:
                qh = match["queryHashCode"]
                print(f"   [sp] queryHashCode={qh}  (window={label})")
                # Cache queryText for Path B
                self._last_query_text = match.get("queryText") or ""
                return qh

        print(f"   [sp] '{sp_name}' not found in 7-day history.")
        return None

    def _resolve_database_name(self, db_server_id, query_hash):
        """Get the SQL database name (e.g. 'OneC_1738') for startDBMonOperation."""
        now_ms = int(time.time() * 1000)
        body = {
            "dbConfigId": -1, "dbServerId": db_server_id,
            "queryHashCode": query_hash,
            "startTime": now_ms - 3600 * 1000, "endTime": now_ms,
            "groupQueries": False, "rolledUp": True,
        }
        result = self._api_post(
            "/controller/databasesui/databases/queryDetails", body
        )
        if result is None:
            return None
        detail = result.get("queryDetail") or result
        active = detail.get("activeDatabases") or []
        if active and isinstance(active, list) and active[0].get("name"):
            return active[0]["name"]
        return detail.get("dbName")

    # ──────────────────────────────────────────────────────────────────
    # Plan retrieval (Path A: getQueryPlans, Path B: startDBMon+getData)
    # ──────────────────────────────────────────────────────────────────

    def _get_cached_plan_list(self, db_server_id, query_hash):
        """Return plan-handle list (newest-first), or [] if none."""
        now_ms = int(time.time() * 1000)
        body = {
            "queryHashCode": query_hash, "dbConfigId": -1,
            "dbServerId":    db_server_id,
            "startTime":     now_ms - 60 * 60 * 1000,
            "endTime":       now_ms,
        }
        result = self._api_post(
            "/controller/databasesui/databases/getCachedExecutionPlanList", body
        )
        if not isinstance(result, list) or not result:
            return []
        print(f"   [plans] {len(result)} cached plan(s) found.")
        return result

    def _get_plan_xml_path_a(self, node_id, plan_hashes):
        """Path A: getQueryPlans (Bearer-only). Returns plan XML or None."""
        body = {"nodeId": node_id, "planHashes": plan_hashes}
        result = self._api_post(
            "/controller/databasesui/databases/getQueryPlans", body
        )
        if not isinstance(result, list):
            return None
        for p in result:
            if isinstance(p, dict) and p.get("queryPlanText"):
                return p["queryPlanText"]
        return None

    def _try_path_b_dbmon(self, node_id, plan_hashes, query_hash, query_text, db_name):
        """
        Path B: startDBMonOperation -> poll getData. Bearer-only attempt.
        Empirically returns HTTP 204 for SQL MI servers without browser SSO
        cookies, but we try anyway as some non-MI servers respond on this
        path even when Path A returned null. Returns plan XML or None.
        """
        s = self._build_session()
        base = self.controller_url
        sid = str(uuid.uuid4())
        extra_headers = {
            "Origin":  base,
            "Referer": f"{base}/controller/?accountName={self.account_name}",
        }
        start_url = f"{base}/controller/restui/transientEvent/startDBMonOperation"

        op_id = None
        for i, plan_hash in enumerate(plan_hashes[:3]):
            now_ms = int(time.time() * 1000)
            body = {
                "session": {
                    "sessionId":       sid,
                    "nodeId":          node_id,
                    "sessionType":     "DBMON",
                    "lastUpdatedTime": now_ms,
                    "creationTime":    now_ms,
                },
                "operation": "DBMON_GET_CACHED_EXPLAIN_PLAN",
                "nameValuePair": {
                    "queryPlanHashValue": plan_hash,
                    "queryHashCode":      query_hash,
                    "type":               "MSSQL",
                    "queryText":          query_text or "",
                    "database":           db_name or "",
                    "startOffset":        None,
                    "endOffset":          None,
                },
            }
            try:
                self._rate_limiter.check_request()
                r = s.post(start_url, json=body, headers=extra_headers, timeout=30)
            except Exception as exc:
                error_text = f"{type(exc).__name__}: {exc}\n{traceback.format_exc()}"
                print(f"   [path-b] startDBMonOperation exception: {exc}")
                log_pipeline_error(
                    error_type='APPD_API_ERROR',
                    error=error_text,
                    sp_name='(AppD path-b: startDBMonOperation)',
                )
                continue
            print(f"   [path-b] startDBMonOperation hash[{i}] HTTP {r.status_code}")
            if r.status_code == 200 and (r.text or "").strip():
                op_id = r.text.strip().strip('"')
                print(f"   [path-b] opId = {op_id}")
                break

        if not op_id:
            return None

        poll_url = (f"{base}/controller/restui/transientEvent/getData"
                    f"?operation=DBMON_GET_CACHED_EXPLAIN_PLAN&opId={op_id}")
        poll_body = {
            "sessionId":       sid,
            "nodeId":          node_id,
            "sessionType":     "DBMON",
            "lastUpdatedTime": int(time.time() * 1000),
            "creationTime":    int(time.time() * 1000),
        }
        for _ in range(10):
            time.sleep(2)
            try:
                self._rate_limiter.check_request()
                r = s.post(poll_url, json=poll_body, headers=extra_headers, timeout=30)
            except Exception:
                continue
            if not r.ok:
                continue
            try:
                payload = r.json()
            except Exception:
                continue
            for entry in (payload.get("data") or []):
                for exp in (entry.get("explanation") or []):
                    xml = exp.get("query_plan")
                    if xml and "<ShowPlanXML" in xml:
                        print(f"   [path-b] Plan XML retrieved ({len(xml):,} chars)")
                        return xml
        return None

    def _fetch_plan_via_rest_api(self, sp_name, db_server_name):
        """
        Orchestrator: resolve server -> find SP -> get plan list -> Path A,
        then Path B fallback. Returns path to a temp .sqlplan file on success
        (caller MUST delete it after use), or None on graceful skip.
        """
        print(f"\n--- Fetch plan: '{sp_name}' on '{db_server_name}' ---")

        resolved = self._resolve_db_server(db_server_name)
        if not resolved:
            return None

        # Multiple candidates — probe each to find which server has this SP
        if isinstance(resolved, list):
            print(f"   [db] Probing {len(resolved)} candidate server(s) to locate SP...")
            info = None
            query_hash = None
            for idx, candidate in enumerate(resolved, 1):
                cid = candidate.get("dbServerId")
                if not cid:
                    continue
                print(f"   [db] [{idx}/{len(resolved)}] Checking server id={cid} ({candidate.get('name')})...")
                qh = self._find_query_hash(cid, sp_name)
                if qh:
                    info = candidate
                    query_hash = qh
                    print(f"   [db] ✓ SP found on server id={cid} — using this server.")
                    break
                else:
                    print(f"   [db] ✗ SP not found on server id={cid}, trying next...")
            if not info or not query_hash:
                print(f"   [db] ❌ SP '{sp_name}' not found on any of the {len(resolved)} candidate servers.")
                return None
        else:
            info = resolved
            if not info.get("dbServerId") or not info.get("nodeId"):
                return None
            query_hash = self._find_query_hash(info["dbServerId"], sp_name)
            if not query_hash:
                return None

        db_server_id = info["dbServerId"]
        node_id      = info["nodeId"]
        is_mi        = info["is_mi"]

        plan_list = self._get_cached_plan_list(db_server_id, query_hash)
        if not plan_list:
            print(f"   [plans] No cached plans for '{sp_name}'.")
            return None
        plan_hashes = [p["planId"] for p in plan_list
                       if isinstance(p, dict) and p.get("planId")]
        if not plan_hashes:
            return None

        # ── Path A: getQueryPlans (Bearer-only) ──
        plan_xml = self._get_plan_xml_path_a(node_id, plan_hashes)

        # ── Path B fallback: startDBMonOperation + getData ──
        if not plan_xml:
            print("   [plans] Path A returned null. Trying Path B "
                  "(startDBMonOperation+getData)...")
            db_name = self._resolve_database_name(db_server_id, query_hash) or ""
            plan_xml = self._try_path_b_dbmon(
                node_id=node_id,
                plan_hashes=plan_hashes,
                query_hash=query_hash,
                query_text=getattr(self, "_last_query_text", "") or "",
                db_name=db_name,
            )

        # ── Both paths failed -> graceful skip ──
        if not plan_xml:
            if is_mi:
                print(f"   [skip] All REST API paths failed for SQL MI server "
                      f"'{db_server_name}'.")
                print( "   [skip] Pipeline will proceed with SP code + table "
                       "schemas only.")
            else:
                print(f"   [plans] All REST API paths failed for '{sp_name}'.")
                print( "   [plans] Plan handle likely evicted from SQL Server "
                       "procedure cache. Will retry on next pipeline run.")
            return None
        print(f"   [plans] Plan XML received ({len(plan_xml):,} chars) — in-memory only")
        return plan_xml

    # ──────────────────────────────────────────────────────────────────
    # Plan analysis (single canonical analyzer)
    # ──────────────────────────────────────────────────────────────────

    def _analyse_plan(self, xml_string, sp_name):
        """
        Analyze plan XML (supplied as a string — no file I/O) with
        AdvancedSQLPlanAnalyzer. Returns a dict shaped for Decision Gate:
            {
              'analysis':          <full analyzer output>,
              'top_5_text':        <formatted top-5 summary>,
              'top_05_operations': <list of dicts>,
            }
        Returns None when the analyzer finds no actionable operations.
        """
        if not xml_string:
            print(f"   No plan XML to analyze for '{sp_name}'.")
            return None

        print(f"\n   Analyzing in-memory plan ({len(xml_string):,} chars) for '{sp_name}'...")
        try:
            analyzer = AdvancedSQLPlanAnalyzer()
            analysis = analyzer.generate_comprehensive_analysis_from_string(xml_string)
            if analysis and "top_05_operations" in analysis:
                top_ops  = analysis["top_05_operations"]
                top_text = self._format_top5(top_ops, analysis)
                print(f"   [analyze] Extracted {len(top_ops)} top operations.")
                return {
                    "analysis":          analysis,
                    "top_5_text":        top_text,
                    "top_05_operations": top_ops,
                }
            print(f"   [analyze] AdvancedSQLPlanAnalyzer returned no top_05_operations.")
            return None
        except Exception as exc:
            error_text = f"{type(exc).__name__}: {exc}\n{traceback.format_exc()}"
            print(f"   [analyze] AdvancedSQLPlanAnalyzer error: {exc}")
            log_pipeline_error(
                error_type='STAGE_ERROR',
                error=error_text,
                sp_name=sp_name,
            )
            return None

    def _format_top5(self, top_operations, analysis):
        """Format top-5 bottleneck operations as text for the AI prompt."""
        lines      = ["TOP 5 PERFORMANCE BOTTLENECK OPERATIONS:\n"]
        is_runtime = bool(top_operations) and "actual_elapsed_ms" in top_operations[0]
        for i, op in enumerate(top_operations, 1):
            lines.append(
                f"{i}. Rank {op.get('rank', i)} | Stmt {op.get('statement_id', 'N/A')} "
                f"| Node {op.get('node_id', 'N/A')}: {op.get('operator_type', 'Unknown')}"
            )
            if is_runtime:
                lines.append(
                    f"   ELAPSED: {op.get('actual_elapsed_ms', 0):,}ms  "
                    f"CPU: {op.get('actual_cpu_ms', 0):,}ms  "
                    f"ROWS: {op.get('actual_rows', 0):,}  "
                    f"EXEC: {op.get('actual_executions', 0):,}"
                )
                lines.append(
                    f"   READS Logical={op.get('actual_logical_reads', 0):,}  "
                    f"Physical={op.get('actual_physical_reads', 0):,}"
                )
            else:
                lines.append(
                    f"   EST.COST: {op.get('estimated_subtree_cost', 0):.4f}  "
                    f"EST.ROWS: {op.get('estimated_rows', 0):,}  "
                    f"EXEC: {op.get('estimated_executions', 0):,}"
                )
            for key in ("object_info", "issue_category", "optimization_recommendation"):
                val = op.get(key)
                if val:
                    lines.append(f"   {key.upper().replace('_', ' ')}: {val}")
            lines.append("")

        ai_ctx = analysis.get("ai_optimization_context", {}) if isinstance(analysis, dict) else {}
        if ai_ctx:
            lines.append("\nAI OPTIMIZATION CONTEXT:")
            lines.append(f"  Urgency: {ai_ctx.get('optimization_urgency', 'N/A')}")
            focus = [a for a in ai_ctx.get("recommended_focus_areas", []) if a]
            if focus:
                lines.append(f"  Focus Areas: {', '.join(focus)}")
        return "\n".join(lines)

    # ──────────────────────────────────────────────────────────────────
    # Memory compaction — retains only what Stage 3 (Decision Gate) needs
    # ──────────────────────────────────────────────────────────────────

    def _compact_analysis(self, full_analysis):
        """
        Compact the full AdvancedSQLPlanAnalyzer output to retain ONLY
        the fields that Stage 3 (Decision Gate → _get_execution_plan_text)
        actually reads: top_05_operations.

        This reduces per-SP memory from ~500KB (full analysis with raw
        statement texts, all operations, context dicts) down to ~3-5KB
        (5 compact operation summaries with truncated statement text).

        Called immediately after _analyse_plan() so the full analysis dict
        and raw plan XML can be garbage-collected before the next SP is
        processed.
        """
        if not full_analysis or "top_05_operations" not in full_analysis:
            return full_analysis

        compact = {
            "top_05_operations": [
                {
                    "rank":                    op.get("rank"),
                    "statement_id":            op.get("statement_id"),
                    "node_id":                 op.get("node_id"),
                    "operator_type":           op.get("operator_type"),
                    "actual_elapsed_ms":       op.get("actual_elapsed_ms", 0),
                    "actual_cpu_ms":           op.get("actual_cpu_ms", 0),
                    "actual_rows":             op.get("actual_rows", 0),
                    "actual_executions":       op.get("actual_executions", 0),
                    "actual_logical_reads":    op.get("actual_logical_reads", 0),
                    "actual_physical_reads":   op.get("actual_physical_reads", 0),
                    "estimated_subtree_cost":  op.get("estimated_subtree_cost", 0),
                    "estimated_rows":          op.get("estimated_rows", 0),
                    "estimated_executions":    op.get("estimated_executions", 0),
                    # Truncate statement_text to 500 chars to prevent memory bloat
                    # from large multi-statement SPs. Stage 3 only uses this for
                    # the AI prompt context — 500 chars is sufficient.
                    "statement_text":          (op.get("statement_text") or "")[:500],
                    "object_info":             op.get("object_info"),
                    "issue_category":          op.get("issue_category"),
                    "optimization_recommendation": op.get("optimization_recommendation"),
                }
                for op in full_analysis["top_05_operations"]
            ],
        }
        return compact

    # ──────────────────────────────────────────────────────────────────
    # Public API
    # ──────────────────────────────────────────────────────────────────

    def download_execution_plan(self, sp_name=None, db_server_name=None):
        """
        Download + analyze plan for a single SP. Returns:
            { 'file_path': None, 'analysis_result': dict|None }
        file_path is always None — plan is analyzed in memory then deleted.
        analysis_result is None when both REST paths fail (graceful skip).
        """
        print("\n" + "=" * 80)
        print("APPD EXECUTION PLAN DOWNLOADER -- SINGLE SP")
        print("=" * 80)

        sp_name, db_server_name = self.get_sp_and_db_server(sp_name, db_server_name)
        if not sp_name or not db_server_name:
            print("   Cannot proceed: SP name or DB server name is missing.")
            return None

        print(f"\n   SP        : {sp_name}")
        print(f"   DB Server : {db_server_name}")

        analysis_result = None
        try:
            print("\n[1] Building API session...")
            self._build_session()

            print("\n[2] Fetching execution plan...")
            xml_string = self._fetch_plan_via_rest_api(sp_name, db_server_name)
            if xml_string:
                analysis_result = self._analyse_plan(xml_string, sp_name)
        except Exception as exc:
            error_text = f"{type(exc).__name__}: {exc}\n{traceback.format_exc()}"
            print(f"\n   Unexpected error: {exc}")
            traceback.print_exc()
            log_pipeline_error(
                error_type='APPD_API_ERROR',
                error=error_text,
                sp_name=sp_name,
            )

        return {"file_path": None, "analysis_result": analysis_result}

    def download_all_execution_plans(self):
        """
        Batch: download + analyze plans for ALL pending SPs. Returns:
            { sp_name: {
                'file_path':       None,
                'analysis_result': dict|None (compact — top-5 ops only),
                'error':           str|None,
              } }

        Memory optimization:
            Each plan XML (10-100MB) is fetched, analyzed, and discarded
            immediately. Only a compact summary (~3-5KB per SP) containing
            the top-5 operation metrics is retained in the results dict.
            This keeps total memory bounded regardless of SP count.

        SPs whose plan fetch fails (e.g. SQL MI servers, evicted plans)
        get analysis_result=None — Decision Gate will run LangChain on those
        with SP code + table schemas only.
        """
        print("\n" + "=" * 80)
        print("APPD EXECUTION PLAN DOWNLOADER -- BATCH MODE")
        print("=" * 80)

        pending_sps = self.get_all_pending_sps()
        if not pending_sps:
            print("   No SPs pending for optimization.")
            return {}

        by_server = {}
        for sp in pending_sps:
            by_server.setdefault(sp["db_server_name"], []).append(sp["sp_name"])
        print(f"\n   Total SPs  : {len(pending_sps)}")
        print(f"   DB Servers : {len(by_server)}")
        for server, names in by_server.items():
            print(f"     {server}: {len(names)} SP(s) -- {names}")

        print("\n[1] Building API session (Bearer-only)...")
        try:
            self._build_session()
        except Exception as exc:
            error_text = f"{type(exc).__name__}: {exc}\n{traceback.format_exc()}"
            print(f"   FATAL: cannot build session -- {exc}")
            log_pipeline_error(
                error_type='APPD_API_ERROR',
                error=error_text,
                sp_name='(AppD batch: session build)',
            )
            return {
                sp["sp_name"]: {
                    "file_path": None, "analysis_result": None, "error": str(exc)
                }
                for sp in pending_sps
            }

        results = {}
        for idx, sp in enumerate(pending_sps, 1):
            sp_name        = sp["sp_name"]
            db_server_name = sp["db_server_name"]
            app_name       = sp["app_name"]

            print(f"\n{'=' * 80}")
            print(f"[SP {idx}/{len(pending_sps)}] {sp_name}  "
                  f"(DB: {db_server_name} | App: {app_name})")
            print("=" * 80)

            analysis_result = None
            error_msg       = None
            try:
                xml_string = self._fetch_plan_via_rest_api(sp_name, db_server_name)
                if xml_string:
                    full_analysis = self._analyse_plan(xml_string, sp_name)
                    # ── Memory optimization: discard large XML immediately ──
                    # Plan XML can be 10-100MB for complex SPs. Delete the
                    # reference so Python's GC can reclaim memory before
                    # processing the next SP.
                    del xml_string
                    if full_analysis is not None:
                        # Compact: retain only the top-5 operation summaries
                        # that Stage 3 (Decision Gate) actually reads.
                        # Discards full statement texts, raw analysis dicts,
                        # and all intermediate data from AdvancedSQLPlanAnalyzer.
                        # Reduces per-SP footprint from ~500KB to ~3-5KB.
                        analysis_result = self._compact_analysis(full_analysis)
                        del full_analysis
                    else:
                        error_msg = "plan_analysis_failed"
                else:
                    error_msg = "plan_fetch_failed"
                    log_audit(
                        "PLAN_FETCH_FAIL",
                        sp_name=sp_name,
                        db_server_name=db_server_name,
                        message=(
                            "Plan not available (SQL MI without SSO cookies, or plan "
                            "handle evicted from SQL Server cache). Pipeline will "
                            "continue with SP code + table schemas only."
                        ),
                    )
            except Exception as exc:
                error_msg = f"{type(exc).__name__}: {exc}"
                error_text = f"{type(exc).__name__}: {exc}\n{traceback.format_exc()}"
                print(f"\n   ERROR for {sp_name}: {error_msg}")
                log_audit(
                    "PLAN_FETCH_FAIL",
                    sp_name=sp_name,
                    db_server_name=db_server_name,
                    message=f"Exception during plan fetch: {error_msg}",
                )
                log_pipeline_error(
                    error_type='APPD_API_ERROR',
                    error=error_text,
                    sp_name=sp_name,
                )
                traceback.print_exc()

            results[sp_name] = {
                "file_path":       None,
                "analysis_result": analysis_result,
                "error":           error_msg,
            }

        self._print_batch_summary(results, total=len(pending_sps))
        return results

    def _print_batch_summary(self, results, total):
        """Print a compact summary of the batch run outcome."""
        success = sum(1 for v in results.values() if v.get("analysis_result"))
        print(f"\n{'=' * 80}")
        print(f"BATCH SUMMARY: {success}/{total} analyzed  |  {total - success} skipped")
        print("=" * 80)
        for sp_name, res in results.items():
            tag = "OK  " if res.get("analysis_result") else f"SKIP ({res.get('error', '?')})"
            print(f"  {tag}  {sp_name}")
        print("=" * 80)


# ──────────────────────────────────────────────────────────────────────
# Standalone entry point
# ──────────────────────────────────────────────────────────────────────

def main():
    """Run the downloader for all pending SPs (batch mode)."""
    downloader = AppDExecutionPlanDownloader()
    results    = downloader.download_all_execution_plans()
    ok = sum(1 for v in results.values() if v.get("analysis_result"))
    print(f"\nDone. {ok}/{len(results)} SPs analyzed successfully.")


if __name__ == "__main__":
    main()
