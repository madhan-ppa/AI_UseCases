﻿import os
import sys
import requests
import time
import re
from collections import defaultdict
from datetime import datetime
from zoneinfo import ZoneInfo
import urllib3

_IST = ZoneInfo("Asia/Kolkata")

# Support both: running as a package (relative imports) and running standalone
try:
    from ..models import get_session, DB_SCHEMA
    from ..config import get_config
    from ..utils.audit_logger import log_pipeline_error
    from ..utils.http_session import build_http_session, RateLimiter
    from ..utils.input_validator import InputValidator, InputValidationError
except ImportError:
    _project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    if _project_root not in sys.path:
        sys.path.insert(0, _project_root)
    os.chdir(_project_root)
    from optimizer.models import get_session
    from optimizer.config import get_config
    from optimizer.utils.audit_logger import log_pipeline_error
    from optimizer.utils.http_session import build_http_session, RateLimiter
    from optimizer.utils.input_validator import InputValidator, InputValidationError

# In GKE set APPD_SSL_VERIFY=true (default). Set to false only when the AppD
# controller uses a corporate self-signed cert not in the system trust store.
_APPD_SSL_VERIFY = os.getenv('APPD_SSL_VERIFY', 'true').lower() not in ('false', '0', 'no')
if not _APPD_SSL_VERIFY:
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class ActiveAppSPFetcher:

    def __init__(self):
        config = get_config()

        self.config_db = config.DATABASE_PATH
        self.data_db = config.DATABASE_PATH

        self.controller_url = config.APPD_CONTROLLER_URL
        self.account_name = config.APPD_ACCOUNT_NAME
        self.token = config.APPD_API_TOKEN
        self.headers = {
            "Authorization": f"Bearer {self.token}",
            "Accept": "application/json"
        }
        self._session = build_http_session(verify_ssl=_APPD_SSL_VERIFY)
        self._rate_limiter = RateLimiter()

    # --------------------------------------------------
    # CONFIG
    # --------------------------------------------------
    def get_active_apps(self):
        """Fetch active apps directly from app_config table."""
        with get_session() as session:
            from sqlalchemy import text
            result = session.execute(
                text(
                    f'SELECT "Appd_AppID", app_name, "Query_Threshold", "Page_Execution_TimeinMillis" '
                    f'FROM "{DB_SCHEMA}".app_config WHERE is_active = 1'
                )
            )
            return result.fetchall()

    # --------------------------------------------------
    # SP NAME NORMALIZATION
    # --------------------------------------------------
    def _canonicalize_sp_name(self, raw_name: str) -> str:
        """
        Convert any AppDynamics SP representation to a canonical key.

        Canonical output:
            - "schema.proc" when schema exists
            - "proc" when schema is unavailable

        Handles formats like:
            EXEC dbo.proc @p=1
            execute [dbo].[proc] @p='x'
            [db].[schema].[proc]
            "schema"."proc"
            schema.proc
            proc
        """
        if not raw_name:
            return None

        s = raw_name.strip().rstrip(';')
        if not s:
            return None

        # Remove leading EXEC / EXECUTE and optional return variable assignment
        # Example: EXEC @rc = [dbo].[usp_name] @p=1
        s = re.sub(
            r"^\s*(?:exec(?:ute)?\s+)?(?:@[A-Za-z_][\w$#]*\s*=\s*)?",
            "",
            s,
            flags=re.IGNORECASE,
        ).strip()

        if not s:
            return None

        # Take only object token before params/whitespace/parentheses/comma
        token = re.split(r"[\s\(,]", s, maxsplit=1)[0].strip()
        token = token.rstrip(".;")
        if not token:
            return None

        # Remove SQL identifier wrappers
        token = token.replace('[', '').replace(']', '')
        token = token.replace('"', '').replace("`", '')
        token = token.strip().strip('.')
        if not token:
            return None

        parts = [p.strip() for p in token.split('.') if p and p.strip()]
        if not parts:
            return None

        # Use last two parts as schema.proc when available
        if len(parts) >= 2:
            schema = parts[-2]
            proc = parts[-1]
            canonical = f"{schema}.{proc}"
        else:
            canonical = parts[-1]

        # Keep only identifier-safe chars per segment
        segs = [re.sub(r"[^A-Za-z0-9_#$@]", "", p) for p in canonical.split('.')]
        segs = [p for p in segs if p]
        if not segs:
            return None

        # Prevent system/internal and non-proc tokens
        proc_name = segs[-1].lower()
        if proc_name.startswith('#') or proc_name in {
            'select', 'insert', 'update', 'delete', 'merge', 'with',
            'from', 'join', 'where', 'set', 'declare', 'begin', 'end',
            'waitfor', 'timeout', 'provider', 'server'
        }:
            return None

        if len(segs) >= 2:
            return f"{segs[-2]}.{segs[-1]}"
        return segs[-1]
 
    # --------------------------------------------------
    # DB
    # --------------------------------------------------
    # DB — upsert aggregated SPs directly into ado_defect_tracker
    # --------------------------------------------------
    def _upsert_to_tracker(self, app_id, app_name, sp_agg):
        """
        Upsert aggregated SPs into ado_defect_tracker.
        sp_agg: { sp_name: {"count": int, "last_timestamp": int} }
        Returns (inserted, updated) counts.
        """
        # ── Centralized server-side input validation (SSDLC control) ─────────
        try:
            app_id   = InputValidator.app_id(app_id)
            app_name = InputValidator.app_name(app_name)
        except InputValidationError as e:
            print(f"  [VALIDATION ERROR] Skipping app — {e}")
            log_pipeline_error(error_type='STAGE_ERROR', error=str(e),
                               app_name=str(app_name))
            return 0, 0   # skip cleanly — pipeline continues with next app
        # ─────────────────────────────────────────────────────────────────────

        now = datetime.now(_IST).strftime('%Y-%m-%d %H:%M:%S')

        # Canonicalize and merge variants before DB write:
        # e.g. [dbo].[usp_x], dbo.usp_x, usp_x -> dbo.usp_x / usp_x
        normalized_agg = defaultdict(lambda: {"count": 0, "last_timestamp": 0})
        dropped = 0
        for raw_sp_name, data in sp_agg.items():
            canonical_name = self._canonicalize_sp_name(raw_sp_name)
            if not canonical_name:
                dropped += 1
                continue
            normalized_agg[canonical_name]["count"] += data.get("count", 0)
            normalized_agg[canonical_name]["last_timestamp"] = max(
                normalized_agg[canonical_name]["last_timestamp"],
                data.get("last_timestamp", 0),
            )

        if dropped:
            print(f"  Normalization dropped {dropped} non-SP/invalid call(s)")

        inserted = updated = 0
        with get_session() as session:
            from sqlalchemy import text
            for sp_name, data in normalized_agg.items():
                # Check if record already exists
                existing = session.execute(
                    text(
                        f'SELECT sp_id FROM "{DB_SCHEMA}".ado_defect_tracker '
                        f'WHERE app_id = :app_id AND sp_name = :sp_name'
                    ),
                    {"app_id": app_id, "sp_name": sp_name},
                ).fetchone()

                if existing:
                    session.execute(
                        text(
                            f'UPDATE "{DB_SCHEMA}".ado_defect_tracker '
                            'SET occurrence_count = COALESCE(occurrence_count, 0) + :count, '
                            '    last_detected = :now, '
                            '    last_updated = :now '
                            'WHERE app_id = :app_id AND sp_name = :sp_name'
                        ),
                        {
                            "count": data["count"],
                            "now": now,
                            "app_id": app_id,
                            "sp_name": sp_name,
                        },
                    )
                    updated += 1
                else:
                    session.execute(
                        text(
                            f'INSERT INTO "{DB_SCHEMA}".ado_defect_tracker '
                            '(app_id, app_name, sp_name, occurrence_count, defect_id, defect_status, '
                            ' snooze_start_date, snooze_end_date, first_detected, last_detected, last_updated) '
                            'VALUES (:app_id, :app_name, :sp_name, :count, NULL, NULL, '
                            '        NULL, NULL, :now, :now, :now)'
                        ),
                        {
                            "app_id": app_id,
                            "app_name": app_name,
                            "sp_name": sp_name,
                            "count": data["count"],
                            "now": now,
                        },
                    )
                    inserted += 1
        return inserted, updated
 
    # --------------------------------------------------
    # SNAPSHOTS
    # --------------------------------------------------
    def fetch_snapshots(self, appd_app_id, app_name, page_time_threshold):
        """
        Fetch SLOW and VERY_SLOW transaction snapshots from AppDynamics.
        Uses numeric app ID for the REST API endpoint.
        Filters by user-experience (SLOW, VERY_SLOW) and minimum page execution time.
        """
        # requires no encoding.  The AppDynamics REST API accepts either the
        # numeric ID or the application name; using the bare ID is the safest
        # and most reliable form (no spaces, no encoding ambiguity).
        url = f"{self.controller_url}/controller/rest/applications/{appd_app_id} - {app_name}/request-snapshots"
        config = get_config()
        params = {
            "time-range-type": "BEFORE_NOW",
            "duration-in-mins": config.APPD_TIME_RANGE_MINS,
            "user-experience": config.APPD_EXPERIENCE_FILTER,
            "execution-time-in-milis": page_time_threshold,
            "need-props": "true",
            "need-exit-calls": "true",
            "output": "JSON"
        }

        try:
            self._rate_limiter.check_request()
            resp = self._session.get(   # CHANGED
                url,
                headers=self.headers,
                params=params,
                timeout=90
                # verify handled by session
            )

            if resp.status_code == 200:
                data = resp.json()
                if isinstance(data, list):
                    return data
                else:
                    print(f"  Unexpected response type: {type(data)}")
                    return []
            elif resp.status_code == 401:
                print(f"  API Error: HTTP 401 Unauthorized")
                print(f"  The APPD_API_TOKEN in .env is invalid or expired.")
                print(f"  Regenerate it from: AppDynamics → Settings → API Clients → Generate Token")
                print(f"  Then update APPD_API_TOKEN in .env file and re-run.")
                return []
            else:
                print(f"  API Error: HTTP {resp.status_code}")
                print(f"  Response: {resp.text[:500]}")
                return []

        except requests.exceptions.RequestException as e:
            import traceback as _tb
            error_text = f"{type(e).__name__}: {e}\n{_tb.format_exc()}"
            print(f"  API Request failed: {e}")
            log_pipeline_error(
                error_type='APPD_API_ERROR',
                error=error_text,
                app_id=appd_app_id,
                app_name=app_name,
            )
            return []
 
    # --------------------------------------------------
    # CLASSIFY DB CALL
    # --------------------------------------------------
    def classify_and_extract(self, detail: str, properties: list, exit_point_name: str):
        """
        Extract and classify database calls using AppDynamics' built-in classification.
        Falls back to pattern matching if properties are not available.
        
        Args:
            detail: The detailString from the exit call
            properties: List of property dicts from the exit call
            exit_point_name: The exitPointName (e.g., ADODOTNET, HTTP, WCF)
            
        Returns:
            Tuple of (procedure_or_query_name, call_type) or (None, None)
        """
        # FILTER: Only process database exit points (ADO.NET, JDBC, etc.)
        # Skip HTTP, WCF, Await, Connection Open, and other non-DB calls
        db_exit_points = ['ADODOTNET', 'JDBC', 'ADO', 'DOTNET', 'OLEDB', 'ODBC']
        if exit_point_name not in db_exit_points:
            return None, None
        
        d = detail.strip()
        
        # Skip connection strings and connection open calls
        if d.startswith("DATA SOURCE") or d.startswith("PROVIDER") or d.startswith("Server="):
            return None, None
        
        # First, check AppDynamics' Query Type property (most reliable)
        query_type = None
        if properties:
            for prop in properties:
                if prop.get("name") == "Query Type":
                    query_type = prop.get("value")
                    break
        
        # Handle based on AppD's classification
        if query_type == "Stored Procedure":
            sp_name = self._canonicalize_sp_name(d)
            return (sp_name, "STORED_PROCEDURE") if sp_name else (None, None)
        
        elif query_type == "Query":
            # AppD classifies some stored procedures as "Query" type
            # Check if it's an EXEC statement (stored procedure)
            if re.match(r"^\s*(exec|execute)\b", d, re.IGNORECASE):
                sp_name = self._canonicalize_sp_name(d)
                return (sp_name, "STORED_PROCEDURE") if sp_name else (None, None)
            # Otherwise treat as SQL query
            elif re.match(r"^\s*(select|insert|update|delete|merge|with)\b", d, re.IGNORECASE):
                return d, "SQL_QUERY"
        
        elif query_type == "Prepared Statement" or query_type == "SQL":
            # Check if it's a SQL query
            if re.match(r"^\s*(select|insert|update|delete|merge|with)\b", d, re.IGNORECASE):
                return d, "SQL_QUERY"
            # Could also be a stored procedure without EXEC
            elif not d.startswith("DATA SOURCE") and not d.startswith("PROVIDER"):
                sp_name = self._canonicalize_sp_name(d)
                return (sp_name, "STORED_PROCEDURE") if sp_name else (None, None)
        
        elif query_type == "Connection Open":
            # Skip connection open calls
            return None, None
        
        # Fallback: Pattern matching for cases without properties
        if not query_type:
            # Try to match stored procedure patterns (any prefix)
            sp_match = re.search(
                r"\b(exec\s+)?([a-zA-Z0-9_]+\.)?([a-zA-Z0-9_]+)",
                d,
                re.IGNORECASE
            )
            if sp_match and not re.match(r"^\s*(select|insert|update|delete|merge|with)\b", d, re.IGNORECASE):
                sp_name = self._canonicalize_sp_name(d)
                return (sp_name, "STORED_PROCEDURE") if sp_name else (None, None)
            
            # SQL Query
            if re.match(r"^\s*(select|insert|update|delete|merge|with)\b", d, re.IGNORECASE):
                return d, "SQL_QUERY"

        return None, None

    # --------------------------------------------------
    # MAIN
    # --------------------------------------------------
    def run(self):
        """Fetch slow SPs from AppD and upsert directly into ado_defect_tracker.
        Returns (total_inserted, total_updated) across all active apps.
        """
        active_apps = self.get_active_apps()
        print(f"Active apps to process: {len(active_apps)}")

        total_inserted = total_updated = 0

        for app_id, app_name, threshold_pct, page_time_threshold in active_apps:
          try:
            print(f"\n✓ Processing AppD App ID: {app_id} | Name: '{app_name}'")
            print(f"  Query Threshold={threshold_pct}% | Page Time Threshold={page_time_threshold}ms")
            print(f"  Filter: SLOW + VERY_SLOW transactions | Min page time: {page_time_threshold}ms")
            print(f"  API: {self.controller_url}/controller/rest/applications/{app_id} - {app_name}/request-snapshots")

            snapshots = self.fetch_snapshots(app_id, app_name, page_time_threshold)
            print(f"  Retrieved {len(snapshots)} snapshots from AppDynamics")

            # In-memory aggregation: sp_name -> {count, last_timestamp}
            sp_agg = defaultdict(lambda: {"count": 0, "last_timestamp": 0})

            snapshots_processed = db_calls_found = db_calls_filtered = 0

            for snap in snapshots:
                request_guid = snap.get("requestGUID")
                page_time    = snap.get("timeTakenInMilliSecs")
                timestamp    = snap.get("localStartTime") or 0

                if not request_guid or not page_time or page_time <= 0:
                    continue

                snapshots_processed += 1

                for call in snap.get("snapshotExitCalls", []):
                    query_time      = call.get("timeTakenInMillis")
                    detail          = call.get("detailString")
                    properties      = call.get("properties", [])
                    exit_point_name = call.get("exitPointName", "")

                    if not query_time or not detail:
                        continue

                    value, call_type = self.classify_and_extract(detail, properties, exit_point_name)
                    if value is None:
                        continue

                    db_calls_found += 1
                    execution_pct = (query_time / page_time) * 100

                    if threshold_pct is not None and execution_pct < threshold_pct:
                        db_calls_filtered += 1
                        continue

                    sp_agg[value]["count"] += 1
                    sp_agg[value]["last_timestamp"] = max(sp_agg[value]["last_timestamp"], timestamp)

            print(f"  Snapshots Processed      : {snapshots_processed}")
            print(f"  DB Calls Found           : {db_calls_found}")
            print(f"  DB Calls Filtered (<{threshold_pct}%): {db_calls_filtered}")
            print(f"  Unique SPs above threshold: {len(sp_agg)}")

            if sp_agg:
                inserted, updated = self._upsert_to_tracker(app_id, app_name, sp_agg)
                print(f"  Inserted: {inserted} new SPs | Updated: {updated} existing SPs")
                total_inserted += inserted
                total_updated  += updated

            time.sleep(1)

          except Exception as exc:
            import traceback as _tb
            error_text = f"{type(exc).__name__}: {exc}\n{_tb.format_exc()}"
            print(f"  [ERROR] App {app_id} ('{app_name}') failed \u2014 skipping. {error_text}")
            log_pipeline_error(
                error_type='APPD_API_ERROR',
                error=error_text,
                app_id=app_id,
                app_name=app_name,
            )

        print(f"\n✅ Total inserted: {total_inserted} | Total updated: {total_updated}")
        return total_inserted, total_updated


def fetch_slow_sps_for_all_active_apps():
    """Convenience wrapper — returns (inserted, updated) tuple."""
    return ActiveAppSPFetcher().run()


if __name__ == "__main__":
    ActiveAppSPFetcher().run()
 
