"""?
Decision Gate � SQL Optimization Workflow Orchestrator
 
Selects SPs from defect tracker using 8-state defect_status logic,
then runs the full optimization pipeline SP by SP.
 
defect_status gate rules:
    NULL        -> ALLOW  (first time seen)
    Closed      -> ALLOW  (fixed, re-enter next AppD cycle)
    Rejected    -> ALLOW  (business logic may now be correct, retry LLM)
    Failed      -> ALLOW  (pipeline crashed last run, retry)
    Deferred    -> ALLOW  only if today > snooze_end_date, else BLOCK
    Active      -> BLOCK  (ADO bug open, app team not started)
    InProgress  -> BLOCK  (app team working)
    Exempt      -> BLOCK  (closed as default functionality, exempt forever)
"""
 
import json
import os
import sys
import traceback
from collections import OrderedDict
from datetime import datetime
from zoneinfo import ZoneInfo

_IST = ZoneInfo("Asia/Kolkata")
 
try:
    from ..github_extractor.github_python_navigator import GitHubPythonNavigator
    from ..ai_optimizer.langchain_sql_optimizer import LangChainSQLOptimizer
    from ..ado_integration.ado_workitem_creator import ADOWorkItemCreator
    from ..models import get_session, DB_SCHEMA
    from ..config import get_config, get_gcp_secret
    from ..utils.audit_logger import log_audit, log_pipeline_error
    from ..utils.content_scanner import scan_report_content
except ImportError:
    _project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    if _project_root not in sys.path:
        sys.path.insert(0, _project_root)
    os.chdir(_project_root)
    from optimizer.github_extractor.github_python_navigator import GitHubPythonNavigator
    from optimizer.ai_optimizer.langchain_sql_optimizer import LangChainSQLOptimizer
    from optimizer.ado_integration.ado_workitem_creator import ADOWorkItemCreator
    from optimizer.models import get_session
    from optimizer.config import get_config, get_gcp_secret
    from optimizer.utils.audit_logger import log_audit, log_pipeline_error
    from optimizer.utils.content_scanner import scan_report_content
 
 
class DecisionGate:
    """
    Orchestrates end-to-end SQL optimization for SPs that pass the decision gate.
 
    WORKFLOW PER SP:
      1. GitHub extraction  � SP code + table schemas
      2. Execution plan     � from execution_plans/ folder (if available)
      3. LangChain optimization � 5-task sequential LLM system
      4. ADO work item      � User Story -> Bug -> Attachment
      5. Defect tracker     � update defect_id and defect_status
 
    On any exception: marks defect_status = 'Failed' with error details so
    the SP is automatically retried on the next pipeline run.
    """
 
    def __init__(self, github_token=None,
                 ado_org_url=None, ado_project=None, ado_pat_token=None,
                 is_test_ado=True, ado_base_url='https://devops.cognizant.com', env_region='DEV'):
        self.github_token = github_token
        self.ado_org_url = ado_org_url
        self.ado_project = ado_project
        self.ado_pat_token = ado_pat_token
        self.is_test_ado = is_test_ado
        self.ado_base_url = ado_base_url.rstrip('/')
        self.env_region = env_region.upper() if env_region else 'DEV'
        self.github_tokens_cache = {}
 
    def get_github_token_for_org(self, organization_name, app_id=None, app_name=None):
        """
        Return org-specific GitHub token from GCP Secret Manager.
 
        Secret name format: 5079_<<OrgName-spaces-as-hyphens>>_GitRepo
        Example: "HR Services IT Systems" ? "5079_HR-Services-IT-Systems_GitRepo"
 
        If the secret is NOT found: logs to error_log table and returns None.
        There is NO fallback to env vars or any other source.
        """
        if organization_name in self.github_tokens_cache:
            return self.github_tokens_cache[organization_name]
 
        normalized = organization_name.replace(' ', '-') if organization_name else ''
        secret_name = f"5079_{normalized}_GitRepo"
 
        token = get_gcp_secret(secret_name)
        if token:
            self.github_tokens_cache[organization_name] = token
            print(f"   [GCP SM] GitHub token retrieved for org '{organization_name}' (secret: {secret_name})")
            return token
 
        # Local mode (no GCP_PROJECT_ID): fall back to global github_token from .env
        if not os.getenv('GCP_PROJECT_ID'):
            token = self.github_token
            if token:
                print(f"   [LOCAL MODE] Using global GITHUB_TOKEN from .env for org '{organization_name}'")
                self.github_tokens_cache[organization_name] = token
                return token
 
        error_msg = (
            f"GCP Secret Manager secret '{secret_name}' not found in project "
            f"'{os.getenv('GCP_PROJECT_ID', '?')}'. "
            f"Cannot access GitHub for org '{organization_name}'. "
            f"Add the secret to GCP SM and redeploy."
        )
        print(f"   [SECRET ERROR] {error_msg}")
        log_pipeline_error(
            error_type='GITHUB_API_ERROR',
            error=error_msg,
            app_name=app_name or organization_name,
            app_id=app_id,
        )
        return None
 
    def run(self, process_all_sps=True, plan_results=None):
        """Main entry point � select eligible SPs and process them one by one."""
        print("\n" + "="*100)
        print("DECISION GATE � SQL OPTIMIZATION WORKFLOW")
        print("="*100)
 
        print("\n[STEP 1] Selecting SPs for Optimization...")
        print("-"*100)
        sps_to_process = self._select_sps_for_optimization()
 
        if not sps_to_process:
            print("   No SPs eligible for optimization at this time.")
            print("\n" + "="*100)
            print("DECISION GATE � COMPLETE (No work to do)")
            print("="*100)
            return
 
        if not process_all_sps:
            print("   Test mode: Processing only 1 SP")
            sps_to_process = sps_to_process[:1]
 
        self._process_sps_sequentially(sps_to_process, plan_results=plan_results or {})
 
        print("\n" + "="*100)
        print("DECISION GATE � WORKFLOW COMPLETE")
        print("="*100)
 
    def _select_sps_for_optimization(self):
        """
        Apply 8-state gate. Returns list of SP records that are eligible to process.
        Deferred SPs are allowed only if today is past their snooze_end_date.
        """
        today = datetime.now(_IST).strftime('%Y-%m-%d')
 
        from sqlalchemy import text
        with get_session() as session:
            result = session.execute(
                text(
                    f'SELECT adt.sp_id, adt.app_id, adt.app_name, adt.sp_name, '
                    f'       ac."Organization_Name", adt.occurrence_count, '
                    f'       adt.defect_id, adt.defect_status, adt.snooze_end_date, ac.repo_name '
                    f'FROM "{DB_SCHEMA}".ado_defect_tracker adt '
                    f'JOIN "{DB_SCHEMA}".app_config ac '
                    f'  ON adt.app_id = ac."Appd_AppID" AND adt.app_name = ac.app_name '
                    f'WHERE ac."Organization_Name" IS NOT NULL '
                    f'ORDER BY adt.occurrence_count DESC'
                )
            )
            rows = result.fetchall()
 
        eligible = []
        blocked_count = 0
 
        for row in rows:
            sp_id, app_id, app_name, sp_name, org_name, occ_count, defect_id, status, snooze_end, repo_name = row
 
            if status == 'Exempt':
                blocked_count += 1
                continue
 
            if status in ('Active', 'InProgress'):
                blocked_count += 1
                continue
 
            if status == 'Deferred':
                if snooze_end and today <= snooze_end:
                    blocked_count += 1
                    continue
 
            eligible.append(row)
 
        print(f"   Eligible: {len(eligible)} SP(s) | Blocked: {blocked_count} SP(s)")
        if eligible:
            for idx, sp in enumerate(eligible[:5], 1):
                sp_id, app_id, app_name, sp_name, org_name, occ_count, defect_id, status, snooze_end, repo_name = sp
                print(f"      {idx}. {sp_name} ({app_name}) � {occ_count} occurrences [status: {status or 'NULL'}]")
            if len(eligible) > 5:
                print(f"      ... and {len(eligible) - 5} more")
 
        return eligible
 
    def _process_sps_sequentially(self, sp_records, plan_results=None):
        """
        Process SPs grouped by app � fetch GitHub token and repo tree once per app,
        then process all SPs in that app before moving to the next.
        """
        plan_results = plan_results or {}
        total_sps = len(sp_records)
 
        apps_map = OrderedDict()
        for sp_record in sp_records:
            sp_id, app_id, app_name, sp_name, org_name, occ_count, defect_id, status, snooze_end, repo_name = sp_record
            key = (app_id, org_name, repo_name)
            if key not in apps_map:
                apps_map[key] = []
            apps_map[key].append(sp_record)
 
        sp_counter = 0
 
        for (app_id, org_name, repo_name), app_sps in apps_map.items():
            app_name = app_sps[0][2]
 
            from sqlalchemy import text as _text
            with get_session() as _s:
                _result = _s.execute(
                    _text(
                        f'SELECT * FROM "{DB_SCHEMA}".app_config '
                        f'WHERE "Appd_AppID" = :p_appd_app_id AND app_name = :p_app_name '
                        f'LIMIT 1'
                    ),
                    {"p_appd_app_id": app_id, "p_app_name": app_name},
                )
                _row = _result.fetchone()
                app_cfg = dict(zip(_result.keys(), _row)) if _row else None
 
            print(f"\n{'='*100}")
            print(f"APP: {app_name} | Org: {org_name} | Repo: {repo_name or 'N/A'} | SPs: {len(app_sps)}")
            print(f"{'='*100}")
 
            github_token = self.get_github_token_for_org(org_name, app_id=app_id, app_name=app_name)
            if not github_token:
                print(f"   Skipping {len(app_sps)} SP(s) for org '{org_name}' � GitHub secret not found in GCP SM.")
                continue
 
            github_navigator = GitHubPythonNavigator(
                github_token=github_token,
            )
 
            actual_org = org_name
            actual_repo = repo_name
 
            if not repo_name:
                print(f"   repo_name is NULL/empty in app_config � skipping {len(app_sps)} SP(s).")
                print(f"   FIX: set app_config.repo_name='<org>/<repo>' (or just '<repo>') for app_id={app_id}.")
                log_audit(
                    "REPO_MISSING",
                    sp_name="(app-level)",
                    message=f"app_config.repo_name is NULL for app '{app_name}' (app_id={app_id}); skipping {len(app_sps)} SP(s) rather than guessing the repo.",
                    app_id=app_id,
                    app_name=app_name,
                    org_name=org_name,
                    skipped_sp_count=len(app_sps),
                    skipped_sps=[r[3] for r in app_sps],
                )
                continue
 
            print(f"\n   Fetching repo tree for '{org_name}/{repo_name}'...")
            repo_tree = github_navigator.get_repo_tree_recursive(org_name, repo_name)
            if not repo_tree:
                print(f"   Could not fetch repo tree � skipping app.")
                log_audit(
                    "REPO_MISSING",
                    sp_name="(app-level)",
                    message=f"Repo tree fetch failed for '{org_name}/{repo_name}'; skipping {len(app_sps)} SP(s).",
                    app_id=app_id,
                    app_name=app_name,
                    org_name=org_name,
                    repo_name=repo_name,
                    skipped_sp_count=len(app_sps),
                )
                continue
            print(f"   Repo tree loaded: {len(repo_tree)} items (shared across all SPs in this app)")
 
            for sp_record in app_sps:
                sp_id, app_id, app_name, sp_name, org_name, occ_count, defect_id, status, snooze_end, repo_name = sp_record
                sp_counter += 1
 
                print(f"\n{'='*100}")
                print(f"SP {sp_counter}/{total_sps}: {sp_name}")
                print(f"App: {app_name} | Occurrences: {occ_count} | Previous status: {status or 'NULL'}")
                print(f"{'='*100}")
 
                self._process_single_sp(
                    sp_id=sp_id,
                    app_id=app_id,
                    app_name=app_name,
                    sp_name=sp_name,
                    org_name=actual_org,
                    repo_name=actual_repo,
                    occ_count=occ_count,
                    repo_tree=repo_tree,
                    github_navigator=github_navigator,
                    plan_results=plan_results,
                    app_cfg=app_cfg,
                )
 
    def _process_single_sp(self, sp_id, app_id, app_name, sp_name, org_name,
                            repo_name, occ_count, repo_tree, github_navigator,
                            plan_results=None, app_cfg=None):
        """Full pipeline for one SP.On any exception: marks defect_status='Failed' with error so it retries next run."""
        try:
            print(f"\n[Step 1/4] Extracting SP Code & Schemas from GitHub...")
            extraction_result = github_navigator.process_sp_with_direct_repo(
                org_name=org_name,
                repo_name=repo_name,
                repo_tree=repo_tree,
                sp_name=sp_name,
                app_name=app_name
            )
 
            if not extraction_result['success']:
                raise RuntimeError(f"GitHub extraction failed: {extraction_result.get('error', 'Unknown')}")
 
            sp_code = extraction_result['sp_code']
            table_schemas = extraction_result['table_schemas']
            safe_sp = sp_name.replace('[', '').replace(']', '').replace('.', '_')
            print(f"   SP code: {len(sp_code):,} chars | Schemas: {len(table_schemas)}")
 
            print(f"\n[Step 2/4] Checking Execution Plan...")
            pre_analysis = None
            if plan_results:
                pre_analysis = (plan_results.get(sp_name) or
                                plan_results.get(sp_name.upper()) or
                                plan_results.get(sp_name.lower()) or
                                next((v for k, v in plan_results.items()
                                      if k.upper() == sp_name.upper()), None))
                if pre_analysis:
                    pre_analysis = pre_analysis.get('analysis_result')
            execution_plan_text = self._get_execution_plan_text(
                sp_name, pre_computed_analysis=pre_analysis
            )

            print(f"\n[Step 3/4] Running LangChain Multi-Task Optimization...")
            optimizer = LangChainSQLOptimizer()
            optimization_result = optimizer.optimize_sql(
                sp_name=sp_name,
                sp_code=sp_code,
                table_schemas=table_schemas,
                execution_plan_analysis=execution_plan_text
            )
 
            # Check if optimization failed (no SQL code produced)
            if not optimization_result.get('success', True):
                error_msg = optimization_result.get('error', 'Unknown optimization error')
                print(f"   ? OPTIMIZATION FAILED: {error_msg}")
                self._mark_failed(sp_id, app_id, app_name, sp_name, error_msg)
                print(f"   Marked as Failed � skipping Bug creation, moving to next SP")
                return  # Skip Bug creation, continue to next SP
 
            report_content = optimization_result.get('result', '')
            if not report_content:
                report_content = str(optimization_result)
            timestamp = datetime.now(_IST).strftime('%Y-%m-%d %H:%M:%S')
            report_content = f"**Stored Procedure:** {sp_name}\n**Timestamp:** {timestamp}\n\n" + report_content
            report_filename = f"{safe_sp}_{datetime.now(_IST).strftime('%Y%m%d_%H%M%S')}.md"
            print(f"   Optimization complete � report: {len(report_content):,} chars (in-memory)")
 
            print(f"\n[Step 4/4] Creating ADO Work Item...")
 
            if self.env_region in ('DEV', 'SIT'):
                if not self.is_test_ado:
                    print(f"   [REGION ENFORCEMENT] ENV_REGION={self.env_region}: Skipping ADO bug creation in production ADO. Only allowed in test ADO.")
                    return
            if self.ado_org_url and self.ado_project and self.ado_pat_token:
                self._create_ado_work_items(
                    sp_id=sp_id,
                    sp_name=sp_name,
                    app_id=app_id,
                    app_name=app_name,
                    report_content=report_content,
                    report_filename=report_filename,
                    occurrence_count=occ_count,
                    app_cfg=app_cfg,
                )
            else:
                print("   ADO credentials not configured � skipping work item creation")
 
            self._clear_pipeline_error(sp_id)
            print(f"\n   COMPLETED: {sp_name}")
 
        except Exception as e:
            error_text = f"{type(e).__name__}: {str(e)}\n{traceback.format_exc()}"
            print(f"\n   FAILED: {sp_name} � {str(e)}")
            self._mark_failed(sp_id, app_id, app_name, sp_name, error_text)
 
    def _create_ado_work_items(self, sp_id, sp_name, app_id, app_name, report_content,
                                report_filename, occurrence_count,
                                app_cfg=None):
        """Create User Story -> Bug -> Attachment in ADO, then update defect tracker."""
        from urllib.parse import quote
 
        if self.env_region in ('DEV', 'SIT'):
            effective_org_url = self.ado_org_url
            effective_project = self.ado_project
            print(f"   [REGION: {self.env_region}] Using test ADO: {effective_org_url}/{effective_project}")
        else:
            if app_cfg is None or not (app_cfg.get('ado_collection') and app_cfg.get('ado_project')):
                print(f"   WARN: ENV_REGION=PROD but app_config.ado_collection/ado_project is NULL for '{app_name}' � falling back to test ADO.")
                effective_org_url = self.ado_org_url
                effective_project = self.ado_project
            else:
                effective_org_url = f"{self.ado_base_url}/{quote(app_cfg.get('ado_collection'), safe='')}"
                effective_project = app_cfg.get('ado_project')
                print(f"   [REGION: PROD] Using app_config ADO: {effective_org_url}/{effective_project}")
 
        area_path      = (app_cfg.get('ado_area_path')      if app_cfg else None) or effective_project
        iteration_path = (app_cfg.get('ado_iteration_path') if app_cfg else None) or effective_project
 
        print(f"   ADO Target: {'TEST' if self.is_test_ado else 'PROD'} | {effective_org_url}/{effective_project}")
 
        # Single shared ADO PAT token used across all environments (DEV/SIT/PROD)
        ado_token = get_gcp_secret('5079_ADO_PAT_TOKEN')
        if not ado_token:
            if not os.getenv('GCP_PROJECT_ID') and self.ado_pat_token:
                ado_token = self.ado_pat_token
                print(f"   [LOCAL MODE] Using global ADO_PAT_TOKEN from .env for app '{app_name}'")
            else:
                error_msg = "GCP Secret Manager secret '5079_ADO_PAT_TOKEN' not found. Cannot create ADO work item."
                print(f"   [SECRET ERROR] {error_msg}")
                log_pipeline_error(error_type='ADO_API_ERROR', error=error_msg, app_id=app_id, app_name=app_name)
                return
        print(f"   [GCP SM] ADO token retrieved from shared secret '5079_ADO_PAT_TOKEN'")
 
        ado_creator = ADOWorkItemCreator(
            ado_org_url=effective_org_url,
            ado_project=effective_project,
            ado_pat_token=ado_token
        )
 
        user_story_title = os.getenv('ADO_USER_STORY_NAME', 'AISQLOptimization_Suggestions')
        print(f"\n   [1/3] Finding/creating User Story: '{user_story_title}'...")
        user_story_id = ado_creator.create_user_story(
            title=user_story_title,
            area_path=area_path,
            iteration_path=iteration_path,
        )
 
        if not user_story_id:
            print("   Failed to create/find User Story")
            return
 
        print(f"   User Story ready: #{user_story_id}")

        # -- [2/3] Security scan BEFORE creating any ADO bug -----------------
        # If blocked (malware/injection detected): skip this SP entirely.
        # defect_id + defect_status stay NULL ? re-enters optimization queue next run.
        print(f"\n   [2/3] Scanning report content before ADO bug creation...")
        scan = scan_report_content(report_content, filename=report_filename)
        print(f"   {scan.summary()}")

        if scan.warnings:
            log_audit(
                'SECURITY_WARN',
                sp_name=sp_name,
                message=f"Report for '{sp_name}' passed scan with warnings � proceeding",
                filename=report_filename,
                warnings=scan.warnings,
            )

        if scan.blocked:
            log_audit(
                'SECURITY_BLOCKED',
                sp_name=sp_name,
                message=f"SP '{sp_name}' skipped � report failed security scan. defect_id/status left NULL for re-processing next run.",
                filename=report_filename,
                findings=scan.findings,
            )
            print(f"   [SECURITY] SP skipped � malware/injection detected in report. No ADO bug created.")
            print(f"   defect_id and defect_status remain NULL ? will re-optimize on next pipeline run.")
            return

        # -- [3/3] Scan passed — create Bug and attach report -----------------
        # Read existing history and reoptimization count to include in the bug description
        from sqlalchemy import text as _sql_text
        with get_session() as _hist_session:
            _hist_row = _hist_session.execute(
                _sql_text(
                    f'SELECT defect_id_history, reoptimization_count '
                    f'FROM "{DB_SCHEMA}".ado_defect_tracker '
                    f'WHERE sp_id = :sp_id'
                ),
                {"sp_id": sp_id},
            ).fetchone()
        prior_history      = _hist_row[0] if _hist_row else None
        prior_reopt_count  = (_hist_row[1] or 0) if _hist_row else 0

        optimization_details = {
            'optimized_sql': report_content,
            'usage': {'prompt_tokens': 'N/A', 'completion_tokens': 'N/A', 'total_tokens': 'N/A'},
            'occurrence_count': occurrence_count,
            'execution_plan_issues': f"Performance optimization for {sp_name} in {app_name}",
            'defect_id_history': prior_history,
            'reoptimization_count': prior_reopt_count,
        }
 
        print(f"\n   [3/3] Creating Bug under User Story #{user_story_id}...")
        bug_id = ado_creator.create_bug_under_user_story(
            user_story_id=user_story_id,
            sp_name=sp_name,
            app_name=app_name,
            optimization_details=optimization_details,
            area_path=area_path,
            iteration_path=iteration_path,
        )
 
        if not bug_id:
            print("   Failed to create Bug work item")
            return
 
        print(f"   Bug created: #{bug_id}")

        # -- Idempotency: persist bug ID to DB IMMEDIATELY after creation --
        # This prevents duplicate ADO bugs if the pipeline crashes between
        # bug creation and report attachment. On next run, the Decision Gate
        # will see defect_status='Active' and SKIP this SP (not re-create).
        # Attachment failure is non-critical � the bug exists in ADO either way.
        db_update_success = self._update_defect_tracker(sp_id, bug_id, "Active")
        
        if not db_update_success:
            print(f"   ??  Skipping report attachment � Bug #{bug_id} is orphaned (not tracked in DB)")
            print(f"   Manual action required: Link Bug #{bug_id} to sp_id={sp_id} or close orphaned Bug")
            return
        
        print(f"   Defect tracker updated: sp_id={sp_id} ? Bug #{bug_id} (Active)")
 
        print(f"\n   [3/3] Attaching report to Bug #{bug_id}...")
        ado_creator.attach_content_to_work_item(
            work_item_id=bug_id,
            file_content=report_content.encode('utf-8'),
            filename=report_filename
        )
 
        print(f"\n   ADO complete: User Story #{user_story_id} -> Bug #{bug_id}")
 
    def _update_defect_tracker(self, sp_id, work_item_id, work_item_status):
        """Set defect_id and defect_status after successful bug creation.
        
        Before overwriting defect_id, the previous value is prepended to
        defect_id_history as 'bug_id|date|status' (newest-to-oldest) so all
        historical Bug IDs are preserved with context across re-optimization cycles.
        reoptimization_count is also incremented on every call.

        Returns:
            bool: True if DB update succeeded, False if failed
        """
        from sqlalchemy import text
        try:
            with get_session() as session:
                # ── Step 1: read current defect_id, history, reopt count ──
                row = session.execute(
                    text(
                        f'SELECT defect_id, defect_id_history, reoptimization_count, defect_status '
                        f'FROM "{DB_SCHEMA}".ado_defect_tracker '
                        f'WHERE sp_id = :sp_id'
                    ),
                    {"sp_id": sp_id},
                ).fetchone()

                new_history = None
                current_reopt_count = 0
                if row:
                    old_defect_id    = row[0]
                    existing_history = row[1]
                    current_reopt_count = row[2] or 0
                    old_status       = row[3] or 'Unknown'
                    new_bug_str = str(work_item_id)

                    # Archive old bug ID only if it exists and differs from new one
                    if old_defect_id and old_defect_id != new_bug_str:
                        history_list = [x.strip() for x in existing_history.split(',') if x.strip()] \
                            if existing_history else []
                        # Build snapshot entry: "bug_id|closed_date|status"
                        closed_date = datetime.now(_IST).strftime('%Y-%m-%d')
                        snapshot = f"{old_defect_id}|{closed_date}|{old_status}"
                        # Prepend (newest-to-oldest) with deduplication by bug_id
                        existing_ids = {e.split('|')[0] for e in history_list}
                        if old_defect_id not in existing_ids:
                            history_list.insert(0, snapshot)
                        new_history = ','.join(history_list)
                    else:
                        new_history = existing_history  # nothing to archive yet

                # ── Step 2: write new defect_id, history, incremented count ─
                session.execute(
                    text(
                        f'UPDATE "{DB_SCHEMA}".ado_defect_tracker '
                        f'SET defect_id = :defect_id, '
                        f'    defect_id_history = CASE '
                        f'        WHEN :new_history IS NOT NULL THEN :new_history '
                        f'        ELSE defect_id_history END, '
                        f'    reoptimization_count = :reopt_count, '
                        f'    defect_status = :defect_status, '
                        f'    pipeline_error = NULL, '
                        f'    last_updated = :last_updated '
                        f'WHERE sp_id = :sp_id'
                    ),
                    {
                        "sp_id": sp_id,
                        "defect_id": str(work_item_id),
                        "new_history": new_history,
                        "reopt_count": current_reopt_count + 1,
                        "defect_status": work_item_status,
                        "last_updated": datetime.now(_IST).strftime('%Y-%m-%d %H:%M:%S'),
                    },
                )
            return True
        except Exception as e:
            import traceback
            error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
            print(f"   ? ERROR: Failed to update defect tracker (Bug #{work_item_id} is orphaned in ADO): {e}")
            log_pipeline_error(
                error_type='DB_UPDATE_ERROR',
                error=error_text,
                sp_id=sp_id,
            )
            # Mark as Failed in a separate transaction so it's tracked for manual cleanup
            try:
                with get_session() as retry_session:
                    retry_session.execute(
                        text(
                            f'UPDATE "{DB_SCHEMA}".ado_defect_tracker '
                            f'SET defect_status = :status, '
                            f'    pipeline_error = :pipeline_error, '
                            f'    last_updated = :last_updated '
                            f'WHERE sp_id = :sp_id'
                        ),
                        {
                            "sp_id": sp_id,
                            "status": 'Failed',
                            "pipeline_error": f"DB update failed after Bug #{work_item_id} creation: {error_text[:1900]}",
                            "last_updated": datetime.now(_IST).strftime('%Y-%m-%d %H:%M:%S'),
                        },
                    )
            except Exception as retry_err:
                print(f"   ? Could not mark as Failed: {retry_err}")
            return False
 
    def _mark_failed(self, sp_id, app_id, app_name, sp_name, error_text):
        """Mark SP as Failed in defect tracker AND write to central error_log."""
        from sqlalchemy import text
        try:
            with get_session() as session:
                session.execute(
                    text(
                        f'UPDATE "{DB_SCHEMA}".ado_defect_tracker '
                        f'SET defect_status = :status, '
                        f'    pipeline_error = :pipeline_error, '
                        f'    last_updated = :last_updated '
                        f'WHERE sp_id = :sp_id'
                    ),
                    {
                        "sp_id": sp_id,
                        "status": 'Failed',
                        "pipeline_error": error_text[:2000],
                        "last_updated": datetime.now(_IST).strftime('%Y-%m-%d %H:%M:%S'),
                    },
                )
        except Exception as db_err:
            print(f"   Could not mark SP as failed in DB: {db_err}")
        log_pipeline_error(
            error_type='SP_PIPELINE_ERROR',
            error=error_text,
            app_id=app_id,
            app_name=app_name,
            sp_id=sp_id,
            sp_name=sp_name,
        )
 
    def _clear_pipeline_error(self, sp_id):
        """Clear pipeline_error on successful run (cleanup from a previous failure)."""
        from sqlalchemy import text
        try:
            with get_session() as session:
                session.execute(
                    text(
                        f'UPDATE "{DB_SCHEMA}".ado_defect_tracker '
                        f'SET pipeline_error = NULL, '
                        f'    last_updated = :last_updated '
                        f'WHERE sp_id = :sp_id AND pipeline_error IS NOT NULL'
                    ),
                    {
                        "sp_id": sp_id,
                        "last_updated": datetime.now(_IST).strftime('%Y-%m-%d %H:%M:%S'),
                    },
                )
        except Exception:
            pass
 
    def _get_execution_plan_text(self, sp_name: str,
                                  pre_computed_analysis=None) -> str:
        """Return formatted execution plan text from Stage 2 in-memory results."""
        if pre_computed_analysis and isinstance(pre_computed_analysis, dict):
            if pre_computed_analysis.get('top_05_operations'):
                ops = pre_computed_analysis['top_05_operations']
                print(f"   Using in-memory plan analysis ({len(ops)} top operations)")
                return self._format_top5_for_ai(ops, False)
            if pre_computed_analysis.get('ai_prompt'):
                return pre_computed_analysis['ai_prompt']
 
        print(f"   No execution plan for '{sp_name}' � proceeding with SP code + schemas only")
        return "No execution plan available"
 
    def _format_top5_for_ai(self, top_operations: list, is_runtime_data: bool = True) -> str:
        """Format top 5 execution plan operations as text for the AI prompt."""
        if not top_operations:
            return "No performance operations identified in execution plan."
 
        if is_runtime_data:
            total_ms = sum(op.get('actual_elapsed_ms', 0) for op in top_operations)
            summary_lines = [
                "=== TOP 5 PERFORMANCE BOTTLENECKS (ACTUAL RUNTIME DATA) ===\n",
                f"Total Operations Analyzed: {len(top_operations)}",
                f"Total Elapsed Time: {total_ms / 1000:.2f} seconds\n"
            ]
        else:
            total_cost = sum(op.get('estimated_subtree_cost', 0) for op in top_operations)
            summary_lines = [
                "=== TOP 5 PERFORMANCE BOTTLENECKS (ESTIMATED COST DATA) ===\n",
                f"Total Operations Analyzed: {len(top_operations)}",
                f"Total Estimated Cost: {total_cost:.4f}\n"
            ]
 
        for i, op in enumerate(top_operations, 1):
            summary_lines.append(f"\n{i}. RANK {op['rank']} - Statement {op['statement_id']}, Node {op['node_id']}")
            summary_lines.append(f"   Operator: {op['operator_type']}")
 
            if is_runtime_data:
                summary_lines.append(f"   Time: {op.get('actual_elapsed_ms', 0):,}ms")
                summary_lines.append(f"   CPU: {op.get('actual_cpu_ms', 0):,}ms")
                summary_lines.append(f"   Rows: {op.get('actual_rows', 0):,}")
                summary_lines.append(f"   Executions: {op.get('actual_executions', 0):,}")
                summary_lines.append(f"   Logical Reads: {op.get('actual_logical_reads', 0):,}")
                summary_lines.append(f"   Physical Reads: {op.get('actual_physical_reads', 0):,}")
            else:
                summary_lines.append(f"   Estimated Cost: {op.get('estimated_subtree_cost', 0):.4f}")
                summary_lines.append(f"   Estimated Rows: {op.get('estimated_rows', 0):,}")
                summary_lines.append(f"   Estimated Executions: {op.get('estimated_executions', 1):,}")
 
            stmt_text = op.get('statement_text', '').replace('&#xD;&#xA;', ' ').replace('\n', ' ')
            summary_lines.append(f"   Query: {stmt_text}")
 
        return "\n".join(summary_lines)
 
 
def main():
    config = get_config()
    agent = DecisionGate(
        github_token=config.GITHUB_TOKEN,
        ado_org_url=config.ADO_ORG_URL,
        ado_project=config.ADO_PROJECT,
        ado_pat_token=config.ADO_PAT_TOKEN,
        is_test_ado=config.IS_TEST_ADO,
        ado_base_url=getattr(config, 'ADO_BASE_URL', 'https://devops.cognizant.com'),
        env_region=getattr(config, 'ENV_REGION', 'DEV')
    )
    agent.run()
 
 
if __name__ == "__main__":
    main()
