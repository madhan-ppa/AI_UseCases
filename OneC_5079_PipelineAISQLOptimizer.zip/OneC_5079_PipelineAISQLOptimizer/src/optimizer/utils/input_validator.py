"""
Centralized Input Validator — SSDLC Control (Input Validation & Encoding)

All input validation and output encoding for the pipeline is declared here.
This module is the single centralized strategy required by the Secure SDLC
input validation control.

Architecture
------------
  Validation methods  — raise InputValidationError on failure, return the
                        cleaned/cast value on success. Call these at the
                        earliest point untrusted data enters the pipeline
                        (e.g. AppDynamics API response → _upsert_to_tracker).

  Encoding methods    — always return a safe string, never raise. Call these
                        immediately before data is written into an interpreted
                        environment (HTML, URL, WIQL, XML).

Interpreted environments covered
---------------------------------
  encode_for_html()   → ADO Bug HTML description  (XSS protection)
  encode_for_url()    → HTTP URL path segments     (URL/path injection)
  encode_for_wiql()   → ADO WIQL query strings     (WIQL injection)
  XML chars stripped  → ADO XML-based API title    (XML injection)
                        (handled inline via re.sub in ado_workitem_creator.py)

Usage
-----
    from optimizer.utils.input_validator import InputValidator, InputValidationError

    # Validate untrusted input at pipeline entry point:
    app_id   = InputValidator.app_id(raw_id)
    app_name = InputValidator.app_name(raw_name)

    # Encode before writing to interpreted environments:
    safe_html = InputValidator.encode_for_html(sp_name)
    safe_url  = InputValidator.encode_for_url(app_segment)
    safe_wiql = InputValidator.encode_for_wiql(title)
"""

import html
from urllib.parse import quote


class InputValidationError(ValueError):
    """
    Raised when an input value fails server-side validation.
    Callers should catch this, log via log_pipeline_error(), and skip
    the offending record — never crash the pipeline.
    """
    pass


class InputValidator:
    """
    Centralized server-side input validation and output encoding.

    All methods are static — no instance needed.

    Validation methods  raise InputValidationError on failure.
    Encoding  methods   always return a safe string, never raise.
    """

    # ────────────────────────────────────────────────────────────────────────
    # VALIDATION METHODS
    # ────────────────────────────────────────────────────────────────────────

    @staticmethod
    def app_id(value) -> int:
        """
        Validate app_id — must be a positive integer.

        Accepts int or string representation of an integer.
        Raises InputValidationError if not a positive integer.

        Example:
            app_id = InputValidator.app_id(raw_id)   # raises if invalid
        """
        try:
            v = int(value)
        except (TypeError, ValueError):
            raise InputValidationError(
                f"app_id must be an integer, got {value!r}"
            )
        if v <= 0:
            raise InputValidationError(
                f"app_id must be positive, got {v}"
            )
        return v

    @staticmethod
    def app_name(value: str) -> str:
        """
        Validate app_name — non-empty printable string, max 255 characters.

        Strips leading/trailing whitespace.
        Raises InputValidationError if empty or too long.

        Example:
            app_name = InputValidator.app_name(raw_name)   # raises if invalid
        """
        if not isinstance(value, str) or not value.strip():
            raise InputValidationError(
                f"app_name must be a non-empty string, got {value!r}"
            )
        v = value.strip()
        if len(v) > 255:
            raise InputValidationError(
                f"app_name too long: {len(v)} chars (max 255)"
            )
        return v

    @staticmethod
    def url(value: str, field_name: str = 'url') -> str:
        """
        Validate a URL — must be non-empty and start with https://.

        Raises InputValidationError if value is not a valid HTTPS URL.

        Example:
            safe_url = InputValidator.url(controller_url, 'APPD_CONTROLLER_URL')
        """
        if not isinstance(value, str) or not value.strip():
            raise InputValidationError(
                f"{field_name} must be a non-empty string, got {value!r}"
            )
        v = value.strip()
        if not v.startswith('https://'):
            raise InputValidationError(
                f"{field_name} must start with https://, got {v!r}"
            )
        return v

    @staticmethod
    def positive_int(value, field_name: str = 'value') -> int:
        """
        Validate that value is a positive integer.

        Raises InputValidationError if not a positive integer.
        """
        try:
            v = int(value)
        except (TypeError, ValueError):
            raise InputValidationError(
                f"{field_name} must be an integer, got {value!r}"
            )
        if v <= 0:
            raise InputValidationError(
                f"{field_name} must be positive, got {v}"
            )
        return v

    @staticmethod
    def non_empty_string(value, field_name: str = 'value', max_len: int = 1024) -> str:
        """
        Validate that value is a non-empty string within max_len characters.

        Strips leading/trailing whitespace.
        Raises InputValidationError if empty or too long.
        """
        if not isinstance(value, str) or not value.strip():
            raise InputValidationError(
                f"{field_name} must be a non-empty string, got {value!r}"
            )
        v = value.strip()
        if len(v) > max_len:
            raise InputValidationError(
                f"{field_name} too long: {len(v)} chars (max {max_len})"
            )
        return v

    # ────────────────────────────────────────────────────────────────────────
    # ENCODING METHODS
    # These never raise — they always return a safe string.
    # ────────────────────────────────────────────────────────────────────────

    @staticmethod
    def encode_for_html(value: str) -> str:
        """
        HTML-encode a value before embedding in an HTML environment.

        Converts:  &  →  &amp;
                   <  →  &lt;
                   >  →  &gt;
                   "  →  &quot;
                   '  →  &#x27;

        Use before: ADO Bug HTML description, any HTML field sent to ADO.
        Protects against: XSS (Cross-Site Scripting).

        Example:
            f"<strong>{InputValidator.encode_for_html(sp_name)}</strong>"
        """
        return html.escape(str(value), quote=True)

    @staticmethod
    def encode_for_url(value: str) -> str:
        """
        URL-encode a value before embedding in a URL path segment.

        Percent-encodes all characters except letters, digits, and _ . - ~
        Spaces → %20,  / → %2F,  & → %26,  # → %23,  ? → %3F

        Use before: Any value placed in an HTTP URL path segment.
        Protects against: URL injection, path traversal.

        Example:
            segment = InputValidator.encode_for_url(f"{app_id} - {app_name}")
            url = f"{base_url}/applications/{segment}/request-snapshots"
        """
        return quote(str(value), safe='')

    @staticmethod
    def encode_for_wiql(value: str) -> str:
        """
        Escape single quotes before embedding a value in a WIQL query string.

        WIQL uses single-quoted string literals. Doubling a single quote ('')
        is the standard WIQL escape — identical to SQL string escaping.

        Use before: Any value placed inside a WIQL query string literal.
        Protects against: WIQL injection (equivalent to SQL injection in ADO).

        Example:
            safe = InputValidator.encode_for_wiql(title)
            query = f"... AND [System.Title] = '{safe}'"
        """
        return str(value).replace("'", "''")
