﻿"""
Audit Logger — Records Uncertain / Skipped / Overflow Events

When the pipeline encounters data that doesn't meet strict-match criteria
or hits a provider limit (e.g. AI response truncated due to max_tokens),
the event is logged here AND the SP/operation is skipped or recovered
rather than silently producing wrong data.

Log file: <project_root>/logs/audit.log
   (the logs/ directory is auto-created on first write)

Format: ISO timestamp | category | sp_name | message | details(json)

Categories:
  DB_AMBIGUOUS         : multiple DB servers matched the hostname
  DB_NOT_FOUND         : no DB server matched the hostname
  SP_NOT_FOUND         : SP name not found in AppD queryListData
  SP_AMBIGUOUS         : SP name matched in a comment but no CREATE PROCEDURE
  REPO_MISSING         : app_config.repo_name is NULL/empty
  GITHUB_SP_NOT_FOUND  : SP .sql file genuinely absent from GitHub repo
                         (all folders, all name formats checked)
  PLAN_MISSING         : no cached execution plan available for SP
  PLAN_FETCH_FAIL      : plan fetch returned empty/error
  PLAN_SKIPPED         : Stage 3 skipped via APPD_SKIP_PLAN_FETCH=true
  TOKEN_OVERFLOW       : an AI request hit max_tokens — output was truncated
                          (response may be incomplete / repaired)
  PROMPT_LARGE         : an AI request prompt exceeded a soft-warning size
  SECURITY_BLOCKED     : AI report content failed security scan — attachment suppressed,
                          ADO bug still created 
  SECURITY_WARN        : AI report content passed scan but has low-severity findings —
                          attachment proceeds 
  GENERIC              : any other uncertainty
"""

import json
import os
from datetime import datetime
from zoneinfo import ZoneInfo
from threading import Lock

_IST = ZoneInfo("Asia/Kolkata")

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_LOGS_DIR    = os.path.join(_PROJECT_ROOT, "logs")
_AUDIT_LOG   = os.path.join(_LOGS_DIR, "audit.log")
_LOCK = Lock()

# In GKE set AUDIT_LOG_TO_STDOUT=true so audit entries go to container stdout
# (picked up by Cloud Logging) instead of writing to a file on the pod's filesystem.
_LOG_TO_STDOUT = os.getenv('AUDIT_LOG_TO_STDOUT', 'false').lower() == 'true'


def log_audit(category: str, sp_name: str, message: str, **details) -> None:
    """
    Append an audit entry. Categories: see module docstring.

    Always safe — never raises. Caller can pass arbitrary keyword
    `details` which are JSON-serialised into the line.
    """
    try:
        ts = datetime.now(_IST).strftime("%Y-%m-%dT%H:%M:%S IST")
        details_json = json.dumps(details, default=str) if details else "{}"
        line = f"{ts} | {category} | {sp_name} | {message} | {details_json}\n"
        with _LOCK:
            if _LOG_TO_STDOUT:
                print(line, end='', flush=True)
            else:
                os.makedirs(_LOGS_DIR, exist_ok=True)
                with open(_AUDIT_LOG, "a", encoding="utf-8") as f:
                    f.write(line)
    except Exception as e:
        # Audit log must never crash the pipeline
        print(f"[audit-logger] Could not write audit entry: {e}")


def get_audit_log_path() -> str:
    """Return the path to the current audit log file."""
    return _AUDIT_LOG


def get_logs_dir() -> str:
    """Return the path to the logs/ directory."""
    return _LOGS_DIR


# ---------------------------------------------------------------------------
# Pipeline error log — writes to the error_log DB table
# ---------------------------------------------------------------------------

def log_pipeline_error(
    error_type: str,
    error: str,
    app_id: int = None,
    app_name: str = None,
    sp_id: int = None,
    sp_name: str = None,
) -> None:
    """
    Persist a pipeline error to the error_log DB table.
    Always safe — never raises, so it can be called freely inside except blocks.

    error_type constants (use one):
        STAGE_ERROR       - entire pipeline stage failed
        SP_PIPELINE_ERROR - individual SP failed in Stage 3
        APPD_API_ERROR    - AppDynamics API error (Stage 1 / Stage 2)
        GITHUB_API_ERROR  - GitHub API error
        ADO_API_ERROR     - Azure DevOps API error
        LLM_API_ERROR     - LangChain / OpenAI / Claude API error
        DB_ERROR          - database operation failed
    """
    try:
        from optimizer.models import get_session, DB_SCHEMA  # local import avoids circular deps
        from sqlalchemy import text
        now = datetime.now(_IST).strftime('%Y-%m-%d %H:%M:%S IST')
        with get_session() as session:
            session.execute(
                text(
                    f'INSERT INTO "{DB_SCHEMA}".error_log '
                    '(app_id, app_name, sp_id, sp_name, error_type, error, datewithtimestamp) '
                    'VALUES (:app_id, :app_name, :sp_id, :sp_name, :error_type, :error, :datewithtimestamp)'
                ),
                {
                    "app_id": app_id,
                    "app_name": app_name,
                    "sp_id": sp_id,
                    "sp_name": sp_name,
                    "error_type": error_type,
                    "error": error[:4000],   # cap at 4 KB — enough for full traceback
                    "datewithtimestamp": now,
                },
            )
    except Exception as exc:
        # Must never crash the caller
        print(f"[error-log] Could not write to error_log table: {exc}")
