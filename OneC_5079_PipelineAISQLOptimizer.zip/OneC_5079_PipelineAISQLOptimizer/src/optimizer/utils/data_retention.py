﻿"""
Data Retention — Archive and purge stale records from error_log table.

Active-table retention (rows moved to error_log_archive):
    PROD       → 180 days  (set ERROR_LOG_RETENTION_DAYS=180 in PROD VG)
    DEV / SIT  → 90 days   (set ERROR_LOG_RETENTION_DAYS=90  in DEV/SIT VG)

Archive-table retention (rows hard-deleted from error_log_archive):
    PROD       → 730 days  (set ERROR_LOG_ARCHIVE_RETENTION_DAYS=730 in PROD VG)
    DEV / SIT  → 90 days   (set ERROR_LOG_ARCHIVE_RETENTION_DAYS=90  in DEV/SIT VG)

Flow:
    1. Rows older than the active retention period are INSERT-selected into
       error_log_archive (with an archived_at timestamp), then deleted from
       error_log.
    2. Rows in error_log_archive older than the archive retention period are
       hard-deleted.

Called once at pipeline startup (before Stage 1) so that the error_log table
does not grow unbounded across daily cron runs.
"""

import os
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from sqlalchemy import text

from optimizer.models import get_session, DB_SCHEMA

_IST = ZoneInfo("Asia/Kolkata")

# ── Retention configuration ──────────────────────────────────────────────────
_ENV_REGION = os.getenv('ENV_REGION', 'DEV').upper().strip()

# How long rows stay in the live error_log table before being archived.
# Set this VG variable per environment:
#   PROD    → 180  |  DEV / SIT → 90
_ACTIVE_RETENTION_DAYS = int(os.getenv('ERROR_LOG_RETENTION_DAYS', '90'))

# How long archived rows stay in error_log_archive before hard-delete.
# Set this VG variable per environment:
#   PROD    → 730  |  DEV / SIT → 90
_ARCHIVE_RETENTION_DAYS = int(os.getenv('ERROR_LOG_ARCHIVE_RETENTION_DAYS', '90'))


def purge_expired_error_logs() -> int:
    """
    Archive error_log rows older than the active retention period into
    error_log_archive, then hard-delete rows from error_log_archive that
    have exceeded the archive retention period.

    Returns the number of rows moved to archive, or -1 if an error occurred.
    This function NEVER raises — pipeline must not fail due to housekeeping.
    """
    try:
        active_days   = _ACTIVE_RETENTION_DAYS
        archive_days  = _ARCHIVE_RETENTION_DAYS
        now_str       = datetime.now(_IST).strftime('%Y-%m-%d %H:%M:%S IST')
        active_cutoff = (datetime.now(_IST) - timedelta(days=active_days)).strftime('%Y-%m-%d %H:%M:%S IST')
        archive_cutoff= (datetime.now(_IST) - timedelta(days=archive_days)).strftime('%Y-%m-%d %H:%M:%S IST')

        with get_session() as session:

            # ── Step 1: Move expired error_log rows → error_log_archive ──────
            archive_result = session.execute(
                text(
                    f'INSERT INTO "{DB_SCHEMA}".error_log_archive '
                    '    (id, app_id, app_name, sp_id, sp_name, error_type, error, datewithtimestamp, archived_at) '
                    f'SELECT id, app_id, app_name, sp_id, sp_name, error_type, error, datewithtimestamp, :now '
                    f'FROM "{DB_SCHEMA}".error_log '
                    'WHERE datewithtimestamp < :cutoff '
                    'ON CONFLICT (id) DO NOTHING'
                ),
                {"cutoff": active_cutoff, "now": now_str},
            )
            archived = archive_result.rowcount or 0

            # ── Step 2: Delete those rows from the live error_log table ───────
            delete_result = session.execute(
                text(
                    f'DELETE FROM "{DB_SCHEMA}".error_log '
                    'WHERE datewithtimestamp < :cutoff'
                ),
                {"cutoff": active_cutoff},
            )
            deleted = delete_result.rowcount or 0

            # ── Step 3: Hard-delete expired rows from error_log_archive ───────
            purge_result = session.execute(
                text(
                    f'DELETE FROM "{DB_SCHEMA}".error_log_archive '
                    'WHERE archived_at < :cutoff'
                ),
                {"cutoff": archive_cutoff},
            )
            purged = purge_result.rowcount or 0

        # ── Logging ───────────────────────────────────────────────────────────
        if archived > 0:
            print(f"[DATA RETENTION] Archived {archived} error_log row(s) older than {active_days} days → error_log_archive (ENV_REGION={_ENV_REGION}).")
        else:
            print(f"[DATA RETENTION] No error_log rows to archive (active retention={active_days} days, ENV_REGION={_ENV_REGION}).")

        if purged > 0:
            print(f"[DATA RETENTION] Purged {purged} error_log_archive row(s) older than {archive_days} days (ENV_REGION={_ENV_REGION}).")
        else:
            print(f"[DATA RETENTION] No expired error_log_archive rows to purge (archive retention={archive_days} days, ENV_REGION={_ENV_REGION}).")

        return archived

    except Exception as exc:
        # Housekeeping must never crash the pipeline
        print(f"[DATA RETENTION ERROR] Could not process error_log retention: {exc}")
        return -1
