"""
==================
Self-contained security scanner for AI-generated report content.

Stdlib ONLY — no external packages required.
Called before any AI-generated text is uploaded to ADO as an attachment.
The content is NEVER modified — the caller decides what to do based on ScanResult.

Checks
------
BLOCK-level  (report attachment is suppressed, ADO bug still created):
  B0  Content size > 4 MB
  B1  Null bytes (\\x00) — binary injection indicator
  B2  EICAR antivirus test string
  B3  Unicode directional-override characters (Trojan Source / text-direction spoofing)
  B4  Dangerous HTML tags (<script>, <iframe>, <object>, <embed>, <form>, <svg>, <meta>)
  B4b HTML inline event-handler attributes (onclick=", onerror=", onload=", …)
       NOTE: requires quotes after = to avoid false positives on SQL like ONLINE = ON
  B5  Dangerous URI schemes in markdown links (javascript:, vbscript:, data:text/html)
  B6  Embedded data:base64 URI in markdown link or HTML src/href attribute

WARN-level  (attachment proceeds, warning is logged):
  W1  Zero-width / invisible Unicode chars (steganography / homoglyph attack)
  W2  Lines exceeding 10 000 characters (buffer-overflow bait)
  W3  Non-whitespace control characters (hidden instructions)
  W4  Non-ASCII character ratio > 40 % (encoding attack)
  W5  Prompt-injection markers in AI output (jailbreak artefacts leaking into response)
"""

import os
import re
import unicodedata
from dataclasses import dataclass, field
from typing import List

# ── EICAR test string — split across two literals so this source file itself
#    does not trigger a real AV scanner.
_EICAR_P1 = r"X5O!P%@AP[4\PZX54(P^)7CC)7}$"
_EICAR_P2 = "EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*"
EICAR_STRING = _EICAR_P1 + _EICAR_P2

# ── Unicode directional-override codepoints (Trojan Source — CVE-2021-42574)
_DIR_OVERRIDES = frozenset({
    '\u202a', '\u202b', '\u202c', '\u202d', '\u202e',   # LRE LRO PDF RLO RLE
    '\u2066', '\u2067', '\u2068', '\u2069',              # LRI RLI FSI PDI
    '\u200e', '\u200f',                                  # LRM RLM
})

# ── Zero-width / invisible codepoints
_ZERO_WIDTH = frozenset({
    '\u200b',  # ZERO WIDTH SPACE
    '\u200c',  # ZERO WIDTH NON-JOINER
    '\u200d',  # ZERO WIDTH JOINER
    '\ufeff',  # BOM / ZERO WIDTH NO-BREAK SPACE
    '\u2060',  # WORD JOINER
    '\u00ad',  # SOFT HYPHEN
})

# ── Dangerous URI schemes inside markdown links: [text](javascript:...) etc.
_DANGEROUS_URI_RE = re.compile(
    r'\]\s*\(\s*(javascript|vbscript|data\s*:\s*text/html|data\s*:\s*application)\s*:',
    re.IGNORECASE,
)

# ── HTML tags that must never appear in a SQL optimisation markdown report
#    Exception: matches inside fenced code blocks (```sql ... ```) are skipped —
#    LLMs legitimately include XML-string SQL like SET @x='<meta>val</meta>'
#    inside code blocks. Outside code blocks, these tags are genuine XSS risk.
_HTML_TAG_RE = re.compile(
    r'<\s*(script|iframe|object|embed|form|svg|meta|link)\b',
    re.IGNORECASE,
)
_CODE_BLOCK_RE = re.compile(r'```[\w]*\n.*?```', re.S)   # fenced code blocks

# ── Inline HTML event handlers (onclick=", onerror=", onload=", …)
#    Requires a quote after = to avoid false positives on SQL like:
#    CREATE INDEX ... WITH (ONLINE = ON)  or  SET NOCOUNT ON
_HTML_EVENT_RE = re.compile(r'\bon\w{2,20}\s*=\s*["\']', re.IGNORECASE)

# ── data: base64 URI — anchored to markdown link/image syntax and HTML src/href
#    Avoids false positives where LLM mentions base64 encoding in plain text.
#    Only fires if the URI appears as an actual link target or HTML attribute value.
_DATA_B64_RE = re.compile(
    r'(?:'
    r'\]\s*\(\s*data:[^;\s]{1,50};base64,'          # markdown link: [text](data:...;base64,
    r'|src\s*=\s*["\']data:[^;\s]{1,50};base64,'    # HTML src="data:...;base64,
    r'|href\s*=\s*["\']data:[^;\s]{1,50};base64,'   # HTML href="data:...;base64,
    r')',
    re.IGNORECASE,
)

# ── Prompt-injection / jailbreak artefacts leaking into AI output
_PROMPT_INJ_RE = re.compile(
    r'(ignore\s+(all\s+)?(previous|above|prior)\s+instructions?'
    r'|system\s*prompt\s*override'
    r'|<\|im_start\|>\s*system'
    r'|<\|im_end\|>'
    r'|\[INST\]\s'
    r'|###\s*NEW\s+INSTRUCTIONS?'
    r'|you\s+are\s+now\s+DAN'
    r'|disregard\s+(all\s+)?previous\s+instructions)',
    re.IGNORECASE,
)

# ── Limits — sourced from VG environment variables with safe local defaults
MAX_CONTENT_BYTES   = int(os.getenv('MAX_CONTENT_BYTES',   str(4 * 1024 * 1024)))
MAX_LINE_LENGTH     = int(os.getenv('MAX_LINE_LENGTH',     '10000'))
MAX_NON_ASCII_RATIO = float(os.getenv('MAX_NON_ASCII_RATIO', '0.40'))


@dataclass
class ScanResult:
    """Immutable result of a content scan.  Content is NEVER modified."""
    passed:   bool = True
    blocked:  bool = False
    findings: List[str] = field(default_factory=list)   # BLOCK-level
    warnings: List[str] = field(default_factory=list)   # WARN-level (attach OK)

    def summary(self) -> str:
        if self.blocked:
            status = "BLOCKED"
        elif self.warnings:
            status = "PASSED WITH WARNINGS"
        else:
            status = "CLEAN"
        lines = [f"Security scan: {status}"]
        for f in self.findings:
            lines.append(f"  [BLOCK] {f}")
        for w in self.warnings:
            lines.append(f"  [WARN]  {w}")
        return "\n".join(lines)


def scan_report_content(content: str, filename: str = "report.md") -> ScanResult:
    """
    Scan AI-generated report content for security threats.

    Parameters
    ----------
    content  : Raw report string (markdown). Never modified.
    filename : Used in log messages for context only.

    Returns
    -------
    ScanResult
        .blocked == True  → caller must NOT attach the file to ADO.
        .warnings         → informational; attachment is still allowed.
    """
    result = ScanResult()

    # ── B0: Content size ────────────────────────────────────────────
    byte_len = len(content.encode('utf-8', errors='replace'))
    if byte_len > MAX_CONTENT_BYTES:
        result.findings.append(
            f"B0 Content size {byte_len:,} bytes exceeds {MAX_CONTENT_BYTES:,} byte limit"
        )

    # ── B1: Null bytes ───────────────────────────────────────────────
    if '\x00' in content:
        result.findings.append(
            f"B1 Null bytes detected ({content.count(chr(0))} occurrences) — binary injection"
        )

    # ── B2: EICAR test string ────────────────────────────────────────
    if EICAR_STRING in content:
        result.findings.append("B2 EICAR antivirus test string found in content")

    # ── B3: Unicode directional overrides ───────────────────────────
    found_dir = [ch for ch in content if ch in _DIR_OVERRIDES]
    if found_dir:
        codes = ', '.join(f"U+{ord(c):04X}" for c in sorted(set(found_dir)))
        result.findings.append(
            f"B3 Unicode directional-override chars detected ({codes}) — Trojan Source / text-direction spoofing"
        )

    # ── B4: Dangerous HTML tags ──────────────────────────────────────
    # Strip fenced code blocks first — XML inside SQL code (e.g. SET @x='<meta>')
    # is legitimate and must not trigger a false positive block.
    content_no_code = _CODE_BLOCK_RE.sub('', content)
    html_tags = _HTML_TAG_RE.findall(content_no_code)
    if html_tags:
        result.findings.append(
            f"B4 Dangerous HTML tags detected outside code blocks: {', '.join(f'<{t}>' for t in set(html_tags))}"
        )

    # ── B4b: HTML inline event handlers ─────────────────────────────
    event_attrs = _HTML_EVENT_RE.findall(content)
    if event_attrs:
        result.findings.append(
            f"B4b HTML event-handler attributes detected: {', '.join(set(event_attrs))}"
        )

    # ── B5: Dangerous URI schemes in markdown links ──────────────────
    if _DANGEROUS_URI_RE.search(content):
        result.findings.append(
            "B5 Dangerous URI scheme in markdown link (javascript:/vbscript:/data:text/html)"
        )

    # ── B6: data:base64 URI ──────────────────────────────────────────
    if _DATA_B64_RE.search(content):
        result.findings.append(
            "B6 Embedded data:base64 URI detected — possible binary payload"
        )

    # ── W1: Zero-width / invisible chars ────────────────────────────
    zw = [ch for ch in content if ch in _ZERO_WIDTH]
    if zw:
        codes = ', '.join(f"U+{ord(c):04X}" for c in sorted(set(zw)))
        result.warnings.append(f"W1 Zero-width/invisible Unicode chars ({codes})")

    # ── W2: Abnormally long lines ────────────────────────────────────
    long_lines = [i + 1 for i, ln in enumerate(content.splitlines()) if len(ln) > MAX_LINE_LENGTH]
    if long_lines:
        result.warnings.append(
            f"W2 {len(long_lines)} line(s) exceed {MAX_LINE_LENGTH} chars "
            f"(first at line {long_lines[0]})"
        )

    # ── W3: Unexpected control characters ───────────────────────────
    ctrl = [ch for ch in content
            if unicodedata.category(ch) == 'Cc' and ch not in '\t\n\r']
    if ctrl:
        codes = ', '.join(f"U+{ord(c):04X}" for c in sorted(set(ctrl[:10])))
        result.warnings.append(f"W3 Non-whitespace control chars detected: {codes}")

    # ── W4: High non-ASCII ratio ─────────────────────────────────────
    if len(content) > 0:
        ratio = sum(1 for c in content if ord(c) > 127) / len(content)
        if ratio > MAX_NON_ASCII_RATIO:
            result.warnings.append(
                f"W4 High non-ASCII ratio ({ratio:.1%}) — possible encoding attack"
            )

    # ── W5: Prompt-injection markers ────────────────────────────────
    if _PROMPT_INJ_RE.search(content):
        result.warnings.append(
            "W5 Prompt-injection marker detected in AI output — review content before use"
        )

    # Finalise
    if result.findings:
        result.blocked = True
        result.passed  = False

    return result