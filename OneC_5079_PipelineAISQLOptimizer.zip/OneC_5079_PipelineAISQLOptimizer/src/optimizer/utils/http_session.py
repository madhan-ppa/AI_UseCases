"""
Shared HTTP session utilities — used by all service classes that make REST API calls.

Contains two independent features:

  1. build_http_session()  — Max Retry (existing)
  2. RateLimiter           — Rate Limiting (controls request rate per time window)

Usage:
    from optimizer.utils.http_session import build_http_session, RateLimiter

    session = build_http_session(verify_ssl=True)
    limiter = RateLimiter()

    # Before every API call:
    limiter.check_request()        # Raises if rate limit exceeded
    response = session.get(url)
"""

import os
import time
import threading
from collections import deque

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


# ══════════════════════════════════════════════════════════════════════════════
# MAX RETRY — existing, unchanged
# ══════════════════════════════════════════════════════════════════════════════

MAX_RETRY_TOTAL = int(os.getenv('MAX_RETRY_TOTAL', '3'))
MAX_RETRY_BACKOFF_FACTOR = float(os.getenv('MAX_RETRY_BACKOFF_FACTOR', '1'))
MAX_RETRY_STATUS_FORCELIST = [int(x) for x in os.getenv('MAX_RETRY_STATUS_FORCELIST', '401,403,502,503,504').split(',')]


def build_http_session(verify_ssl: bool = True) -> requests.Session:
    """
    Create a requests.Session pre-configured with retry logic.

    Args:
        verify_ssl: Whether to verify SSL certificates. Each caller passes
                    its own value (from env var or constructor param).

    Returns:
        A requests.Session with:
          - verify set to the caller's preference
          - Retry with configurable total, backoff_factor, and status_forcelist
          - HTTPAdapter mounted on https://

    The caller is responsible for adding auth headers, extra session headers,
    or any service-specific configuration after receiving the session.
    """
    s = requests.Session()
    s.verify = verify_ssl
    retry = Retry(
        total=MAX_RETRY_TOTAL,
        backoff_factor=MAX_RETRY_BACKOFF_FACTOR,
        status_forcelist=MAX_RETRY_STATUS_FORCELIST,
        raise_on_status=False
    )
    adapter = HTTPAdapter(max_retries=retry)
    s.mount("https://", adapter)
    return s


# ══════════════════════════════════════════════════════════════════════════════
# RATE LIMITING — controls API request rate, blocks requests exceeding limit
# ══════════════════════════════════════════════════════════════════════════════
#
# Configuration (via environment variables — safe defaults if unset):
#   RATE_LIMIT_MAX_REQUESTS       Max requests allowed per window        (default: 60)
#   RATE_LIMIT_WINDOW_SECONDS     Time window in seconds for rate limit  (default: 60)
# ══════════════════════════════════════════════════════════════════════════════

RATE_LIMIT_MAX_REQUESTS = int(os.getenv('RATE_LIMIT_MAX_REQUESTS', '60'))
RATE_LIMIT_WINDOW_SECONDS = int(os.getenv('RATE_LIMIT_WINDOW_SECONDS', '60'))


class RateLimiter:
    """
    Rate limiter that enforces max N requests per time window.
    Any request exceeding the limit is blocked.

    Usage:
        limiter = RateLimiter()

        # Before making a request:
        limiter.check_request()   # raises RateLimitExceeded if limit exceeded

    Thread-safe.
    """

    def __init__(self):
        self._lock = threading.Lock()
        self._request_timestamps = deque()
        self._rate_limit_max = RATE_LIMIT_MAX_REQUESTS
        self._rate_limit_window = RATE_LIMIT_WINDOW_SECONDS

    def check_request(self):
        """
        Call BEFORE every API request.
        If rate limit is exceeded, waits until the window resets, then allows the request.
        """
        with self._lock:
            now = time.time()

            # Purge timestamps outside the current window
            cutoff = now - self._rate_limit_window
            while self._request_timestamps and self._request_timestamps[0] < cutoff:
                self._request_timestamps.popleft()

            # If limit exceeded, wait until oldest request exits the window
            if len(self._request_timestamps) >= self._rate_limit_max:
                oldest = self._request_timestamps[0]
                wait_seconds = (oldest + self._rate_limit_window) - now
                if wait_seconds > 0:
                    print(f"   [RATE LIMIT] {self._rate_limit_max} requests reached in "
                          f"{self._rate_limit_window}s window. Waiting {wait_seconds:.1f}s...")
                    time.sleep(wait_seconds)

                # After sleeping, purge again and allow
                now = time.time()
                cutoff = now - self._rate_limit_window
                while self._request_timestamps and self._request_timestamps[0] < cutoff:
                    self._request_timestamps.popleft()

            # Allowed — record this request
            self._request_timestamps.append(now)
