"""​
GitHub Python Navigator - Rule-Based Repository Navigation (No AI)
Automates: Organization Discovery → Repository Finding → Directory Mapping → Pattern-Based Path Finding

This version uses pure Python logic for accurate table/SP path matching.
"""

import os
import sys
import requests
import json
from typing import List, Dict, Tuple, Optional
import urllib3
import time
import re
import base64

# Support both: running as a package (relative imports) and running standalone
try:
    from ..models import get_session
    from ..utils.audit_logger import log_audit, log_pipeline_error
    from ..utils.http_session import build_http_session, RateLimiter
except ImportError:
    _project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    if _project_root not in sys.path:
        sys.path.insert(0, _project_root)
    os.chdir(_project_root)
    from optimizer.models import get_session
    from optimizer.utils.audit_logger import log_audit, log_pipeline_error
    from optimizer.utils.http_session import build_http_session, RateLimiter
from .ai_tables_extractor import AITableExtractor

# In GKE set GITHUB_SSL_VERIFY=true (default). Set to false only when the
# corporate GitHub Enterprise instance uses a self-signed/internal CA cert.
_GITHUB_SSL_VERIFY = os.getenv('GITHUB_SSL_VERIFY', 'true').lower() not in ('false', '0', 'no')
if not _GITHUB_SSL_VERIFY:
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class GitHubPythonNavigator:
    """
    Python-based GitHub navigator:
    - Uses Python pattern matching for repository identification (no AI needed)
    - Uses Python pattern matching for SP/table paths (accurate)
    """
    
    def __init__(self, github_token: str, github_base_url: str = None):
        """
        Initialize the GitHub Python Navigator.

        Args:
            github_token: GitHub Personal Access Token
            github_base_url: Base URL for GitHub Enterprise API
        """
        self.github_token = github_token
        self.github_base_url = github_base_url or os.getenv('GITHUB_BASE_URL', 'https://github.cognizant.com/api/v3')
        
        self.github_headers = {
            "Authorization": f"token {github_token}",
            "Accept": "application/vnd.github.v3+json"
        }
        self._session = build_http_session(verify_ssl=_GITHUB_SSL_VERIFY)
        self._rate_limiter = RateLimiter()
        
        self.db_name = "AI_SQL_Optimizer.db"
        
        # Cache for repository data to avoid redundant API calls
        self._repo_cache = {}  # Key: (portfolio, app_name) -> (org_name, repo_name, tree)
        self._portfolio_repos_cache = {}  # Key: portfolio -> list of repos

    # ========================================
    # GITHUB API METHODS
    # ========================================
    
    def get_organization_repos(self, org_name: str) -> List[Dict]:
        """
        Fetch all repositories for a given organization.
        
        Args:
            org_name: Organization name (portfolio)
            
        Returns:
            List of repository dictionaries
        """
        url = f"{self.github_base_url}/orgs/{org_name}/repos"
        all_repos = []
        page = 1
        
        try:
            while True:
                self._rate_limiter.check_request()
                response = self._session.get(
                    url,
                    headers=self.github_headers,
                    params={"page": page, "per_page": 100},
                    timeout=60
                )
                response.raise_for_status()
                repos = response.json()

                if not repos:
                    break

                all_repos.extend(repos)
                page += 1

                if len(repos) < 100:
                    break
            
            print(f"✅ Found {len(all_repos)} repositories in '{org_name}'")
            return all_repos
        except Exception as e:
            import traceback
            error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
            print(f"❌ Error fetching repos for org '{org_name}': {e}")
            log_pipeline_error(
                error_type='GITHUB_API_ERROR',
                error=error_text,
                sp_name=f'(GitHub: list_repos org={org_name})',
            )
            return []
    
    def get_repo_tree_recursive(self, org_name: str, repo_name: str, branch: str = None) -> List[Dict]:
        """
        Fetch the COMPLETE directory tree of a repository recursively (SINGLE API CALL).
        
        Args:
            org_name: Organization name
            repo_name: Repository name
            branch: Branch name (default: from GIT_DEFAULT_BRANCH env var or 'develop')

        Returns:
            List of all files/directories with their paths
        """
        if branch is None:
            branch = os.getenv('GIT_DEFAULT_BRANCH', 'develop')
        url = f"{self.github_base_url}/repos/{org_name}/{repo_name}/git/trees/{branch}?recursive=1"
        
        try:
            print(f"📥 Fetching complete tree from {org_name}/{repo_name} (branch: {branch})...")
            self._rate_limiter.check_request()
            response = self._session.get(url, headers=self.github_headers, timeout=60)
            response.raise_for_status()
            tree_data = response.json()
            
            tree = tree_data.get("tree", [])
            print(f"✅ Retrieved {len(tree)} items from repository")
            return tree
        except Exception as e:
            import traceback
            error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
            print(f"❌ Error fetching tree for '{org_name}/{repo_name}' (branch: {branch}): {e}")
            log_pipeline_error(
                error_type='GITHUB_API_ERROR',
                error=error_text,
                sp_name=f'(GitHub: get_repo_tree {org_name}/{repo_name})',
            )
            # Try 'master' branch as fallback
            try:
                url_master = f"{self.github_base_url}/repos/{org_name}/{repo_name}/git/trees/master?recursive=1"
                print(f"🔄 Trying 'master' branch as fallback...")
                self._rate_limiter.check_request()
                response = self._session.get(url_master, headers=self.github_headers, timeout=60)
                response.raise_for_status()
                tree_data = response.json()
                tree = tree_data.get("tree", [])
                print(f"✅ Retrieved {len(tree)} items from repository (master branch)")
                return tree
            except Exception as e2:
                import traceback
                error_text = f"{type(e2).__name__}: {e2}\n{traceback.format_exc()}"
                print(f"❌ Error fetching tree (master branch): {e2}")
                log_pipeline_error(
                    error_type='GITHUB_API_ERROR',
                    error=error_text,
                    sp_name=f'(GitHub: get_repo_tree master {org_name}/{repo_name})',
                )
                # Try 'main' branch as last fallback
                try:
                    url_main = f"{self.github_base_url}/repos/{org_name}/{repo_name}/git/trees/main?recursive=1"
                    print(f"🔄 Trying 'main' branch as last fallback...")
                    self._rate_limiter.check_request()
                    response = self._session.get(url_main, headers=self.github_headers, timeout=60)
                    response.raise_for_status()
                    tree_data = response.json()
                    tree = tree_data.get("tree", [])
                    print(f"✅ Retrieved {len(tree)} items from repository (main branch)")
                    return tree
                except Exception as e3:
                    import traceback
                    error_text = f"{type(e3).__name__}: {e3}\n{traceback.format_exc()}"
                    print(f"❌ All branch attempts failed: {e3}")
                    log_pipeline_error(
                        error_type='GITHUB_API_ERROR',
                        error=error_text,
                        sp_name=f'(GitHub: get_repo_tree main {org_name}/{repo_name})',
                    )
                    return []
    
    def get_file_content(self, org_name: str, repo_name: str, file_path: str) -> Optional[str]:
        """
        Fetch the content of a specific file from GitHub.
        
        Args:
            org_name: Organization name
            repo_name: Repository name
            file_path: Path to the file in the repository
            
        Returns:
            File content as string, or None if error
        """
        url = f"{self.github_base_url}/repos/{org_name}/{repo_name}/contents/{file_path}"
        
        try:
            self._rate_limiter.check_request()
            response = self._session.get(url, headers=self.github_headers, timeout=30)
            response.raise_for_status()
            content_data = response.json()
            
            # GitHub returns base64 encoded content
            content = base64.b64decode(content_data.get("content", "")).decode('utf-8')
            return content
        except Exception as e:
            import traceback
            error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
            print(f"❌ Error fetching file '{file_path}': {e}")
            log_pipeline_error(
                error_type='GITHUB_API_ERROR',
                error=error_text,
                sp_name=f'(GitHub: get_file_content {file_path})',
            )
            return None
    
    # ========================================
    # PYTHON PATTERN MATCHING METHODS
    # ========================================
    
    def find_repository(self, repos: List[Dict], app_name: str, sp_name: str) -> Optional[Tuple[str, str]]:
        """
        Find the correct repository for an application using Python pattern matching.
        No AI needed — uses multi-strategy scoring to accurately match app to repo.

        Scoring strategies (in priority order):
        1. Exact app name match in repo name (highest confidence)
        2. App ID prefix match (e.g., "1738" from "1738-My-Learning-Studio")
        3. Token overlap — words from app name found in repo name/description
        4. Normalized substring match (ignore case, hyphens, underscores, spaces)
        5. SP name match in repo name/description (weak signal, tiebreaker)

        Args:
            repos: List of repository dictionaries from GitHub API
            app_name: Application name from app_config
            sp_name: Stored procedure name

        Returns:
            Tuple of (org_name, repo_name) or None
        """
        if not repos:
            print("❌ No repositories to search")
            return None

        print(f"🔍 Finding repository for app: '{app_name}', SP: '{sp_name}'")
        print(f"   Scanning {len(repos)} repositories...")

        # Normalize helper
        def normalize(s):
            """Lowercase, strip brackets, replace separators with space, collapse whitespace."""
            s = s.lower().replace('[', '').replace(']', '')
            s = re.sub(r'[-_./\\]', ' ', s)
            return re.sub(r'\s+', ' ', s).strip()

        # Extract app ID (numeric prefix before first hyphen/space)
        app_id_match = re.match(r"(\d{3,})", app_name)
        app_id = app_id_match.group(1) if app_id_match else None

        # Tokenize app name into meaningful words (3+ chars, no stop words)
        stop_words = {'the', 'and', 'for', 'sit', 'uat', 'dev', 'prod', 'prd', 'stg', 'test',
                       'app', 'application', 'system', 'tool', 'service', 'api', 'web', 'new', 'old'}
        app_tokens = [w for w in normalize(app_name).split()
                      if len(w) >= 3 and w not in stop_words and not w.isdigit()]

        # Also get SP tokens (just the procedure name part after schema)
        sp_clean = sp_name.replace('[', '').replace(']', '').strip()
        if '.' in sp_clean:
            sp_clean = sp_clean.split('.')[-1]
        sp_tokens = [w for w in re.sub(r'[_]', ' ', sp_clean.lower()).split()
                     if len(w) >= 3 and w not in stop_words]

        app_norm = normalize(app_name)

        scored_repos = []

        for repo in repos:
            repo_name = repo.get("name", "")
            full_name = repo.get("full_name", "")
            description = repo.get("description") or ""

            if "/" not in full_name:
                continue

            repo_norm = normalize(repo_name)
            desc_norm = normalize(description)
            combined_norm = repo_norm + " " + desc_norm

            score = 0
            match_reasons = []

            # Strategy 1: Exact app name in repo name (strongest signal)
            if app_norm == repo_norm:
                score += 100
                match_reasons.append("exact-name-match")
            elif app_norm in repo_norm or repo_norm in app_norm:
                score += 80
                match_reasons.append("substring-name-match")

            # Strategy 2: App ID in repo name
            if app_id:
                if app_id in repo_name:
                    score += 70
                    match_reasons.append(f"app-id-{app_id}-in-repo")
                elif app_id in description:
                    score += 40
                    match_reasons.append(f"app-id-{app_id}-in-desc")

            # Strategy 3: Token overlap — how many app name words appear in repo
            if app_tokens:
                repo_token_set = set(combined_norm.split())
                matched_tokens = [t for t in app_tokens if t in repo_token_set]
                token_ratio = len(matched_tokens) / len(app_tokens) if app_tokens else 0
                if token_ratio >= 0.8:
                    score += 60
                    match_reasons.append(f"token-match-{len(matched_tokens)}/{len(app_tokens)}")
                elif token_ratio >= 0.5:
                    score += 40
                    match_reasons.append(f"token-partial-{len(matched_tokens)}/{len(app_tokens)}")
                elif matched_tokens:
                    score += 15 * len(matched_tokens)
                    match_reasons.append(f"token-some-{len(matched_tokens)}/{len(app_tokens)}")

            # Strategy 4: Condensed match (remove ALL separators and spaces)
            app_condensed = re.sub(r'[^a-z0-9]', '', app_norm)
            repo_condensed = re.sub(r'[^a-z0-9]', '', repo_norm)
            if app_condensed and repo_condensed:
                if app_condensed == repo_condensed:
                    score += 90
                    match_reasons.append("condensed-exact")
                elif app_condensed in repo_condensed or repo_condensed in app_condensed:
                    score += 50
                    match_reasons.append("condensed-substring")

            # Strategy 5: SP name tokens in repo name/description (weak tiebreaker)
            if sp_tokens:
                sp_matched = [t for t in sp_tokens if t in combined_norm]
                if sp_matched:
                    score += 5 * len(sp_matched)
                    match_reasons.append(f"sp-token-{len(sp_matched)}")

            # Strategy 6: Database-related repo (bonus if repo contains db keywords)
            db_keywords = ['database', 'db', 'sql', 'data', 'schema', 'stored', 'proc']
            if any(kw in combined_norm for kw in db_keywords):
                score += 5
                match_reasons.append("db-keyword")

            if score > 0:
                scored_repos.append((score, full_name, match_reasons))

        # Sort by score descending
        scored_repos.sort(key=lambda x: x[0], reverse=True)

        # Log top candidates
        if scored_repos:
            print(f"   Top candidates:")
            for score, full_name, reasons in scored_repos[:5]:
                print(f"      Score {score:3d}: {full_name} ({', '.join(reasons)})")

        # Select best match if score is above minimum threshold
        if scored_repos and scored_repos[0][0] >= 15:
            best_score, best_full_name, best_reasons = scored_repos[0]
            org, name = best_full_name.split("/", 1)
            print(f"   ✅ Selected repository: {best_full_name} (score: {best_score}, reasons: {', '.join(best_reasons)})")
            return org, name

        print(f"   ❌ No repository match found for '{app_name}' (all scores below threshold)")
        return None
    
    def find_sp_path(self, tree: List[Dict], sp_name: str, schema_name: Optional[str] = None) -> Optional[str]:
        """
        Find a stored procedure's .sql file anywhere in the repo tree.

        Searches ALL folders in the repo (the tree is fetched recursively
        via GitHub's Trees API with ?recursive=1, so EVERY .sql file across
        every folder is in `tree`). Returns None ONLY when no file matches
        via any of the 4 patterns below.

        Handles every common SP-naming convention AppD may produce:
            [Schema].[Name]   |  "Schema"."Name"   |  `Schema`.`Name`
            Schema.Name       |  Database.Schema.Name (3-part)
            [Name]            |  Name              |  ' Name ' (whitespace)

        Caller-supplied `schema_name` always takes precedence over inline.

        Args:
            tree:        Repository tree from get_repo_tree_recursive()
            sp_name:     Stored procedure name in any of the forms above
            schema_name: Optional explicit schema (overrides auto-detection)

        Returns:
            Repo-relative file path, or None if no match in any folder.
        """
        # ── Step 1: aggressively normalise the input ──────────────────────
        # Strip brackets, quotes (single/double/backtick), and whitespace
        raw = sp_name
        for ch in ('[', ']', '"', "'", '`'):
            raw = raw.replace(ch, '')
        raw = raw.strip()

        # Auto-detect inline schema. For 3-part names like "DB.Schema.Name"
        # we use rsplit so the LAST segment is treated as the SP name and
        # everything before it becomes the schema (which we'll match
        # loosely via path segments).
        if '.' in raw:
            head, tail    = raw.rsplit('.', 1)
            inline_schema = head.strip()
            sp_name_clean = tail.strip()
            if not schema_name and inline_schema:
                schema_name = inline_schema
        else:
            sp_name_clean = raw

        if not sp_name_clean:
            print(f"❌ SP name empty after parsing: original='{sp_name}'")
            return None

        # Normalise schema (last segment if 3-part, e.g. 'DB.Schema' -> 'Schema')
        schema_clean = None
        if schema_name:
            cleaned = schema_name
            for ch in ('[', ']', '"', "'", '`'):
                cleaned = cleaned.replace(ch, '')
            cleaned = cleaned.strip()
            if '.' in cleaned:
                cleaned = cleaned.rsplit('.', 1)[-1].strip()
            schema_clean = cleaned.lower() if cleaned else None

        # ── Step 2: filter to .sql blobs ──────────────────────────────────
        sql_files = [item for item in tree
                     if item.get("type") == "blob"
                     and item.get("path", "").lower().endswith(".sql")]

        print(f"🔍 Searching for SP: '{sp_name_clean}' "
              f"(schema='{schema_clean}', candidates={len(sql_files)})")

        sp_lower = sp_name_clean.lower()

        # ── Pattern 1: schema appears as a PATH SEGMENT + exact filename ──
        # Stricter than substring match — avoids 'mls' matching 'somemls/'.
        if schema_clean:
            for file in sql_files:
                path     = file.get("path", "")
                segments = [s.lower() for s in path.split('/')]
                filename = os.path.basename(path).replace(".sql", "").lower()
                if schema_clean in segments and filename == sp_lower:
                    print(f"✅ Found (schema+exact): {path}")
                    return path

        # ── Pattern 2: exact filename match anywhere in the tree ──────────
        for file in sql_files:
            path     = file.get("path", "")
            filename = os.path.basename(path).replace(".sql", "").lower()
            if filename == sp_lower:
                print(f"✅ Found (exact match): {path}")
                return path

        # ── Pattern 3: filename starts with SP name ───────────────────────
        # Catches e.g. `USP_QGInsertQuizResult_v2.sql` — but only if the
        # next character after the SP name is a separator, to avoid
        # "USP_NAME" matching "USP_NAMEDIFFERENT".
        for file in sql_files:
            path     = file.get("path", "")
            filename = os.path.basename(path).replace(".sql", "").lower()
            if filename.startswith(sp_lower) and len(filename) > len(sp_lower):
                next_char = filename[len(sp_lower)]
                if next_char in ('_', '-', '.', ' '):
                    print(f"✅ Found (prefix+sep match): {path}")
                    return path

        # ── Pattern 4: last-resort substring match ────────────────────────
        for file in sql_files:
            path     = file.get("path", "")
            filename = os.path.basename(path).lower()
            if sp_lower in filename:
                print(f"✅ Found (partial match): {path}")
                return path

        # ── Not found in any folder via any pattern ───────────────────────
        # In autonomous mode (GKE cron) nobody reads stdout interactively, so
        # the stdout message stays terse: SP is genuinely absent. The audit
        # log captures the diagnostic context (closest filenames by 4-char
        # sliding-window similarity) for offline post-hoc analysis if needed.
        print(f"❌ SP file not present in GitHub repo: '{sp_name}'")

        closest = []
        if len(sp_lower) >= 4:
            scored = []
            for file in sql_files:
                path     = file.get("path", "")
                filename = os.path.basename(path).replace(".sql", "").lower()
                score = sum(1 for i in range(len(sp_lower) - 3)
                            if sp_lower[i:i + 4] in filename)
                if score:
                    scored.append((score, path))
            scored.sort(key=lambda x: -x[0])
            closest = [path for _score, path in scored[:5]]

        log_audit(
            "GITHUB_SP_NOT_FOUND",
            sp_name=sp_name,
            message="SP file not present in GitHub repo (searched all folders, "
                    "all known name formats — confirmed absent).",
            parsed_schema=schema_clean,
            parsed_sp_name=sp_name_clean,
            sql_files_scanned=len(sql_files),
            closest_matches=closest,
        )
        return None
    
    def find_table_paths(self, tree: List[Dict], table_names: List[str]) -> Dict[str, Optional[str]]:
        """
        Find table schema file paths using Python pattern matching (SINGLE OPERATION).
        
        Args:
            tree: Repository tree
            table_names: List of table names (with schema prefixes like [RDP].[TableName])
            
        Returns:
            Dictionary mapping original_table_name -> file_path
        """
        print(f"\n🔍 Searching for {len(table_names)} table schemas...")
        
        # Filter SQL files
        sql_files = [item for item in tree if item.get("type") == "blob" and item.get("path", "").lower().endswith(".sql")]
        
        print(f"📂 Available SQL files: {len(sql_files)}")
        
        # Parse table names and extract schema + table name
        parsed_tables = {}
        for full_table_name in table_names:
            # Remove brackets and split by dot
            # e.g., "[RDP].[tblAssociateTemplateExcemption]" -> ["RDP", "tblAssociateTemplateExcemption"]
            parts = full_table_name.replace('[', '').replace(']', '').split('.')
            
            if len(parts) >= 2:
                schema = parts[-2]  # Second to last part
                table_name = parts[-1]  # Last part
            else:
                schema = None
                table_name = parts[-1]
            
            parsed_tables[full_table_name] = {
                'schema': schema,
                'table_name': table_name
            }
        
        # Find paths for each table
        results = {}
        
        for full_table_name, info in parsed_tables.items():
            schema = info['schema']
            table_name = info['table_name']
            path = None
            
            # Strategy 1: Match with schema in path
            if schema:
                for file in sql_files:
                    file_path = file.get("path", "")
                    filename = os.path.basename(file_path).replace(".sql", "")
                    
                    # Check if schema is in the path and table name matches filename
                    if schema.lower() in file_path.lower() and filename.lower() == table_name.lower():
                        path = file_path
                        print(f"   ✅ {table_name} -> {path}")
                        break
            
            # Strategy 2: Exact filename match (case-insensitive)
            if not path:
                for file in sql_files:
                    file_path = file.get("path", "")
                    filename = os.path.basename(file_path).replace(".sql", "")
                    
                    if filename.lower() == table_name.lower():
                        path = file_path
                        print(f"   ✅ {table_name} -> {path}")
                        break
            
            # Strategy 3: Partial match in filename (COMMENTED OUT - USER WANTS EXACT MATCHES ONLY)
            # if not path:
            #     for file in sql_files:
            #         file_path = file.get("path", "")
            #         filename = os.path.basename(file_path).lower()
            #         
            #         if table_name.lower() in filename:
            #             path = file_path
            #             print(f"   ⚠️  {table_name} -> {path} (partial match)")
            #             break
            
            if not path:
                print(f"   ❌ {table_name} -> Not found")
            
            results[full_table_name] = path
        
        found_count = len([p for p in results.values() if p])
        print(f"\n📊 Found {found_count} out of {len(table_names)} tables")
        
        return results
    
    # ========================================
    # MAIN WORKFLOW
    # ========================================
    
    def process_sp_with_python_navigation(self, app_id: int, app_name: str, sp_name: str, schema_name: Optional[str] = None) -> Dict:
        """
        Complete Python-based workflow:
        - Python pattern matching for repository identification (no AI)
        - Python pattern matching for SP/table path finding (accurate)
        
        Args:
            app_id: Application ID from app_config
            app_name: Application name
            sp_name: Stored procedure name
            schema_name: Optional schema name
            
        Returns:
            Dictionary containing SP code, table schemas, and paths
        """
        print("\n" + "="*100)
        print(f"� PYTHON NAVIGATION: AI (Repo) + Python (Paths)")
        print(f"   Processing SP '{sp_name}' for App '{app_name}'")
        print("="*100)
        
        # Step 1: Get portfolio (organization) from app_config
        portfolio = self._get_portfolio_for_app(app_id)
        if not portfolio:
            print(f"❌ No portfolio found for app_id {app_id}")
            return {'success': False, 'error': f'No portfolio found for app_id {app_id}'}
        
        print(f"📂 Portfolio: {portfolio}")
        
        # Check if we have cached data for this portfolio + app
        cache_key = (portfolio, app_name)
        if cache_key in self._repo_cache:
            print(f"🎯 CACHE HIT: Using cached repository data for '{app_name}' in '{portfolio}'")
            print(f"   ⚡ Skipping Steps 1-3 (already done for this app)")
            org_name, repo_name, tree = self._repo_cache[cache_key]
        else:
            # Step 2: Get all repositories in the portfolio (with caching)
            print(f"\n[Step 1/5] Fetching repositories from portfolio '{portfolio}'...")
            if portfolio in self._portfolio_repos_cache:
                print(f"🎯 Using cached repository list for '{portfolio}'")
                repos = self._portfolio_repos_cache[portfolio]
            else:
                repos = self.get_organization_repos(portfolio)
                if not repos:
                    print(f"❌ No repositories found in portfolio '{portfolio}'")
                    return {'success': False, 'error': f'No repositories found in portfolio {portfolio}'}
                self._portfolio_repos_cache[portfolio] = repos
            
            # Step 3: Find correct repository using Python pattern matching
            print(f"\n[Step 2/5] Finding repository using pattern matching...")
            repo_match = self.find_repository(repos, app_name, sp_name)
            if not repo_match:
                print(f"❌ Could not identify repository")
                return {'success': False, 'error': f'Could not identify repository for app {app_name}'}
            
            org_name, repo_name = repo_match
            
            # Step 4: Get complete directory tree (SINGLE OPERATION)
            print(f"\n[Step 3/5] Fetching complete directory tree (ONE-TIME OPERATION)...")
            tree = self.get_repo_tree_recursive(org_name, repo_name)
            if not tree:
                print(f"❌ Could not fetch repository tree")
                return {'success': False, 'error': f'Could not fetch repository tree from {org_name}/{repo_name}'}
            
            # Cache the repository data for this portfolio + app
            self._repo_cache[cache_key] = (org_name, repo_name, tree)
            print(f"💾 Cached repository data for future SPs in this app")
        
        # Step 5: Find SP file path using Python pattern matching
        print(f"\n[Step 4/5] Finding stored procedure file path...")
        sp_file_path = self.find_sp_path(tree, sp_name, schema_name)
        if not sp_file_path:
            print(f"❌ Could not find SP file path")
            return {'success': False, 'error': f'Could not find SP file path for {sp_name}'}
        
        # Step 6: Fetch SP code
        print(f"\n[Step 5/5] Fetching stored procedure code...")
        sp_code = self.get_file_content(org_name, repo_name, sp_file_path)
        if not sp_code:
            print(f"❌ Could not fetch SP code")
            return {'success': False, 'error': f'Could not fetch SP code from {sp_file_path}'}
        
        print(f"✅ Successfully extracted SP code ({len(sp_code)} characters)")
        
        # Step 7: Extract table names from SP code
        print(f"\n[Bonus] Extracting table names from SP code...")
        table_names = self._extract_table_names_from_sp(sp_name, sp_code)
        print(f"📊 Found {len(table_names)} tables: {table_names}")
        
        # Step 8: Find table schema paths using Python pattern matching (reusing same tree)
        table_schemas = {}
        table_paths = {}
        
        if table_names:
            print(f"\n[Bonus] Finding table schema paths using pattern matching...")
            table_path_map = self.find_table_paths(tree, table_names)
            
            # Fetch table schemas
            print(f"\n📥 Fetching table schema contents...")
            for table_name, table_path in table_path_map.items():
                if table_path:
                    clean_name = table_name.split('.')[-1].strip('[]')
                    print(f"  Fetching schema for '{clean_name}'...")
                    schema_code = self.get_file_content(org_name, repo_name, table_path)
                    if schema_code:
                        table_schemas[table_name] = schema_code
                        table_paths[table_name] = table_path
                        print(f"    ✅ Retrieved ({len(schema_code)} characters)")
                    else:
                        print(f"    ❌ Failed to retrieve")
        
        print("\n" + "="*100)
        print(f"✅ PYTHON NAVIGATION COMPLETE")
        print("="*100)
        
        return {
            "success": True,
            "sp_code": sp_code,
            "sp_file_path": sp_file_path,
            "table_schemas": table_schemas,
            "table_paths": table_paths,
            "repository": f"{org_name}/{repo_name}",
            "portfolio": portfolio
        }
    
    def process_sp_with_direct_repo(self, org_name: str, repo_name: str, repo_tree: List[Dict],
                                       sp_name: str, app_name: str, schema_name: Optional[str] = None) -> Dict:
        """
        Direct repo mode — uses pre-fetched repo tree, skips repo listing and pattern matching.
        Called by DecisionAgent when repo_name is available from app_config.

        Args:
            org_name: GitHub organization name (from AppConfig.Organization_Name)
            repo_name: Repository name (from AppConfig.repo_name)
            repo_tree: Pre-fetched repository tree (from get_repo_tree_recursive)
            sp_name: Stored procedure name
            app_name: Application name (for logging)
            schema_name: Optional schema name

        Returns:
            Dictionary containing SP code, table schemas, and paths
        """
        print(f"\n   DIRECT REPO: {org_name}/{repo_name}")
        print(f"   Processing SP '{sp_name}' for App '{app_name}'")

        # Step 1: Find SP file path using Python pattern matching on pre-fetched tree
        print(f"   Finding stored procedure file path...")
        sp_file_path = self.find_sp_path(repo_tree, sp_name, schema_name)
        if not sp_file_path:
            print(f"   Could not find SP file path for '{sp_name}'")
            return {'success': False, 'error': f'Could not find SP file path for {sp_name}'}

        # Step 2: Fetch SP code
        print(f"   Fetching stored procedure code...")
        sp_code = self.get_file_content(org_name, repo_name, sp_file_path)
        if not sp_code:
            print(f"   Could not fetch SP code from {sp_file_path}")
            return {'success': False, 'error': f'Could not fetch SP code from {sp_file_path}'}

        print(f"   SP code extracted ({len(sp_code)} characters)")

        # Step 3: Extract table names from SP code
        print(f"   Extracting table names from SP code...")
        table_names = self._extract_table_names_from_sp(sp_name, sp_code)
        print(f"   Found {len(table_names)} tables: {table_names}")

        # Step 4: Find table schema paths using pattern matching (reusing same tree)
        table_schemas = {}
        table_paths = {}

        if table_names:
            print(f"   Finding table schema paths...")
            table_path_map = self.find_table_paths(repo_tree, table_names)

            for table_name, table_path in table_path_map.items():
                if table_path:
                    clean_name = table_name.split('.')[-1].strip('[]')
                    schema_code = self.get_file_content(org_name, repo_name, table_path)
                    if schema_code:
                        table_schemas[table_name] = schema_code
                        table_paths[table_name] = table_path
                        print(f"     {clean_name}: {len(schema_code)} chars")

        print(f"   EXTRACTION COMPLETE: SP code + {len(table_schemas)} table schema(s)")

        return {
            "success": True,
            "sp_code": sp_code,
            "sp_file_path": sp_file_path,
            "table_schemas": table_schemas,
            "table_paths": table_paths,
            "repository": f"{org_name}/{repo_name}",
        }

    def _get_portfolio_for_app(self, app_id: int) -> Optional[str]:
        """Get portfolio (organization) name from app_config for the given app_id.
        Calls: fn_get_portfolio_for_app()
        """
        from sqlalchemy import text
        with get_session() as session:
            result = session.execute(
                text("SELECT fn_get_portfolio_for_app(:p_app_id)"),
                {"p_app_id": app_id},
            )
            return result.scalar()
    
    def _extract_table_names_from_sp(self, sp_name: str, sp_code: str) -> List[str]:
        """
        Extract table names from SP code using AI (reusing existing module).
        
        Args:
            sp_name: Name of the stored procedure
            sp_code: Stored procedure code
            
        Returns:
            List of table names
        """
        try:
            # Use existing AI table extractor with settings from config
            extractor = AITableExtractor()
            result = extractor.extract_tables_from_sp(sp_name, sp_code)
            
            # The method returns a dict with 'table_names' key
            if isinstance(result, dict):
                return result.get('table_names', [])
            else:
                return result if isinstance(result, list) else []
        except Exception as e:
            import traceback
            error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
            print(f"⚠️  Could not extract table names: {e}")
            log_pipeline_error(
                error_type='LLM_API_ERROR',
                error=error_text,
                sp_name=sp_name,
            )
            return []


# ========================================
# MAIN EXECUTION
# ========================================

def main():
    """
    Test the GitHub Python Navigator with a sample SP from ado_defect_tracker.
    """
    # Load configuration from .env file
    from config import get_config
    config = get_config()
    
    github_token = config.GITHUB_TOKEN

    # Initialize navigator
    navigator = GitHubPythonNavigator(
        github_token=github_token,
    )
    
    # Get a sample SP from defect tracker via fn_get_eligible_sps()
    from sqlalchemy import text
    with get_session() as session:
        result = session.execute(text(
            "SELECT app_id, app_name, sp_name FROM fn_get_eligible_sps() LIMIT 1"
        ))
        result_row = result.fetchone()
    
    if not result_row:
        print("❌ No SPs found in defect tracker with active app config")
        return
    
    app_id, app_name, sp_name = result_row
    
    # Process with Python navigation
    result = navigator.process_sp_with_python_navigation(app_id, app_name, sp_name)
    
    # Display results
    if result:
        print("\n" + "="*100)
        print("📊 RESULTS SUMMARY")
        print("="*100)
        print(f"Repository: {result.get('repository')}")
        print(f"Portfolio: {result.get('portfolio')}")
        print(f"SP File Path: {result.get('sp_file_path')}")
        print(f"SP Code Length: {len(result.get('sp_code', ''))} characters")
        print(f"Tables Found: {len(result.get('table_schemas', {}))}")
        for table, path in result.get('table_paths', {}).items():
            clean_name = table.split('.')[-1].strip('[]')
            print(f"  - {clean_name}: {path}")
        print("="*100)


if __name__ == "__main__":
    main()
