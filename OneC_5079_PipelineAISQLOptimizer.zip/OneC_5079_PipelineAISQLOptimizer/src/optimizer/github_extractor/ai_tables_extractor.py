"""
AI-Powered Table Name Extractor
Uses LLM (Azure OpenAI or Anthropic Claude) to intelligently extract real database tables from stored procedure code.
Provider is configured via LLM_PROVIDER in .env
"""

import os
import sys
import json
import traceback
from datetime import datetime
from zoneinfo import ZoneInfo

_IST = ZoneInfo("Asia/Kolkata")

# Support both: running as a package (relative imports) and running standalone
try:
    from ..models import get_session, DB_SCHEMA
    from ..utils.audit_logger import log_audit
except ImportError:
    _project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    if _project_root not in sys.path:
        sys.path.insert(0, _project_root)
    os.chdir(_project_root)
    from optimizer.models import get_session
    from optimizer.utils.audit_logger import log_audit


# Provider output-token maxima (set to maximum supported per model)
#   gpt-4.1 (Azure OpenAI)        max output: 32,768 tokens
#   claude-opus-4-6 (Anthropic)   max output: 64,000 tokens (default;
#                                 128K with extended thinking enabled)
_AZURE_MAX_OUTPUT_TOKENS  = 32768
_CLAUDE_MAX_OUTPUT_TOKENS = 64000

# Soft-warning threshold for input-prompt size (chars). Above this we
# log a PROMPT_LARGE event so we have a record if the AI ever truncates.
_PROMPT_LARGE_WARN_CHARS = 100000

class AITableExtractor:
    """
    Uses LLM (Azure OpenAI or Anthropic Claude) to extract real database table names from SP code.
    Provider is auto-detected from config (LLM_PROVIDER in .env).
    """

    def __init__(self):
        """
        Initialize LLM client based on configured provider (read from config).
        """
        try:
            from ..config import get_config
        except ImportError:
            import sys as _sys
            _proj = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            if _proj not in _sys.path:
                _sys.path.insert(0, _proj)
            from optimizer.config import get_config

        config = get_config()
        self.llm_provider = config.LLM_PROVIDER

        if self.llm_provider == 'azure_openai':
            from openai import AzureOpenAI
            self.client = AzureOpenAI(
                api_key=config.AZURE_OPENAI_API_KEY,
                azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
                api_version=config.AZURE_OPENAI_API_VERSION,
                max_retries=3,
                timeout=60.0,
            )
            self.deployment = config.AZURE_OPENAI_DEPLOYMENT
        elif self.llm_provider == 'vertex_ai':
            # AnthropicVertex uses Workload Identity — no API key required.
            # The pod's GSA must have roles/aiplatform.user on VERTEX_PROJECT_ID.
            from anthropic import AnthropicVertex
            self.client = AnthropicVertex(
                project_id=config.VERTEX_PROJECT_ID,
                region=config.VERTEX_LOCATION,
                max_retries=3,
                timeout=60.0,
            )
            self.claude_model = config.CLAUDE_MODEL
            self.claude_max_tokens = config.CLAUDE_MAX_TOKENS
        else:
            raise ValueError(
                f"Unsupported LLM_PROVIDER='{self.llm_provider}'. "
                "Valid values: 'azure_openai', 'vertex_ai'."
            )

    def extract_tables_from_sp(self, sp_name, sp_code):
        """
        Use Azure OpenAI to extract real table names from stored procedure code

        Args:
            sp_name: Name of the stored procedure
            sp_code: Full SQL code of the stored procedure

        Returns:
            dict: Contains table_names list and AI analysis
        """
        print(f"\n{'='*100}")
        print(f"🤖 AI Analysis for: {sp_name}")
        print(f"{'='*100}")

        # Construct the prompt for the AI
        prompt = f"""You are an expert SQL Server database analyst. Your task is to analyze the following stored procedure code and extract ONLY the real database tables that are being queried, inserted, updated, or deleted.

CRITICAL RULES:
1. Extract ONLY permanent database tables (with schema like [dbo].[TableName], [MLS].[TableName], etc.)
2. EXCLUDE the following:
   - Temporary tables (starting with #)
   - Table variables (starting with @)
   - Functions (containing _FN_ or _SP_)
   - Stored procedures being called
   - Common Table Expressions (CTEs)
   - System tables and views
   - Aliases and derived tables
3. Return tables in the format: [Schema].[TableName]
4. If schema is not explicitly mentioned, use [dbo].[TableName]
5. Be very careful to identify actual FROM/JOIN/INSERT/UPDATE/DELETE/MERGE operations on real tables

Stored Procedure: {sp_name}

SQL Code:
```sql
{sp_code}
```

Analyze the code thoroughly and return your response in the following JSON format:
{{
    "tables": [
        {{
            "schema": "SchemaName",
            "table_name": "TableName",
            "full_name": "[Schema].[TableName]",
            "operations": ["SELECT", "INSERT", "UPDATE", "DELETE"],
            "line_reference": "First line number where referenced (e.g. 'L120') — DO NOT list every occurrence"
        }}
    ],
    "temp_tables_excluded": ["List of temporary tables excluded"],
    "table_variables_excluded": ["List of table variables excluded"],
    "ctes_excluded": ["List of CTEs excluded"],
    "total_real_tables": 0,
    "analysis_notes": "Brief notes about the analysis (max 200 chars)"
}}

CRITICAL OUTPUT RULES:
- "line_reference" must be a SHORT string like "L120" (just the FIRST line number). DO NOT list every occurrence.
- "analysis_notes" must be at most 200 chars.
- Each table appears ONCE in the array — do NOT duplicate.
- Be thorough and accurate. Only include actual database tables that exist in the schema."""

        try:
            provider_name = "Azure OpenAI" if self.llm_provider == 'azure_openai' else "Claude"
            print(f"   📤 Sending to {provider_name} for analysis...")
            print(f"   SP Code Length: {len(sp_code)} characters")

            system_prompt = "You are an expert SQL Server database analyst specialized in parsing stored procedures and identifying real database tables. You are extremely accurate and follow instructions precisely. Always respond with valid JSON."

            # ── Pre-flight: warn-log when prompt is unusually large ──
            prompt_chars = len(prompt) + len(system_prompt)
            if prompt_chars > _PROMPT_LARGE_WARN_CHARS:
                log_audit(
                    "PROMPT_LARGE",
                    sp_name=sp_name,
                    message=(
                        f"Input prompt to AI table extractor is "
                        f"{prompt_chars:,} chars (warn threshold "
                        f"{_PROMPT_LARGE_WARN_CHARS:,}). Response may be "
                        f"truncated; JSON-repair fallback will activate if so."
                    ),
                    sp_code_chars=len(sp_code),
                )
                print(f"   ⚠ Large prompt: {prompt_chars:,} chars — "
                      f"audit logged as PROMPT_LARGE")

            truncated = False
            if self.llm_provider == 'azure_openai':
                response = self.client.chat.completions.create(
                    model=self.deployment,
                    max_tokens=_AZURE_MAX_OUTPUT_TOKENS,   # gpt-4.1 max
                    temperature=0.1,
                    response_format={"type": "json_object"},  # force valid JSON
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": prompt}
                    ]
                )
                ai_response = response.choices[0].message.content
                # OpenAI / Azure: finish_reason=='length' means cut by max_tokens
                truncated = (response.choices[0].finish_reason == "length")
                usage_str = (
                    f"prompt={getattr(response.usage, 'prompt_tokens', '?')}  "
                    f"completion={getattr(response.usage, 'completion_tokens', '?')}"
                    if getattr(response, 'usage', None) else "?"
                )
            else:
                ai_response = ""
                with self.client.messages.stream(
                    model=self.claude_model,
                    max_tokens=self.claude_max_tokens,
                    temperature=0.1,
                    system=system_prompt,
                    messages=[
                        {"role": "user", "content": prompt}
                    ],
                ) as stream:
                    for text in stream.text_stream:
                        ai_response += text
                    final_msg = stream.get_final_message()
                    truncated = (final_msg.stop_reason == "max_tokens")
                    usage_str = (
                        f"input={final_msg.usage.input_tokens}  "
                        f"output={final_msg.usage.output_tokens}"
                    )
            print(f"   ✅ Received AI response ({len(ai_response):,} chars, tokens: {usage_str})")

            if truncated:
                log_audit(
                    "TOKEN_OVERFLOW",
                    sp_name=sp_name,
                    message=(
                        f"AI response was truncated due to max_tokens limit "
                        f"({_AZURE_MAX_OUTPUT_TOKENS if self.llm_provider == 'azure_openai' else self.claude_max_tokens} "
                        f"tokens). JSON-repair fallback will attempt to recover "
                        f"complete table objects from the partial response."
                    ),
                    provider=self.llm_provider,
                    response_chars=len(ai_response),
                    sp_code_chars=len(sp_code),
                )
                print(f"   ⚠ Response truncated by max_tokens — "
                      f"audit logged as TOKEN_OVERFLOW")

            # Strip markdown code fences if Claude wrapped the JSON in ```json ... ```
            cleaned = ai_response.strip()
            if cleaned.startswith("```"):
                # Remove opening fence (```json or ```)
                first_newline = cleaned.index('\n')
                cleaned = cleaned[first_newline + 1:]
                # Remove closing fence
                if cleaned.rstrip().endswith("```"):
                    cleaned = cleaned.rstrip()[:-3].rstrip()

            # Parse JSON response — with repair fallback for truncated output
            result = self._parse_json_with_repair(cleaned)
            if result is None:
                raise json.JSONDecodeError(
                    "Could not parse JSON even after repair attempts", cleaned, 0
                )

            # Extract table names
            tables = result.get('tables', [])
            table_names = [table['full_name'] for table in tables]

            print(f"\n   📊 AI Analysis Results:")
            print(f"      Real Tables Found: {len(table_names)}")

            if result.get('temp_tables_excluded'):
                print(f"      Temp Tables Excluded: {len(result['temp_tables_excluded'])}")
            if result.get('table_variables_excluded'):
                print(f"      Table Variables Excluded: {len(result['table_variables_excluded'])}")
            if result.get('ctes_excluded'):
                print(f"      CTEs Excluded: {len(result['ctes_excluded'])}")

            print(f"\n   ✅ Real Database Tables:")
            for table in tables:
                operations = ", ".join(table.get('operations', []))
                print(f"      - {table['full_name']} ({operations})")

            if result.get('analysis_notes'):
                print(f"\n   📝 Analysis Notes: {result['analysis_notes']}")

            return {
                'sp_name': sp_name,
                'table_names': table_names,
                'detailed_tables': tables,
                'temp_tables_excluded': result.get('temp_tables_excluded', []),
                'table_variables_excluded': result.get('table_variables_excluded', []),
                'ctes_excluded': result.get('ctes_excluded', []),
                'analysis_notes': result.get('analysis_notes', ''),
                'total_tables': len(table_names)
            }

        except json.JSONDecodeError as e:
            error_text = f"JSON parsing failed: {e}\nRaw response: {ai_response[:500]}..."
            print(f"   ❌ Error parsing AI response as JSON: {e}")
            print(f"   Raw response: {ai_response[:500]}...")
            try:
                from ..utils.audit_logger import log_pipeline_error
                log_pipeline_error(
                    error_type='LLM_API_ERROR',
                    error=error_text,
                    sp_name=sp_name,
                )
            except:
                pass
            return None
        except Exception as e:
            error_text = f"{type(e).__name__}: {str(e)}\n{traceback.format_exc()}"
            print(f"   ❌ Error calling LLM API: {str(e)}")
            traceback.print_exc()
            try:
                from ..utils.audit_logger import log_pipeline_error
                log_pipeline_error(
                    error_type='LLM_API_ERROR',
                    error=error_text,
                    sp_name=sp_name,
                )
            except:
                pass
            return None

    def _parse_json_with_repair(self, raw):
        """
        Robust JSON parser. First tries strict json.loads. If that fails
        (e.g. response truncated mid-string by max_tokens), tries to repair
        by closing the open string + array + object so the partial result is
        still usable. Returns parsed dict or None.
        """
        try:
            return json.loads(raw)
        except json.JSONDecodeError as exc:
            print(f"   ⚠ Strict JSON parse failed: {exc} — attempting repair...")

        # Repair attempt: find the LAST complete table object inside "tables": [ ... ]
        # then close the array and outer object.
        try:
            tables_idx = raw.find('"tables"')
            if tables_idx == -1:
                return None
            arr_start = raw.find('[', tables_idx)
            if arr_start == -1:
                return None
            # Walk forward, tracking brace depth; collect complete {...} objects
            depth = 0
            obj_start = -1
            complete_objects = []
            i = arr_start + 1
            in_string = False
            escape_next = False
            while i < len(raw):
                ch = raw[i]
                if escape_next:
                    escape_next = False
                elif ch == '\\':
                    escape_next = True
                elif ch == '"' and not escape_next:
                    in_string = not in_string
                elif not in_string:
                    if ch == '{':
                        if depth == 0:
                            obj_start = i
                        depth += 1
                    elif ch == '}':
                        depth -= 1
                        if depth == 0 and obj_start != -1:
                            complete_objects.append(raw[obj_start:i + 1])
                            obj_start = -1
                i += 1

            if not complete_objects:
                return None

            repaired = (
                '{"tables": ['
                + ','.join(complete_objects)
                + '], "temp_tables_excluded": [], "table_variables_excluded": [], '
                + '"ctes_excluded": [], "analysis_notes": "(JSON repaired from truncated response)"}'
            )
            print(f"   ✓ JSON repair recovered {len(complete_objects)} complete table object(s).")
            return json.loads(repaired)
        except Exception as exc:
            print(f"   ⚠ JSON repair failed: {exc}")
            return None


def process_sps_from_database(db_path, sp_folder_path, output_file="ai_table_analysis.json"):
    """
    Process SPs from ado_defect_tracker table and extract tables using AI.
    LLM provider and credentials are read from config (LLM_PROVIDER in .env / ConfigMap).

    Args:
        db_path: Path to SQLite database
        sp_folder_path: Path to folder containing extracted SP .sql files
        output_file: Output JSON file to save results
    """
    print("\n" + "="*100)
    print("AI-POWERED TABLE EXTRACTION FROM STORED PROCEDURES")
    print("="*100)

    # Connect to database and get SPs from ado_defect_tracker
    print(f"\n📊 Connecting to database: {db_path}")

    from sqlalchemy import text
    with get_session() as session:
        result = session.execute(
            text(
                f'SELECT sp_id, sp_name, app_name, occurrence_count '
                f'FROM "{DB_SCHEMA}".ado_defect_tracker '
                f'ORDER BY occurrence_count DESC'
            )
        )
        sps_from_db = result.fetchall()

    print(f"   ✅ Found {len(sps_from_db)} SPs in ado_defect_tracker table")

    # Initialize AI extractor (reads LLM config automatically)
    extractor = AITableExtractor()

    print(f"\n📁 SP Code Folder: {sp_folder_path}")
    print(f"\n📁 SP Code Folder: {sp_folder_path}")

    all_results = []
    processed_count = 0
    skipped_count = 0

    for i, (sp_id, sp_name, app_name, occurrence_count) in enumerate(sps_from_db, 1):
        print(f"\n{'='*100}")
        print(f"[{i}/{len(sps_from_db)}] SP ID: {sp_id} | {sp_name} | App: {app_name} | Occurrences: {occurrence_count}")
        print(f"{'='*100}")

        # Look for the SP file in the folder
        # Try different possible file name formats
        possible_filenames = [
            f"{sp_name}.sql",
            f"{sp_name.upper()}.sql",
            f"{sp_name.lower()}.sql",
            f"[RDP].[{sp_name}].sql",
            f"[dbo].[{sp_name}].sql",
            f"[MLS].[{sp_name}].sql"
        ]

        file_path = None
        for filename in possible_filenames:
            test_path = os.path.join(sp_folder_path, filename)
            if os.path.exists(test_path):
                file_path = test_path
                break

        if not file_path:
            print(f"   ⚠️  SP file not found in folder. Tried: {possible_filenames[0]}")
            skipped_count += 1
            continue

        try:
            # Read SP code
            with open(file_path, 'r', encoding='utf-8') as f:
                sp_code = f.read()

            print(f"   📄 File: {os.path.basename(file_path)}")
            print(f"   📏 Size: {len(sp_code)} characters")

            # Extract tables using AI
            result = extractor.extract_tables_from_sp(sp_name, sp_code)

            if result:
                result['sp_id'] = sp_id
                result['app_name'] = app_name
                result['occurrence_count'] = occurrence_count
                result['file_name'] = os.path.basename(file_path)
                result['file_path'] = file_path
                all_results.append(result)
                processed_count += 1
                print(f"   ✅ Successfully analyzed")
            else:
                print(f"   ⚠️  Analysis failed")
                skipped_count += 1

        except Exception as e:
            print(f"   ❌ Error processing {sp_name}: {str(e)}")
            skipped_count += 1
            continue

    # Save results to JSON
    print(f"\n{'='*100}")
    print(f"SAVING RESULTS")
    print(f"{'='*100}")

    output_path = os.path.join(os.path.dirname(sp_folder_path), output_file)

    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)

    print(f"   💾 Saved to: {output_path}")

    # Print summary
    print(f"\n{'='*100}")
    print(f"SUMMARY")
    print(f"{'='*100}")
    print(f"   Total SPs in Database: {len(sps_from_db)}")
    print(f"   Successfully Analyzed: {processed_count}")
    print(f"   Skipped (not found/failed): {skipped_count}")
    print(f"   Total Unique Tables Found: {len(set(table for r in all_results for table in r['table_names']))}")

    # Print all unique tables
    unique_tables = sorted(set(table for r in all_results for table in r['table_names']))
    print(f"\n   📊 All Unique Tables ({len(unique_tables)}):")
    for table in unique_tables:
        # Count how many SPs use this table
        count = sum(1 for r in all_results if table in r['table_names'])
        print(f"      - {table} (used in {count} SP(s))")

    return all_results


def save_to_database(results, db_path="AI_SQL_Optimizer.db"):
    """
    Save AI-extracted table names to ai_sp_tables via stored procedures.

    Args:
        results: List of AI analysis results
        db_path: Kept for backward-compat signature; ignored (uses DATABASE_URL).
    """
    print(f"\n{'='*100}")
    print(f"SAVING TO DATABASE")
    print(f"{'='*100}")

    from sqlalchemy import text
    total_inserted = 0

    with get_session() as session:
        for result in results:
            sp_id    = result.get('sp_id', 0)
            sp_name  = result['sp_name']
            app_name = result.get('app_name', '')

            for table in result['detailed_tables']:
                session.execute(
                    text(
                        f'INSERT INTO "{DB_SCHEMA}".ai_sp_tables '
                        '(sp_id, sp_name, app_name, table_name, schema_name, operations, line_reference) '
                        'VALUES (:sp_id, :sp_name, :app_name, :table_name, :schema_name, :operations, :line_reference) '
                        'ON CONFLICT (sp_name, table_name) DO UPDATE SET '
                        '    sp_id = EXCLUDED.sp_id, '
                        '    app_name = EXCLUDED.app_name, '
                        '    schema_name = EXCLUDED.schema_name, '
                        '    operations = EXCLUDED.operations, '
                        '    line_reference = EXCLUDED.line_reference, '
                        '    extraction_date = :extraction_date'
                    ),
                    {
                        "sp_id":          sp_id,
                        "sp_name":        sp_name,
                        "app_name":       app_name,
                        "table_name":     table['full_name'],
                        "schema_name":    table.get('schema', 'dbo'),
                        "operations":     ','.join(table.get('operations', [])),
                        "line_reference": table.get('line_reference', ''),
                        "extraction_date": datetime.now(_IST).strftime('%Y-%m-%d %H:%M:%S'),
                    },
                )
                total_inserted += 1

    # Print stats via direct queries
    with get_session() as session:
        row = session.execute(
            text(
                f'SELECT COUNT(DISTINCT sp_name), COUNT(DISTINCT table_name), COUNT(*) '
                f'FROM "{DB_SCHEMA}".ai_sp_tables'
            )
        ).fetchone()
        sp_count, table_count, total_records = (row[0], row[1], row[2]) if row else (0, 0, 0)

    print(f"   ✅ Saved to database")
    print(f"   📊 Records Inserted/Updated: {total_inserted}")
    print(f"   📊 Total Records in Table: {total_records}")
    print(f"   📊 Unique SPs: {sp_count}")
    print(f"   📊 Unique Tables: {table_count}")


if __name__ == "__main__":
    # Configuration
    # Load configuration from .env file
    from config import get_config
    config = get_config()

    DB_PATH = config.DATABASE_PATH
    SP_FOLDER_PATH = r"C:\Users\2439899\Downloads\appd_sql\appd\extracted_sp_code"

    # Process SPs from database
    results = process_sps_from_database(
        db_path=DB_PATH,
        sp_folder_path=SP_FOLDER_PATH,
        output_file="ai_table_analysis.json"
    )

    # Save to database
    if results:
        save_to_database(results, DB_PATH)
    
    print("\n" + "="*100)
    print("✅ COMPLETED")
    print("="*100)
