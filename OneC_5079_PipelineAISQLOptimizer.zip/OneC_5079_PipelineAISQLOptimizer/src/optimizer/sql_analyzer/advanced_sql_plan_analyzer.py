"""
Advanced SQL Execution Plan Analyzer - Runtime Performance Focused
=================================================================
Identifies the TRUE performance bottlenecks based on actual execution metrics.
Falls back to estimated plan analysis when runtime data is not available.

Author: AI Assistant  
Date: January 12, 2026
Version: 5.0_Top5_Hybrid (Actual + Estimated Support)
Purpose: Extract the most critical performance issues from any SQL execution plan
"""

import re
import os
import json
import traceback
from datetime import datetime
from zoneinfo import ZoneInfo
from typing import Dict, List, Tuple, Optional

_IST = ZoneInfo("Asia/Kolkata")

# Import audit logger for error tracking
try:
    import sys
    _project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    if _project_root not in sys.path:
        sys.path.insert(0, _project_root)
    from optimizer.utils.audit_logger import log_pipeline_error
except ImportError:
    # Fallback if import fails (standalone mode)
    def log_pipeline_error(*args, **kwargs):
        pass

class AdvancedSQLPlanAnalyzer:
    def __init__(self):
        self.statements = []
        self.critical_operations = []
        
    def read_execution_plan(self, file_path: str) -> str:
        """Read execution plan with proper encoding detection."""
        encodings = ['utf-8', 'utf-16', 'utf-16le', 'utf-16be', 'cp1252']
        
        for encoding in encodings:
            try:
                with open(file_path, 'r', encoding=encoding) as f:
                    content = f.read()
                print(f"[OK] Successfully read execution plan using {encoding} encoding")
                print(f"  File size: {len(content):,} characters")
                return content
            except (UnicodeDecodeError, UnicodeError):
                continue
            except Exception as e:
                error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
                print(f"[FAILED] Error reading file with {encoding}: {e}")
                log_pipeline_error(
                    error_type='STAGE_ERROR',
                    error=error_text,
                    sp_name=f'(Analyzer: read_execution_plan {os.path.basename(file_path)})',
                )
                
        print("[FAILED] Failed to read file with any supported encoding")
        return None
    
    def decode_statement_text(self, encoded_text: str) -> str:
        """Decode HTML entities and format SQL text."""
        if not encoded_text:
            return ""
            
        # Decode HTML entities
        decoded = encoded_text.replace('&#xD;&#xA;', '\n')
        decoded = decoded.replace('&#xA;', '\n') 
        decoded = decoded.replace('&#xD;', '\n')
        decoded = decoded.replace('&gt;', '>')
        decoded = decoded.replace('&lt;', '<')
        decoded = decoded.replace('&amp;', '&')
        decoded = decoded.replace('&quot;', '"')
        decoded = decoded.replace('&apos;', "'")
        
        # Clean formatting
        lines = [line.strip() for line in decoded.split('\n') if line.strip()]
        return '\n'.join(lines)
    
    def extract_statement_info(self, content: str) -> List[Dict]:
        """Extract statement information, focusing on cost analysis."""
        statements = []
        
        # Find all StmtSimple opening tags (multi-line friendly)
        pattern = r'<StmtSimple\s+([^>]+)>'
        matches = re.finditer(pattern, content, re.DOTALL)
        
        for match in matches:
            full_match = match.group(0)
            attributes = match.group(1)
            
            # Extract required attributes
            stmt_id_match = re.search(r'StatementId="(\d+)"', attributes)
            if not stmt_id_match:
                continue
            stmt_id = int(stmt_id_match.group(1))
            
            # Extract cost (may not always be present)
            cost_match = re.search(r'StatementSubTreeCost="([^"]*)"', attributes)
            if cost_match:
                try:
                    cost = float(cost_match.group(1))
                except ValueError:
                    cost = 0.0
            else:
                cost = 0.0
            
            # Extract statement text
            text_match = re.search(r'StatementText="([^"]*?)"', attributes, re.DOTALL)
            statement_text = text_match.group(1) if text_match else f"Statement {stmt_id}"
            decoded_text = self.decode_statement_text(statement_text)
            
            # Extract additional metadata
            est_rows_match = re.search(r'StatementEstRows="([^"]*)"', attributes)
            est_rows = int(float(est_rows_match.group(1))) if est_rows_match else 0
            
            stmt_type_match = re.search(r'StatementType="([^"]*)"', attributes)
            stmt_type = stmt_type_match.group(1) if stmt_type_match else "UNKNOWN"
            
            statements.append({
                'statement_id': stmt_id,
                'cost': cost,
                'estimated_rows': est_rows,
                'statement_type': stmt_type,
                'statement_text': decoded_text,
                'raw_text': statement_text
            })
        
        return sorted(statements, key=lambda x: x['cost'], reverse=True)
    
    def extract_runtime_performance_operations(self, content: str, statement_id: int = None) -> List[Dict]:
        """Extract TOP 5 operations based on ACTUAL runtime performance across all statements."""
        all_operations = []
        
        # Extract all statement information first with simpler approach
        print(f"[DATA] Extracting statement information...")
        
        # Find all statement elements - using a simpler pattern
        stmt_starts = []
        for match in re.finditer(r'<StmtSimple[^>]*StatementId="(\d+)"[^>]*>', content):
            stmt_id = int(match.group(1))
            start_pos = match.start()
            
            # Extract StatementText from the opening tag
            opening_tag = match.group(0)
            text_match = re.search(r'StatementText="([^"]*)"', opening_tag)
            statement_text = text_match.group(1) if text_match else f"Statement {stmt_id}"
            
            stmt_starts.append({
                'id': stmt_id,
                'text': statement_text,
                'start_pos': start_pos
            })
        
        # Find statement content by looking for closing tags
        statements_info = {}
        for i, stmt_info in enumerate(stmt_starts):
            stmt_id = stmt_info['id']
            start_pos = stmt_info['start_pos']
            
            # Find the end position by looking for the closing </StmtSimple>
            end_search_start = start_pos + 50  # Start search after opening tag
            end_match = re.search(r'</StmtSimple>', content[end_search_start:])
            
            if end_match:
                end_pos = end_search_start + end_match.end()
                stmt_content = content[start_pos:end_pos]
                
                statements_info[stmt_id] = {
                    'statement_text': stmt_info['text'],
                    'content': stmt_content
                }
                
                print(f"[STMT] Statement {stmt_id}: {stmt_info['text'][:100]}..." if len(stmt_info['text']) > 100 else f"[STMT] Statement {stmt_id}: {stmt_info['text']}")
        
        print(f"[OK] Found {len(statements_info)} statements to analyze")
        
        # Process all statements to find operations
        for stmt_id, stmt_data in statements_info.items():
            stmt_content = stmt_data['content']
            statement_text = stmt_data['statement_text']
            
            print(f"[SEARCH] Analyzing Statement {stmt_id} ({len(stmt_content):,} chars)")
            
            # Find ALL RelOp elements with their NodeIds using a more flexible approach
            relop_simple_pattern = r'<RelOp[^>]*NodeId="(\d+)"[^>]*>'
            
            for relop_match in re.finditer(relop_simple_pattern, stmt_content):
                node_id = int(relop_match.group(1))
                relop_tag = relop_match.group(0)
                
                # Extract PhysicalOp and LogicalOp from the tag
                physical_match = re.search(r'PhysicalOp="([^"]*)"', relop_tag)
                logical_match = re.search(r'LogicalOp="([^"]*)"', relop_tag)
                
                physical_op = physical_match.group(1) if physical_match else "Unknown"
                logical_op = logical_match.group(1) if logical_match else "Unknown"
                
                # Look for RunTimeCountersPerThread in a reasonable range after this RelOp
                search_start = relop_match.end()
                search_range = stmt_content[search_start:search_start + 5000]  # Look within next 5000 chars
                
                # Use a more flexible runtime pattern that doesn't depend on attribute order
                runtime_match = re.search(r'<RunTimeCountersPerThread[^>]*>', search_range)
                
                if runtime_match:
                    runtime_tag = runtime_match.group(0)
                    
                    # Extract each attribute separately
                    elapsed_match = re.search(r'ActualElapsedms="(\d+)"', runtime_tag)
                    cpu_match = re.search(r'ActualCPUms="(\d+)"', runtime_tag)
                    rows_match = re.search(r'ActualRows="(\d+)"', runtime_tag)
                    executions_match = re.search(r'ActualExecutions="(\d+)"', runtime_tag)
                    
                    if elapsed_match and cpu_match and rows_match and executions_match:
                        try:
                            actual_elapsed_ms = int(elapsed_match.group(1))
                            actual_cpu_ms = int(cpu_match.group(1))
                            actual_rows = int(rows_match.group(1))
                            actual_executions = int(executions_match.group(1))
                            
                            # Extract additional details from the same search range
                            logical_reads = 0
                            physical_reads = 0
                            
                            logical_reads_match = re.search(r'ActualLogicalReads="(\d+)"', runtime_tag)
                            physical_reads_match = re.search(r'ActualPhysicalReads="(\d+)"', runtime_tag)
                            
                            if logical_reads_match:
                                logical_reads = int(logical_reads_match.group(1))
                            if physical_reads_match:
                                physical_reads = int(physical_reads_match.group(1))
                            
                            # Get detailed operator type
                            operator_type = self._get_detailed_operator_type(physical_op, logical_op, search_range)
                            
                            operation = {
                                'statement_id': stmt_id,
                                'statement_text': statement_text,
                                'node_id': node_id,
                                'physical_op': physical_op,
                                'logical_op': logical_op,
                                'operator_type': operator_type,
                                'actual_elapsed_ms': actual_elapsed_ms,
                                'actual_cpu_ms': actual_cpu_ms,
                                'actual_rows': actual_rows,
                                'actual_executions': actual_executions,
                                'actual_logical_reads': logical_reads,
                                'actual_physical_reads': physical_reads,
                                'scan_details': {},  # Simplified for now
                                'join_details': {},  # Simplified for now
                                'rank': 0  # Will be set after sorting
                            }
                            
                            all_operations.append(operation)
                            
                        except (ValueError, IndexError) as e:
                            print(f"[WARNING] Error parsing runtime data for Node {node_id}: {e}")
        
        # Sort by ActualElapsedms in descending order
        all_operations.sort(key=lambda x: x['actual_elapsed_ms'], reverse=True)
        
        # Assign ranks and take top 5
        top_operations = []
        for i, op in enumerate(all_operations[:5], 1):
            op['rank'] = i
            top_operations.append(op)
            print(f"[RANK] Rank {i}: Statement {op['statement_id']}, Node {op['node_id']}: {op['actual_elapsed_ms']:,}ms - {op['operator_type']}")
        
        print(f"[OK] Extracted top {len(top_operations)} operations from {len(all_operations)} total operations")
        return top_operations
    
    def extract_estimated_cost_operations(self, content: str) -> List[Dict]:
        """Extract TOP 5 operations based on ESTIMATED costs when runtime data is not available."""
        all_operations = []
        
        # Extract all statement information first
        print(f"[DATA] Extracting statement information...")
        
        # Find all statement elements
        stmt_starts = []
        for match in re.finditer(r'<StmtSimple[^>]*StatementId="(\d+)"[^>]*>', content, re.DOTALL):
            stmt_id = int(match.group(1))
            start_pos = match.start()
            
            # Extract StatementText from the opening tag
            opening_tag = match.group(0)
            text_match = re.search(r'StatementText="([^"]*)"', opening_tag)
            statement_text = text_match.group(1) if text_match else f"Statement {stmt_id}"
            
            stmt_starts.append({
                'id': stmt_id,
                'text': statement_text,
                'start_pos': start_pos
            })
        
        # Find statement content
        statements_info = {}
        for i, stmt_info in enumerate(stmt_starts):
            stmt_id = stmt_info['id']
            start_pos = stmt_info['start_pos']
            
            end_search_start = start_pos + 50
            end_match = re.search(r'</StmtSimple>', content[end_search_start:])
            
            if end_match:
                end_pos = end_search_start + end_match.end()
                stmt_content = content[start_pos:end_pos]
                
                statements_info[stmt_id] = {
                    'statement_text': stmt_info['text'],
                    'content': stmt_content
                }
                
                print(f"[STMT] Statement {stmt_id}: {stmt_info['text'][:100]}..." if len(stmt_info['text']) > 100 else f"[STMT] Statement {stmt_id}: {stmt_info['text']}")
        
        print(f"[OK] Found {len(statements_info)} statements to analyze")
        
        # Process all statements to find operations
        for stmt_id, stmt_data in statements_info.items():
            stmt_content = stmt_data['content']
            statement_text = stmt_data['statement_text']
            
            print(f"[SEARCH] Analyzing Statement {stmt_id} ({len(stmt_content):,} chars)")
            
            # Find all RelOp elements
            relop_pattern = r'<RelOp\s+([^>]+)>'
            
            for relop_match in re.finditer(relop_pattern, stmt_content, re.DOTALL):
                attributes = relop_match.group(1)
                
                # Extract NodeId
                node_id_match = re.search(r'NodeId="(\d+)"', attributes)
                if not node_id_match:
                    continue
                node_id = int(node_id_match.group(1))
                
                # Extract operators
                physical_op_match = re.search(r'PhysicalOp="([^"]*)"', attributes)
                logical_op_match = re.search(r'LogicalOp="([^"]*)"', attributes)
                
                if not physical_op_match:
                    continue
                    
                physical_op = physical_op_match.group(1)
                logical_op = logical_op_match.group(1) if logical_op_match else physical_op
                
                # Extract estimated costs
                subtree_cost_match = re.search(r'EstimatedTotalSubtreeCost="([^"]*)"', attributes)
                est_rows_match = re.search(r'EstimateRows="([^"]*)"', attributes)
                est_executions_match = re.search(r'EstimateExecutions="([^"]*)"', attributes)
                est_cpu_match = re.search(r'EstimateCPU="([^"]*)"', attributes)
                est_io_match = re.search(r'EstimateIO="([^"]*)"', attributes)
                
                try:
                    subtree_cost = float(subtree_cost_match.group(1)) if subtree_cost_match else 0.0
                    est_rows = int(float(est_rows_match.group(1))) if est_rows_match else 0
                    est_executions = int(float(est_executions_match.group(1))) if est_executions_match else 1
                    est_cpu = float(est_cpu_match.group(1)) if est_cpu_match else 0.0
                    est_io = float(est_io_match.group(1)) if est_io_match else 0.0
                    
                    # Get detailed operator type
                    operator_type = self._get_detailed_operator_type(physical_op, logical_op, attributes)
                    
                    operation = {
                        'statement_id': stmt_id,
                        'statement_text': statement_text,
                        'node_id': node_id,
                        'physical_op': physical_op,
                        'logical_op': logical_op,
                        'operator_type': operator_type,
                        'estimated_subtree_cost': subtree_cost,
                        'estimated_rows': est_rows,
                        'estimated_executions': est_executions,
                        'estimated_cpu_cost': est_cpu,
                        'estimated_io_cost': est_io,
                        'scan_details': {},
                        'join_details': {},
                        'rank': 0
                    }
                    
                    all_operations.append(operation)
                    
                except (ValueError, IndexError) as e:
                    continue
        
        if not all_operations:
            print(f"[WARNING] No operations found")
            return []
        
        # Sort by subtree cost (descending) and take top 5
        sorted_operations = sorted(all_operations, key=lambda x: x['estimated_subtree_cost'], reverse=True)
        top_operations = sorted_operations[:5]
        
        # Assign ranks
        for i, op in enumerate(top_operations, 1):
            op['rank'] = i
            print(f"[RANK] Rank {i}: Statement {op['statement_id']}, Node {op['node_id']}: Cost {op['estimated_subtree_cost']:.4f} - {op['operator_type']}")
        
        print(f"[OK] Extracted top {len(top_operations)} operations from {len(all_operations)} total operations")
        return top_operations
    
    def _get_detailed_operator_type(self, physical_op: str, logical_op: str, relop_content: str) -> str:
        """Get detailed operator type with context."""
        operator_type = f"{physical_op}"
        
        if "Scan" in physical_op:
            if "Table Scan" in physical_op:
                operator_type += " (Full Table)"
            elif "Index Scan" in physical_op:
                operator_type += " (Index)"
            elif "Clustered Index Scan" in physical_op:
                operator_type += " (Clustered)"
        
        elif "Join" in logical_op:
            if "Nested Loops" in physical_op:
                operator_type += " (Nested Loop Join)"
            elif "Hash" in physical_op:
                operator_type += " (Hash Join)"
            elif "Merge" in physical_op:
                operator_type += " (Merge Join)"
        
        elif "Sort" in physical_op:
            operator_type += " (Sorting)"
        
        elif "Filter" in physical_op:
            operator_type += " (Filtering)"
        
        return operator_type
    
    def _extract_scan_details(self, relop_content: str) -> Dict:
        """Extract scan-specific details."""
        details = {}
        
        # Look for TableScan details
        if "TableScan" in relop_content:
            table_match = re.search(r'Table="([^"]*)"', relop_content)
            if table_match:
                details['table_name'] = table_match.group(1)
                
            database_match = re.search(r'Database="([^"]*)"', relop_content)
            if database_match:
                details['database'] = database_match.group(1)
        
        # Look for IndexScan details  
        if "IndexScan" in relop_content:
            index_match = re.search(r'Index="([^"]*)"', relop_content)
            if index_match:
                details['index_name'] = index_match.group(1)
        
        return details
    
    def _extract_join_details(self, relop_content: str) -> Dict:
        """Extract join-specific details."""
        details = {}
        
        if "Join" in relop_content:
            # Look for join predicates
            predicate_match = re.search(r'<HashKeysBuild>.*?</HashKeysBuild>', relop_content, re.DOTALL)
            if predicate_match:
                details['join_type'] = 'Hash Join'
                details['build_side'] = predicate_match.group(0)
            
            # Look for nested loop joins
            if "NestedLoops" in relop_content:
                details['join_type'] = 'Nested Loop'
                outer_ref_match = re.search(r'<OuterReferences>.*?</OuterReferences>', relop_content, re.DOTALL)
                if outer_ref_match:
                    details['outer_references'] = outer_ref_match.group(0)
        
        return details
    
    def _generate_ai_context_for_top5(self, top_operations: List[Dict], is_runtime_data: bool = True) -> Dict:
        """Generate AI-ready optimization context for top 5 operations."""
        if is_runtime_data:
            return {
                'operation_count': len(top_operations),
                'total_elapsed_time_ms': sum([op['actual_elapsed_ms'] for op in top_operations]),
                'statements_affected': list(set([op['statement_id'] for op in top_operations])),
                'primary_bottlenecks': [
                    {
                        'rank': op['rank'],
                        'statement_id': op['statement_id'],
                        'node_id': op['node_id'], 
                        'operator_type': op['operator_type'],
                        'elapsed_ms': op['actual_elapsed_ms'],
                        'cpu_ms': op['actual_cpu_ms'],
                        'rows_processed': op['actual_rows'],
                        'optimization_priority': 'CRITICAL' if op['actual_elapsed_ms'] > 100000 else 'HIGH'
                    }
                    for op in top_operations
                ],
                'optimization_urgency': 'CRITICAL' if any(op['actual_elapsed_ms'] > 300000 for op in top_operations) else 'HIGH',
                'recommended_focus_areas': [
                    'Table scan optimization' if any('Table Scan' in op['operator_type'] for op in top_operations) else None,
                    'Join optimization' if any('Join' in op['operator_type'] for op in top_operations) else None,
                    'Index optimization' if any('Scan' in op['operator_type'] for op in top_operations) else None,
                    'Query rewrite' if any(op['actual_elapsed_ms'] > 400000 for op in top_operations) else None
                ]
            }
        else:
            # Estimated plan context
            return {
                'operation_count': len(top_operations),
                'total_estimated_cost': sum([op['estimated_subtree_cost'] for op in top_operations]),
                'statements_affected': list(set([op['statement_id'] for op in top_operations])),
                'primary_bottlenecks': [
                    {
                        'rank': op['rank'],
                        'statement_id': op['statement_id'],
                        'node_id': op['node_id'], 
                        'operator_type': op['operator_type'],
                        'estimated_cost': op['estimated_subtree_cost'],
                        'estimated_rows': op['estimated_rows'],
                        'optimization_priority': 'HIGH' if op['estimated_subtree_cost'] > 1.0 else 'MEDIUM'
                    }
                    for op in top_operations
                ],
                'optimization_urgency': 'HIGH' if any(op['estimated_subtree_cost'] > 10.0 for op in top_operations) else 'MEDIUM',
                'recommended_focus_areas': [
                    'Table scan optimization' if any('Table Scan' in op['operator_type'] for op in top_operations) else None,
                    'Join optimization' if any('Join' in op['operator_type'] for op in top_operations) else None,
                    'Index optimization' if any('Scan' in op['operator_type'] for op in top_operations) else None,
                    'Query rewrite' if any(op['estimated_subtree_cost'] > 20.0 for op in top_operations) else None
                ]
            }
        
    def _get_optimization_recommendation_for_operator(self, operation: Dict) -> str:
        """Get specific optimization recommendation for an operator."""
        op_type = operation['operator_type'].lower()
        elapsed_ms = operation['actual_elapsed_ms']
        
        if 'table scan' in op_type:
            return f"Critical table scan taking {elapsed_ms/1000:.1f}s - Add covering index or improve WHERE clause"
        elif 'nested loop' in op_type:
            return f"Expensive nested loop join taking {elapsed_ms/1000:.1f}s - Consider hash/merge join or add indexes"
        elif 'index scan' in op_type:
            return f"Costly index scan taking {elapsed_ms/1000:.1f}s - Consider covering index or seek operation"
        elif 'sort' in op_type:
            return f"Expensive sort operation taking {elapsed_ms/1000:.1f}s - Add index to avoid sorting"
        elif 'hash' in op_type:
            return f"Hash operation taking {elapsed_ms/1000:.1f}s - Review join conditions and statistics"
        elif 'filter' in op_type:
            return f"Expensive filter taking {elapsed_ms/1000:.1f}s - Move filter conditions earlier in plan"
        else:
            return f"Operation taking {elapsed_ms/1000:.1f}s - Review execution plan and consider query optimization"
    
    def _get_optimization_recommendation_for_estimated_operator(self, operation: Dict) -> str:
        """Get specific optimization recommendation for an operator with estimated data only."""
        op_type = operation['operator_type'].lower()
        cost = operation['estimated_subtree_cost']
        
        if 'table scan' in op_type:
            return f"Table scan with estimated cost {cost:.2f} - Add covering index or improve WHERE clause"
        elif 'nested loop' in op_type:
            return f"Nested loop join with estimated cost {cost:.2f} - Consider hash/merge join or add indexes"
        elif 'index scan' in op_type:
            return f"Index scan with estimated cost {cost:.2f} - Consider covering index or seek operation"
        elif 'sort' in op_type:
            return f"Sort operation with estimated cost {cost:.2f} - Add index to avoid sorting"
        elif 'hash' in op_type:
            return f"Hash operation with estimated cost {cost:.2f} - Review join conditions and statistics"
        elif 'filter' in op_type:
            return f"Filter with estimated cost {cost:.2f} - Move filter conditions earlier in plan"
        else:
            return f"Operation with estimated cost {cost:.2f} - Review execution plan and consider query optimization"
    
    def _calculate_performance_impact(self, elapsed_ms: int, rows: int, executions: int) -> float:
        """Calculate a performance impact score."""
        # Weight elapsed time heavily, then rows, then executions
        impact_score = (elapsed_ms * 10) + (rows * 0.001) + (executions * 0.1)
        return impact_score
    
    def _categorize_issue(self, physical_op: str, logical_op: str, elapsed_ms: int, rows: int, executions: int) -> str:
        """Categorize the performance issue type."""
        issues = []
        
        if elapsed_ms > 100000:  # > 100 seconds
            issues.append(f"CRITICAL_TIME({elapsed_ms/1000:.1f}s)")
        elif elapsed_ms > 30000:  # > 30 seconds
            issues.append(f"HIGH_TIME({elapsed_ms/1000:.1f}s)")
        elif elapsed_ms > 5000:   # > 5 seconds
            issues.append(f"MODERATE_TIME({elapsed_ms/1000:.1f}s)")
        
        if "Table Scan" in physical_op:
            issues.append("FULL_TABLE_SCAN")
        elif "Clustered Index Scan" in physical_op:
            issues.append("CLUSTERED_SCAN")
        elif "Index Scan" in physical_op:
            issues.append("INDEX_SCAN")
        
        if "Nested Loops" in logical_op and executions > 1000:
            issues.append(f"NESTED_LOOPS({executions:,}x)")
        
        if rows > 10000000:  # > 10M rows
            issues.append(f"MASSIVE_ROWS({rows:,})")
        elif rows > 1000000:  # > 1M rows
            issues.append(f"HIGH_ROWS({rows:,})")
        
        return " | ".join(issues) if issues else "PERFORMANCE_ISSUE"
    
    def generate_comprehensive_analysis(self, file_path: str) -> Dict:
        """Generate the complete analysis focusing on true performance bottlenecks."""
        print("\n" + "="*80)
        print("[ANALYZER] ADVANCED SQL EXECUTION PLAN ANALYZER")
        print("[FOCUS] TRUE Runtime Performance Bottlenecks")
        print("="*80)
        
        # Read execution plan
        content = self.read_execution_plan(file_path)
        if not content:
            return None
        
        # Extract statements
        print(f"\n[DATA] EXTRACTING STATEMENT ANALYSIS...")
        statements = self.extract_statement_info(content)
        
        if not statements:
            print("[FAILED] No statements found")
            return None
        
        print(f"[OK] Found {len(statements)} statements")
        
        # Show top statements by cost
        print(f"\n[COST] TOP 5 STATEMENTS BY COST:")
        for i, stmt in enumerate(statements[:5], 1):
            print(f"   {i}. Statement ID {stmt['statement_id']:2d}: ${stmt['cost']:>10,.2f} | {stmt['statement_type']}")
        
        # Analyze the highest cost statement
        highest_cost = statements[0]
        print(f"\n[ANALYZE] ANALYZING CRITICAL STATEMENT {highest_cost['statement_id']}:")
        print(f"   [COST] Total Cost: {highest_cost['cost']:,.2f}")
        print(f"   [DATA] Est. Rows: {highest_cost['estimated_rows']:,}")
        print(f"   [TYPE]  Type: {highest_cost['statement_type']}")
        
        # Extract ACTUAL performance bottlenecks across ALL statements
        print(f"\n[SEARCH] EXTRACTING TOP 5 RUNTIME PERFORMANCE OPERATIONS...")
        top_operations = self.extract_runtime_performance_operations(content)
        
        if not top_operations:
            print("[WARNING] No runtime data found - analyzing estimated plan instead")
            print(f"\n[SEARCH] EXTRACTING TOP 5 ESTIMATED COST OPERATIONS...")
            top_operations = self.extract_estimated_cost_operations(content)
            
            if not top_operations:
                print("[FAILED] No operations found in execution plan")
                return None
        
        # Show top 5 operations
        is_runtime_data = 'actual_elapsed_ms' in top_operations[0]
        
        if is_runtime_data:
            print(f"\n[ALERT] TOP 5 ACTUAL PERFORMANCE OPERATIONS:")
            for i, op in enumerate(top_operations, 1):
                print(f"   {i}. Rank {op['rank']:2d} | Statement {op['statement_id']:2d} | NodeId {op['node_id']:2d}: {op['operator_type']}")
                print(f"      [TIME]  ELAPSED: {op['actual_elapsed_ms']:>8,}ms ({op['actual_elapsed_ms']/1000:.1f}s)")
                print(f"      [CPU]  CPU: {op['actual_cpu_ms']:>8,}ms | [DATA] ROWS: {op['actual_rows']:>10,} | [EXEC] EXECUTIONS: {op['actual_executions']:,}")
                print(f"      [READS] READS: Logical:{op['actual_logical_reads']:,} | Physical:{op['actual_physical_reads']:,}")
                print()
        else:
            print(f"\n[ALERT] TOP 5 ESTIMATED COST OPERATIONS:")
            for i, op in enumerate(top_operations, 1):
                print(f"   {i}. Rank {op['rank']:2d} | Statement {op['statement_id']:2d} | NodeId {op['node_id']:2d}: {op['operator_type']}")
                print(f"      [COST]  Subtree Cost: {op['estimated_subtree_cost']:.4f} | [DATA] Est. Rows: {op['estimated_rows']:>10,} | [EXEC] Executions: {op['estimated_executions']:,}")
                if op.get('estimated_cpu_cost'):
                    print(f"      [CPU]   Est. CPU: {op['estimated_cpu_cost']:.4f} | [IO] Est. IO: {op.get('estimated_io_cost', 0):.4f}")
                print()
        
        # Generate comprehensive summary
        summary = {
            'analysis_metadata': {
                'file_analyzed': os.path.basename(file_path),
                'analysis_timestamp': datetime.now(_IST).isoformat(),
                'analyzer_version': "5.0_Top5_Hybrid",
                'total_statements': len(statements),
                'file_size_chars': len(content),
                'has_runtime_data': is_runtime_data
            },
            'top_05_operations': top_operations,
            'ai_optimization_context': self._generate_ai_context_for_top5(top_operations, is_runtime_data)
        }
        
        return summary

    def generate_comprehensive_analysis_from_string(self, xml_content: str) -> Dict:
        """Analyze plan XML supplied as a string — no file I/O, GKE-safe.

        Thin wrapper around generate_comprehensive_analysis: temporarily
        replaces read_execution_plan so the parent method receives the
        already-fetched XML instead of reading a file.
        """
        if not xml_content or not xml_content.strip():
            return None
        _original = self.read_execution_plan
        self.read_execution_plan = lambda _path: xml_content
        try:
            return self.generate_comprehensive_analysis("__in_memory__")
        finally:
            self.read_execution_plan = _original

    def extract_detailed_operation_info(self, content: str, statement_id: int, node_ids: List[int]) -> List[Dict]:
        """Extract comprehensive details for specific high-impact operations."""
        detailed_operations = []
        
        # Find the statement section
        stmt_pattern = rf'StatementId="{statement_id}".*?</StmtSimple>'
        stmt_match = re.search(stmt_pattern, content, re.DOTALL)
        
        if not stmt_match:
            return detailed_operations
        
        stmt_content = stmt_match.group(0)
        
        for node_id in node_ids:
            print(f"[SEARCH] Extracting detailed info for NodeId {node_id}...")
            
            # Find the specific RelOp section for this NodeId
            relop_pattern = rf'<RelOp[^>]*NodeId="{node_id}"[^>]*>.*?</RelOp>'
            relop_match = re.search(relop_pattern, stmt_content, re.DOTALL)
            
            if not relop_match:
                print(f"  [ERROR] Could not find RelOp for NodeId {node_id}")
                continue
                
            relop_section = relop_match.group(0)
            
            # Extract basic RelOp attributes
            relop_tag = re.search(r'<RelOp[^>]*>', relop_section).group(0)
            
            basic_info = self._extract_relop_attributes(relop_tag)
            
            # Extract RunTimeInformation
            runtime_info = self._extract_runtime_information(relop_section, node_id)
            
            # Extract join conditions and predicates
            join_info = self._extract_join_information(relop_section)
            
            # Extract table/index access information
            access_info = self._extract_access_information(relop_section)
            
            # Extract output columns
            output_info = self._extract_output_information(relop_section)
            
            # Extract seek predicates (for index operations)
            seek_info = self._extract_seek_information(relop_section)
            
            # Extract memory and resource usage
            resource_info = self._extract_resource_information(relop_section)
            
            detailed_op = {
                'node_id': node_id,
                'basic_operation': basic_info,
                'runtime_performance': runtime_info,
                'join_details': join_info,
                'data_access': access_info,
                'output_columns': output_info,
                'seek_predicates': seek_info,
                'resource_usage': resource_info,
                'optimization_hints': self._generate_operation_optimization_hints(
                    basic_info, runtime_info, join_info, access_info
                ),
                'raw_xml_section': relop_section
            }
            
            detailed_operations.append(detailed_op)
            print(f"  ✅ Extracted {len(detailed_op)} detail categories for NodeId {node_id}")
        
        return detailed_operations
    
    def _extract_relop_attributes(self, relop_tag: str) -> Dict:
        """Extract basic RelOp attributes."""
        attributes = {}
        
        patterns = {
            'logical_op': r'LogicalOp="([^"]*)"',
            'physical_op': r'PhysicalOp="([^"]*)"',
            'estimated_cost': r'EstimatedTotalSubtreeCost="([^"]*)"',
            'estimated_cpu': r'EstimateCPU="([^"]*)"',
            'estimated_io': r'EstimateIO="([^"]*)"',
            'estimated_rows': r'EstimateRows="([^"]*)"',
            'avg_row_size': r'AvgRowSize="([^"]*)"',
            'parallel': r'Parallel="([^"]*)"'
        }
        
        for key, pattern in patterns.items():
            match = re.search(pattern, relop_tag)
            if match:
                try:
                    value = match.group(1)
                    if key in ['estimated_cost', 'estimated_cpu', 'estimated_io']:
                        attributes[key] = float(value)
                    elif key in ['estimated_rows', 'avg_row_size']:
                        attributes[key] = int(float(value))
                    else:
                        attributes[key] = value
                except (ValueError, TypeError):
                    attributes[key] = value
            else:
                attributes[key] = None
        
        return attributes
    
    def _extract_runtime_information(self, relop_section: str, node_id: int) -> Dict:
        """Extract detailed runtime performance metrics."""
        runtime_info = {}
        
        # Find RunTimeInformation section
        runtime_pattern = r'<RunTimeInformation>.*?</RunTimeInformation>'
        runtime_match = re.search(runtime_pattern, relop_section, re.DOTALL)
        
        if runtime_match:
            runtime_section = runtime_match.group(0)
            
            # Extract all runtime metrics
            metrics = {
                'actual_elapsed_ms': r'ActualElapsedms="([^"]*)"',
                'actual_cpu_ms': r'ActualCPUms="([^"]*)"',
                'actual_rows': r'ActualRows="([^"]*)"',
                'actual_executions': r'ActualExecutions="([^"]*)"',
                'actual_logical_reads': r'ActualLogicalReads="([^"]*)"',
                'actual_physical_reads': r'ActualPhysicalReads="([^"]*)"',
                'actual_read_aheads': r'ActualReadAheads="([^"]*)"',
                'actual_scans': r'ActualScans="([^"]*)"',
                'actual_end_of_scans': r'ActualEndOfScans="([^"]*)"',
                'batches': r'Batches="([^"]*)"',
                'actual_rebinds': r'ActualRebinds="([^"]*)"',
                'actual_rewinds': r'ActualRewinds="([^"]*)"',
                'actual_rows_read': r'ActualRowsRead="([^"]*)"'
            }
            
            for key, pattern in metrics.items():
                match = re.search(pattern, runtime_section)
                if match:
                    try:
                        runtime_info[key] = int(match.group(1))
                    except ValueError:
                        runtime_info[key] = match.group(1)
                else:
                    runtime_info[key] = 0
        
        return runtime_info
    
    def _extract_join_information(self, relop_section: str) -> Dict:
        """Extract join operation details."""
        join_info = {}
        
        # Check for different join types
        join_types = ['NestedLoops', 'Hash', 'Merge']
        
        for join_type in join_types:
            pattern = rf'<{join_type}[^>]*>(.*?)</{join_type}>'
            match = re.search(pattern, relop_section, re.DOTALL)
            
            if match:
                join_info['join_type'] = join_type
                join_section = match.group(1)
                
                # Extract join-specific details
                if join_type == 'NestedLoops':
                    optimized_match = re.search(r'Optimized="([^"]*)"', relop_section)
                    join_info['optimized'] = optimized_match.group(1) if optimized_match else 'unknown'
                    
                    # Extract outer references (join keys)
                    outer_refs = []
                    outer_pattern = r'<OuterReferences>(.*?)</OuterReferences>'
                    outer_match = re.search(outer_pattern, join_section, re.DOTALL)
                    if outer_match:
                        col_pattern = r'<ColumnReference[^>]*Table="\[([^\]]*)\]"[^>]*Column="([^"]*)"'
                        col_matches = re.finditer(col_pattern, outer_match.group(1))
                        for col_match in col_matches:
                            outer_refs.append(f"{col_match.group(1)}.{col_match.group(2)}")
                    join_info['outer_references'] = outer_refs
                
                elif join_type == 'Hash':
                    # Extract hash keys
                    hash_keys_build = []
                    hash_keys_probe = []
                    
                    build_pattern = r'<HashKeysBuild>(.*?)</HashKeysBuild>'
                    build_match = re.search(build_pattern, join_section, re.DOTALL)
                    if build_match:
                        col_pattern = r'Column="([^"]*)"'
                        hash_keys_build = re.findall(col_pattern, build_match.group(1))
                    
                    probe_pattern = r'<HashKeysProbe>(.*?)</HashKeysProbe>'
                    probe_match = re.search(probe_pattern, join_section, re.DOTALL)
                    if probe_match:
                        col_pattern = r'Column="([^"]*)"'
                        hash_keys_probe = re.findall(col_pattern, probe_match.group(1))
                    
                    join_info['hash_keys_build'] = hash_keys_build
                    join_info['hash_keys_probe'] = hash_keys_probe
                
                # Extract join predicates/conditions
                predicate_pattern = r'<Predicate>(.*?)</Predicate>'
                predicate_match = re.search(predicate_pattern, join_section, re.DOTALL)
                if predicate_match:
                    scalar_pattern = r'ScalarString="([^"]*)"'
                    scalar_match = re.search(scalar_pattern, predicate_match.group(1))
                    if scalar_match:
                        join_info['predicate'] = scalar_match.group(1)
                
                break
        
        return join_info
    
    def _extract_access_information(self, relop_section: str) -> Dict:
        """Extract table/index access information."""
        access_info = {}
        
        # Check for different access methods
        access_patterns = {
            'table_scan': r'<TableScan[^>]*>(.*?)</TableScan>',
            'index_scan': r'<IndexScan[^>]*>(.*?)</IndexScan>',
            'clustered_scan': r'<ClusteredIndexScan[^>]*>(.*?)</ClusteredIndexScan>'
        }
        
        for access_type, pattern in access_patterns.items():
            match = re.search(pattern, relop_section, re.DOTALL)
            if match:
                access_info['access_method'] = access_type
                access_section = match.group(1)
                
                # Extract object information
                object_pattern = r'<Object[^>]*Database="\[([^\]]*)\]"[^>]*Schema="\[([^\]]*)\]"[^>]*Table="\[([^\]]*)\]"[^>]*(?:Index="\[([^\]]*)\]")?[^>]*(?:Alias="\[([^\]]*)\]")?'
                object_match = re.search(object_pattern, relop_section)
                if object_match:
                    access_info['database'] = object_match.group(1)
                    access_info['schema'] = object_match.group(2)
                    access_info['table'] = object_match.group(3)
                    access_info['index'] = object_match.group(4) if object_match.group(4) else None
                    access_info['alias'] = object_match.group(5) if object_match.group(5) else None
                
                # Extract scan properties
                scan_attrs = ['Ordered', 'ForcedIndex', 'ForceScan', 'ForceSeek']
                for attr in scan_attrs:
                    attr_pattern = rf'{attr}="([^"]*)"'
                    attr_match = re.search(attr_pattern, relop_section)
                    if attr_match:
                        access_info[attr.lower()] = attr_match.group(1)
                
                break
        
        return access_info
    
    def _extract_output_information(self, relop_section: str) -> List[str]:
        """Extract output column information."""
        output_columns = []
        
        output_pattern = r'<OutputList>(.*?)</OutputList>'
        output_match = re.search(output_pattern, relop_section, re.DOTALL)
        
        if output_match:
            col_pattern = r'<ColumnReference[^>]*(?:Table="\[([^\]]*)\]")?[^>]*Column="([^"]*)"'
            col_matches = re.finditer(col_pattern, output_match.group(1))
            
            for col_match in col_matches:
                table = col_match.group(1) if col_match.group(1) else ''
                column = col_match.group(2)
                if table:
                    output_columns.append(f"{table}.{column}")
                else:
                    output_columns.append(column)
        
        return output_columns
    
    def _extract_seek_information(self, relop_section: str) -> Dict:
        """Extract seek predicate information for index operations."""
        seek_info = {}
        
        seek_pattern = r'<SeekPredicates>(.*?)</SeekPredicates>'
        seek_match = re.search(seek_pattern, relop_section, re.DOTALL)
        
        if seek_match:
            seek_section = seek_match.group(1)
            
            # Extract seek keys
            seek_keys = []
            key_pattern = r'<RangeColumns>(.*?)</RangeColumns>'
            key_matches = re.finditer(key_pattern, seek_section, re.DOTALL)
            
            for key_match in key_matches:
                col_pattern = r'Column="([^"]*)"'
                columns = re.findall(col_pattern, key_match.group(1))
                seek_keys.extend(columns)
            
            seek_info['seek_keys'] = seek_keys
            
            # Extract seek expressions
            expr_pattern = r'<RangeExpressions>(.*?)</RangeExpressions>'
            expr_match = re.search(expr_pattern, seek_section, re.DOTALL)
            if expr_match:
                scalar_pattern = r'ScalarString="([^"]*)"'
                scalar_match = re.search(scalar_pattern, expr_match.group(1))
                if scalar_match:
                    seek_info['seek_expression'] = scalar_match.group(1)
        
        return seek_info
    
    def _extract_resource_information(self, relop_section: str) -> Dict:
        """Extract memory and resource usage information."""
        resource_info = {}
        
        # Memory grant information
        memory_pattern = r'<MemoryGrantInfo[^>]*SerialRequiredMemory="([^"]*)"[^>]*SerialDesiredMemory="([^"]*)"[^>]*RequiredMemory="([^"]*)"[^>]*DesiredMemory="([^"]*)"[^>]*RequestedMemory="([^"]*)"[^>]*GrantedMemory="([^"]*)"[^>]*MaxUsedMemory="([^"]*)"'
        memory_match = re.search(memory_pattern, relop_section)
        if memory_match:
            resource_info['memory'] = {
                'serial_required': memory_match.group(1),
                'serial_desired': memory_match.group(2),
                'required': memory_match.group(3),
                'desired': memory_match.group(4),
                'requested': memory_match.group(5),
                'granted': memory_match.group(6),
                'max_used': memory_match.group(7)
            }
        
        # Memory fractions for hash joins
        fraction_pattern = r'<MemoryFractions Input="([^"]*)" Output="([^"]*)"'
        fraction_match = re.search(fraction_pattern, relop_section)
        if fraction_match:
            resource_info['memory_fractions'] = {
                'input': fraction_match.group(1),
                'output': fraction_match.group(2)
            }
        
        return resource_info
    
    def _generate_operation_optimization_hints(self, basic_info: Dict, runtime_info: Dict, 
                                             join_info: Dict, access_info: Dict) -> List[str]:
        """Generate specific optimization hints for this operation."""
        hints = []
        
        # Performance-based hints
        if runtime_info.get('actual_elapsed_ms', 0) > 60000:  # > 1 minute
            hints.append(f"CRITICAL: Operation takes {runtime_info['actual_elapsed_ms']/1000:.1f} seconds - immediate optimization required")
        
        # Join optimization hints
        if join_info.get('join_type') == 'NestedLoops':
            executions = runtime_info.get('actual_executions', 0)
            if executions > 1000:
                hints.append(f"NESTED_LOOP_ISSUE: {executions:,} executions - consider hash/merge join")
            
            if join_info.get('optimized') == 'false':
                hints.append("JOIN_NOT_OPTIMIZED: Nested loop not optimized by SQL Server")
        
        # Table access hints
        if access_info.get('access_method') == 'table_scan':
            table = access_info.get('table', 'unknown')
            hints.append(f"TABLE_SCAN_DETECTED: Full scan on {table} - needs indexing")
        
        # Row processing hints
        actual_rows = runtime_info.get('actual_rows', 0)
        if actual_rows > 1000000:
            hints.append(f"HIGH_ROW_PROCESSING: {actual_rows:,} rows - consider filtering/partitioning")
        
        # I/O hints
        logical_reads = runtime_info.get('actual_logical_reads', 0)
        if logical_reads > 10000:
            hints.append(f"HIGH_IO: {logical_reads:,} logical reads - index optimization needed")
        
        return hints
        """Generate specific optimization priorities based on actual performance."""
        priorities = []
        
        for i, op in enumerate(top_operations, 1):
            if op['actual_elapsed_ms'] > 100000:  # > 100 seconds
                priorities.append(f"IMMEDIATE_ACTION_REQUIRED - NodeId {op['node_id']} takes {op['actual_elapsed_ms']/1000:.1f} seconds")
            elif op['actual_elapsed_ms'] > 30000:   # > 30 seconds
                priorities.append(f"HIGH_PRIORITY - NodeId {op['node_id']} takes {op['actual_elapsed_ms']/1000:.1f} seconds")
            
            if "FULL_TABLE_SCAN" in op['issue_category']:
                priorities.append(f"CREATE_INDEX - NodeId {op['node_id']} performing table scan on {op['actual_rows']:,} rows")
            
            if "NESTED_LOOPS" in op['issue_category'] and op['actual_executions'] > 5000:
                priorities.append(f"OPTIMIZE_JOIN - NodeId {op['node_id']} has {op['actual_executions']:,} nested loop executions")
        
        return priorities
    
    def _generate_ai_context(self, statement: Dict, critical_ops: List[Dict]) -> str:
        """Generate AI-ready optimization context."""
        context = f"""
CRITICAL SQL PERFORMANCE ANALYSIS FOR AI OPTIMIZATION
=====================================================

EXECUTION PLAN SUMMARY:
- Statement ID: {statement['statement_id']}
- Total Estimated Cost: {statement['cost']:,.2f} units  
- Statement Type: {statement['statement_type']}
- Estimated Rows: {statement['estimated_rows']:,}

PROBLEMATIC SQL QUERY:
{'-' * 60}
{statement['statement_text']}
{'-' * 60}

CRITICAL PERFORMANCE BOTTLENECKS (Ranked by Actual Runtime Impact):
"""
        
        for i, op in enumerate(critical_ops, 1):
            execution_time_seconds = op['actual_elapsed_ms'] / 1000
            context += f"""
BOTTLENECK #{i} - NodeId {op['node_id']} ({op['physical_op']}):
  🔥 ACTUAL ELAPSED TIME: {op['actual_elapsed_ms']:,}ms ({execution_time_seconds:.1f} seconds)
  [DATA] ACTUAL ROWS PROCESSED: {op['actual_rows']:,}
  [EXEC] ACTUAL EXECUTIONS: {op['actual_executions']:,}
  [SAVE] LOGICAL READS: {op['actual_logical_reads']:,}
  [COST] ESTIMATED COST: {op['estimated_cost']:,.2f}
  [ISSUES] PERFORMANCE ISSUES: {op['issue_category']}
  
  OPTIMIZATION FOCUS:
  - This operation consumes {execution_time_seconds:.1f} seconds of execution time
  - {'CRITICAL: Immediate optimization required' if execution_time_seconds > 60 else 'Significant performance impact'}
  - {'Table scan detected - needs indexing strategy' if 'SCAN' in op['issue_category'] else 'Join optimization may be needed'}
"""
        
        context += f"""

ROOT CAUSE ANALYSIS:
The query execution is dominated by {len(critical_ops)} critical operations.
The most expensive operation (NodeId {critical_ops[0]['node_id']}) alone takes {critical_ops[0]['actual_elapsed_ms']/1000:.1f} seconds.

IMMEDIATE ACTION ITEMS:
1. Focus on NodeId {critical_ops[0]['node_id']} - {critical_ops[0]['actual_elapsed_ms']/1000:.1f}s execution time
2. Analyze the join conditions and table access patterns
3. Create appropriate indexes to eliminate table scans
4. Consider query restructuring to reduce nested loop executions

This analysis provides the actual runtime bottlenecks for targeted optimization.
"""
        
        return context
    
    def save_analysis_report(self, summary: Dict, output_file: str = None) -> str:
        """Save detailed analysis report."""
        if not output_file:
            timestamp = datetime.now(_IST).strftime("%Y%m%d_%H%M%S")
            output_file = f"runtime_performance_analysis_{timestamp}.json"
        
        try:
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(summary, f, indent=2, ensure_ascii=False)
            print(f"\n[SAVE] Analysis report saved: {output_file}")
            return output_file
        except Exception as e:
            error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
            print(f"[FAILED] Error saving report: {e}")
            log_pipeline_error(
                error_type='STAGE_ERROR',
                error=error_text,
                sp_name=f'(Analyzer: save_analysis_report {output_file})',
            )
            return None
    
    def print_summary_report(self, summary: Dict):
        """Print comprehensive summary report for top 5 analysis."""
        print("\n" + "="*80)
        print("[SUMMARY] TOP 5 PERFORMANCE OPERATIONS SUMMARY")
        print("="*80)
        print(f"[FILE] File: {summary['analysis_metadata']['file_analyzed']}")
        print(f"[DATE] Analyzed: {summary['analysis_metadata']['analysis_timestamp']}")
        
        top_ops = summary.get('top_05_operations', [])
        is_runtime_data = summary['analysis_metadata'].get('has_runtime_data', False)
        
        print(f"\n[ALERT] TOP 5 PERFORMANCE OPERATIONS:")
        
        if is_runtime_data:
            for i, op in enumerate(top_ops, 1):
                print(f"\n   {i}. Rank {op['rank']:2d} | Statement {op['statement_id']:2d} | Node {op['node_id']:2d}")
                print(f"      [OPERATOR] Operator: {op['operator_type']}")
                print(f"      [TIME]  TIME: {op['actual_elapsed_ms']/1000:.1f} seconds ({op['actual_elapsed_ms']:,}ms)")
                print(f"      [DATA] DATA: {op['actual_rows']:,} rows | {op['actual_executions']:,} executions")
                print(f"      [CPU]  CPU: {op['actual_cpu_ms']:,}ms | [READS] READS: {op['actual_logical_reads']:,}")
        else:
            for i, op in enumerate(top_ops, 1):
                print(f"\n   {i}. Rank {op['rank']:2d} | Statement {op['statement_id']:2d} | Node {op['node_id']:2d}")
                print(f"      [OPERATOR] Operator: {op['operator_type']}")
                print(f"      [COST]  Estimated Cost: {op['estimated_subtree_cost']:.4f}")
                print(f"      [DATA] Est. Rows: {op['estimated_rows']:,} | Executions: {op['estimated_executions']:,}")
                if op.get('estimated_cpu_cost'):
                    print(f"      [CPU]  Est. CPU: {op['estimated_cpu_cost']:.4f} | [IO] Est. IO: {op.get('estimated_io_cost', 0):.4f}")
        
        print(f"\n[SUMMARY] OPERATION SUMMARY:")
        print(f"   [OPERATOR] Operations Analyzed: {len(top_ops)}")
        
        if is_runtime_data:
            print(f"   [TIME]  Total Elapsed Time: {sum([op['actual_elapsed_ms'] for op in top_ops])/1000:.1f} seconds")
        else:
            print(f"   [COST]  Total Estimated Cost: {sum([op['estimated_subtree_cost'] for op in top_ops]):.4f}")
        
        print(f"\n[AI] AI OPTIMIZATION READY:")
        ai_context = summary.get('ai_optimization_context', {})
        print(f"   [WARNING]  Optimization Urgency: {ai_context.get('optimization_urgency', 'UNKNOWN')}")
        print(f"   [FOCUS] Primary Focus: {', '.join([area for area in ai_context.get('recommended_focus_areas', []) if area])}")
        
        print("\n" + "="*80)
        print("[OK] TOP 5 ANALYSIS COMPLETE - Ready for Optimization")
        print("="*80)
    
    def _generate_ai_summary_from_detailed_ops(self, detailed_operations):
        """Generate AI-ready summary from detailed operations analysis."""
        ai_summary = {
            'critical_findings': [],
            'join_optimization_needed': [],
            'index_recommendations': [],
            'memory_concerns': [],
            'io_bottlenecks': []
        }
        
        for op in detailed_operations:
            # Extract basic info
            basic_info = op.get('basic_operation', {})
            runtime_info = op.get('runtime_performance', {})
            join_info = op.get('join_details', {})
            access_info = op.get('data_access', {})
            resource_info = op.get('resource_usage', {})
            
            # Add critical finding
            ai_summary['critical_findings'].append({
                'operation': basic_info.get('logical_operation', 'unknown'),
                'elapsed_ms': runtime_info.get('actual_elapsed_ms', 0),
                'description': f"{basic_info.get('logical_operation', 'unknown')} taking {runtime_info.get('actual_elapsed_ms', 0):,}ms"
            })
            
            # Check for join issues
            if join_info and join_info.get('type'):
                ai_summary['join_optimization_needed'].append({
                    'node_id': op['node_id'],
                    'join_type': join_info.get('type', 'unknown'),
                    'predicates': join_info.get('predicates', []),
                    'elapsed_ms': runtime_info.get('actual_elapsed_ms', 0)
                })
            
            # Check for index opportunities
            if access_info and access_info.get('scan_type'):
                if 'scan' in access_info.get('scan_type', '').lower():
                    ai_summary['index_recommendations'].append({
                        'table': access_info.get('table_name', 'unknown'),
                        'reason': f"{access_info.get('scan_type')} detected",
                        'seek_predicates': op.get('seek_predicates', {}).get('predicates', []),
                        'elapsed_ms': runtime_info.get('actual_elapsed_ms', 0)
                    })
            
            # Memory concerns
            if resource_info:
                memory_kb = resource_info.get('memory_grant_kb', 0)
                if memory_kb > 100000:  # > 100MB
                    ai_summary['memory_concerns'].append({
                        'node_id': op['node_id'],
                        'memory_kb': memory_kb,
                        'operation': basic_info.get('logical_operation', 'unknown')
                    })
            
            # I/O bottlenecks
            elapsed_ms = runtime_info.get('actual_elapsed_ms', 0)
            if elapsed_ms > 100000:  # > 100 seconds
                ai_summary['io_bottlenecks'].append({
                    'node_id': op['node_id'],
                    'elapsed_ms': elapsed_ms,
                    'operation': basic_info.get('logical_operation', 'unknown'),
                    'estimated_io_cost': basic_info.get('estimated_io_cost', 0)
                })
        
        return ai_summary
    
    def _generate_optimization_priorities(self, operations):
        """Generate optimization priorities based on analysis."""
        priorities = []
        
        for op in operations:
            priority = {
                'node_id': op['node_id'],
                'priority_level': 'CRITICAL' if op['actual_elapsed_ms'] > 400000 else 'HIGH',
                'operation_type': op['physical_op'],
                'issue': op['issue_category'],
                'impact_ms': op['actual_elapsed_ms'],
                'recommendation': self._get_optimization_recommendation(op)
            }
            priorities.append(priority)
        
        return priorities
    
    def _get_optimization_recommendation(self, operation):
        """Get specific optimization recommendation for an operation."""
        op_type = operation['physical_op'].lower()
        
        if 'nested loops' in op_type:
            return "Consider adding indexes on join columns or rewriting as hash/merge join"
        elif 'table scan' in op_type or 'clustered index scan' in op_type:
            return "Add covering index or improve WHERE clause filtering"
        elif 'hash match' in op_type:
            return "Review join conditions and consider statistics updates"
        elif 'sort' in op_type:
            return "Add index to avoid sorting or increase sort memory"
        else:
            return "Review execution plan and consider query rewrite"
    
    def _generate_ai_context(self, highest_cost_statement, critical_operations):
        """Generate context for AI optimization."""
        return {
            'query_complexity': 'HIGH' if highest_cost_statement['cost'] > 1000 else 'MEDIUM',
            'primary_bottlenecks': [op['issue_category'] for op in critical_operations],
            'optimization_urgency': 'CRITICAL' if any(op['actual_elapsed_ms'] > 400000 for op in critical_operations) else 'HIGH',
            'statement_summary': {
                'type': highest_cost_statement['statement_type'],
                'estimated_cost': highest_cost_statement['cost'],
                'estimated_rows': highest_cost_statement['estimated_rows']
            }
        }

def main():
    """Main execution function."""
    print("Advanced SQL Execution Plan Analyzer v5.0_Hybrid")
    print("Top 5 Performance Operations (Actual + Estimated Support)")
    print("="*60)
    
    # Find execution plan files
    current_dir = os.getcwd()
    execution_plans_dir = os.path.join(current_dir, "execution_plans")
    
    if not os.path.exists(execution_plans_dir):
        print(f"[ERROR] Directory not found: {execution_plans_dir}")
        return
    
    sqlplan_files = [f for f in os.listdir(execution_plans_dir) if f.endswith('.xml')]

    if not sqlplan_files:
        print(f"[ERROR] No .xml files found in directory: {execution_plans_dir}")
        print(f"[DIR] Directory: {current_dir}")
        return
    
    print(f"[INFO] Found {len(sqlplan_files)} execution plan file(s):")
    for i, file in enumerate(sqlplan_files, 1):
        print(f"   {i}. {file}")
    
    # Select file
    if len(sqlplan_files) == 1:
        selected_file = sqlplan_files[0]
        print(f"[SELECT] Auto-selecting: {selected_file}")
    else:
        # Auto-select the first file (no interactive input in production pipeline)
        selected_file = sqlplan_files[0]
        print(f"[SELECT] Auto-selecting first file: {selected_file}")
 
    
    # Build full file path
    full_file_path = os.path.join(execution_plans_dir, selected_file)
    
    # Run analysis
    analyzer = AdvancedSQLPlanAnalyzer()
    
    print(f"\n[EXEC] Analyzing: {selected_file}")
    print(f"[PATH] Full path: {full_file_path}")
    summary = analyzer.generate_comprehensive_analysis(full_file_path)
    
    if summary:
        # Display results
        analyzer.print_summary_report(summary)
        
        # Save report
        report_file = analyzer.save_analysis_report(summary)
        
        print(f"\n[REPORT] DELIVERABLES:")
        print(f"   [OK] Executive Summary: Displayed above")
        print(f"   [OK] Detailed JSON Report: {report_file}")
        print(f"   [OK] AI Optimization Context: Ready in JSON")
        
        # Show verification based on data type
        print(f"\n[SEARCH] VERIFICATION - Top 3 operations:")
        if 'top_05_operations' in summary and summary['top_05_operations']:
            is_runtime = summary['analysis_metadata'].get('has_runtime_data', False)
            for i, op in enumerate(summary['top_05_operations'][:3], 1):
                if is_runtime:
                    elapsed_sec = op['actual_elapsed_ms'] / 1000
                    print(f"   {i}. Statement {op['statement_id']}, Node {op['node_id']}: {op['actual_elapsed_ms']:,}ms ({elapsed_sec:.1f}s) - {op['operator_type']}")
                else:
                    print(f"   {i}. Statement {op['statement_id']}, Node {op['node_id']}: Cost {op['estimated_subtree_cost']:.4f} - {op['operator_type']}")
        else:
            print("   [OK] Analysis completed successfully - check JSON reports for detailed data")
            
    else:
        print("[ERROR] Analysis failed")

if __name__ == "__main__":
    main()
