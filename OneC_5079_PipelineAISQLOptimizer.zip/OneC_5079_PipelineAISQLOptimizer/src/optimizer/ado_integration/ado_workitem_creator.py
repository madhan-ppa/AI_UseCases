"""
Azure DevOps Work Item Creator
Creates bug work items in ADO with optimization recommendations and attaches optimized SQL files
"""

import requests
import json
import base64
import html as _html
import os
import re as _re
import sys
import warnings
from datetime import datetime
from zoneinfo import ZoneInfo
from typing import Dict, Optional

_IST = ZoneInfo("Asia/Kolkata")

# Support both: running as a package (relative imports) and running standalone
try:
    from ..models import get_session, DB_SCHEMA
    from ..utils.audit_logger import log_pipeline_error
    from ..utils.http_session import build_http_session, RateLimiter
    from ..utils.input_validator import InputValidator
except ImportError:
    _project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    if _project_root not in sys.path:
        sys.path.insert(0, _project_root)
    os.chdir(_project_root)
    from optimizer.models import get_session
    from optimizer.utils.audit_logger import log_pipeline_error
    from optimizer.utils.http_session import build_http_session, RateLimiter
    from optimizer.utils.input_validator import InputValidator


class ADOWorkItemCreator:
    """
    Creates and manages Azure DevOps work items for SQL optimization
    """
    
    def __init__(self, ado_org_url, ado_project, ado_pat_token, verify_ssl=True):
        """
        Initialize ADO Work Item Creator
        
        Args:
            ado_org_url: Azure DevOps organization URL (e.g., 'https://devopstest.cognizant.com/Default%20Portfolio')
            ado_project: Project name in ADO (e.g., '2090-RHMS')
            ado_pat_token: Personal Access Token for authentication
            verify_ssl: Whether to verify SSL certificates (set to False for self-signed certs in corporate environments)
        """
        self.ado_org_url = ado_org_url.rstrip('/')
        self.ado_project = ado_project
        self.ado_pat_token = ado_pat_token
        self.api_version = os.getenv('ADO_API_VERSION', '7.0')
        _env_verify = os.getenv('ADO_SSL_VERIFY', 'true').lower() not in ('false', '0', 'no')
        self.verify_ssl = verify_ssl and _env_verify
        
        # Disable SSL warnings if verification is disabled (common for corporate environments)
        if not self.verify_ssl:
            warnings.warn(
                "SSL certificate verification is disabled. This is expected for corporate environments with self-signed certificates.",
                UserWarning
            )
            requests.packages.urllib3.disable_warnings(requests.packages.urllib3.exceptions.InsecureRequestWarning)
        
        # Setup authentication header - PAT should be encoded as base64 with format: ":{PAT}"
        auth_string = f":{ado_pat_token}"
        encoded_auth = base64.b64encode(auth_string.encode('utf-8')).decode('utf-8')
        
        self.headers = {
            "Content-Type": "application/json-patch+json",
            "Authorization": f"Basic {encoded_auth}"
        }
        # Clear raw PAT from memory — encoded header is all we need
        del auth_string
        ado_pat_token = None
        self._session = build_http_session(verify_ssl=self.verify_ssl)
        self._rate_limiter = RateLimiter()
        
        self.db_name = os.getenv('DATABASE_PATH', 'AI_SQL_Optimizer.db')

    def _get_bug_field_ops(self) -> list:
        """
        Build JSON Patch 'add' operations for Bug work item fields defined in
        the environment variable ADO_BUG_FIELDS.

        VG / ConfigMap value (JSON string):
            ADO_BUG_FIELDS = {"System.Tags":"SQL-Optimization; Performance; AI-Generated","Microsoft.VSTS.Common.Priority":2,"Microsoft.VSTS.Common.Severity":"2 - High"}

        Returns an empty list when the env var is absent, blank, or unparseable.
        """
        raw = os.getenv('ADO_BUG_FIELDS', '').strip()
        if not raw:
            return []
        try:
            fields = json.loads(raw)
            if not isinstance(fields, dict):
                print("   [WARN] ADO_BUG_FIELDS is not a JSON object — skipping bug fields.")
                return []
            return [
                {"op": "add", "path": f"/fields/{field_name}", "value": field_value}
                for field_name, field_value in fields.items()
            ]
        except json.JSONDecodeError as exc:
            print(f"   [WARN] ADO_BUG_FIELDS could not be parsed as JSON ({exc}) — skipping bug fields.")
            return []

    def _get_custom_field_ops(self) -> list:
        """
        Build JSON Patch 'add' operations for any custom ADO fields defined in
        the environment variable ADO_CUSTOM_FIELDS.

        VG / ConfigMap value (JSON string):
            ADO_CUSTOM_FIELDS = {"Custom.SecurityReviewed":"NA","Custom.AIUseCase":"Yes","Custom.SecurityReviewCommentsorJustificationforNA":"Not Applicable"}

        Returns an empty list when the env var is absent, blank, or unparseable
        so that projects without custom fields are unaffected.
        """
        raw = os.getenv('ADO_CUSTOM_FIELDS', '').strip()
        if not raw:
            return []
        try:
            fields = json.loads(raw)
            if not isinstance(fields, dict):
                print("   [WARN] ADO_CUSTOM_FIELDS is not a JSON object — skipping custom fields.")
                return []
            return [
                {"op": "add", "path": f"/fields/{field_name}", "value": field_value}
                for field_name, field_value in fields.items()
            ]
        except json.JSONDecodeError as exc:
            print(f"   [WARN] ADO_CUSTOM_FIELDS could not be parsed as JSON ({exc}) — skipping custom fields.")
            return []

    def _post_with_custom_field_retry(self, api_url: str, base_payload: list, apply_custom_fields: bool = True) -> requests.Response:
        """
        POST to ADO with all custom/bug fields, auto-stripping any that the
        project rejects with HTTP 400. Handles two ADO 400 error classes:

          1. "TF51535: Cannot find field Custom.XYZ."
             — field doesn't exist in this project's process template.
             Strip from custom_ops (ADO_CUSTOM_FIELDS).

          2. RuleValidationException / invalidListValue
             — field exists but the supplied value is not in the project's
               allowed picklist (e.g. Activity = "n. Documentation" rejected).
             Strip that field from the full payload and retry.

        Core fields (System.Title, System.Description, AreaPath, etc.) are
        never stripped — only optional configurable fields are candidates.

        Args:
            api_url:              Full ADO REST endpoint URL.
            base_payload:         All JSON Patch ops including bug/custom fields.
            apply_custom_fields:  When True (User Story), appends ADO_CUSTOM_FIELDS ops.
                                  When False (Bug), only the fields already in
                                  base_payload (ADO_BUG_FIELDS) are used.

        Returns:
            The last requests.Response received (caller raises_for_status).
        """
        # Core fields that must never be stripped — stripping these would
        # break the work item entirely.
        _REQUIRED_PATHS = {
            "/fields/System.Title",
            "/fields/System.Description",
            "/fields/Microsoft.VSTS.TCM.ReproSteps",
            "/fields/Microsoft.VSTS.Common.AcceptanceCriteria",
            "/fields/System.AreaPath",
            "/fields/System.IterationPath",
        }

        # Only apply ADO_CUSTOM_FIELDS for User Story; Bug uses ADO_BUG_FIELDS
        # already baked into base_payload — never mix the two field sets.
        custom_ops = self._get_custom_field_ops() if apply_custom_fields else []
        # Mutable copy of base_payload so optional fields can be stripped
        current_base = list(base_payload)

        while True:
            # Merge base + custom ops, deduplicating by field path.
            # base_payload takes priority — custom_ops fields are dropped if
            # the same path already exists in base_payload (e.g. System.Tags
            # appears in both ADO_BUG_FIELDS and ADO_CUSTOM_FIELDS).
            seen_paths = {op["path"] for op in current_base}
            deduped_custom = [op for op in custom_ops if op["path"] not in seen_paths]
            payload = current_base + deduped_custom

            self._rate_limiter.check_request()
            response = self._session.post(
                api_url,
                headers=self.headers,
                json=payload,
                timeout=30,
            )

            # Success — return immediately
            if response.status_code in (200, 201):
                return response

            # Only auto-retry on 400
            if response.status_code != 400:
                return response

            # Parse ADO error body
            try:
                err_body = response.json()
                err_msg = err_body.get("message", "")
            except Exception:
                err_body = {}
                err_msg = response.text

            stripped = False

            # ── Case 1: "Cannot find field Custom.XYZ" (missing field) ──────
            match = _re.search(r"Cannot find field\s+([\w.]+)", err_msg, _re.IGNORECASE)
            if match:
                bad_field = match.group(1).rstrip('.')
                bad_path = f"/fields/{bad_field}"
                before = len(custom_ops)
                custom_ops = [op for op in custom_ops if op.get("path") != bad_path]
                if len(custom_ops) < before:
                    print(f"   [ADO RETRY] Project does not support '{bad_field}' — retrying without it.")
                    stripped = True
                else:
                    # Field not in custom_ops — try base payload
                    before_base = len(current_base)
                    current_base = [op for op in current_base
                                    if op.get("path") != bad_path or bad_path in _REQUIRED_PATHS]
                    if len(current_base) < before_base:
                        print(f"   [ADO RETRY] Project does not support '{bad_field}' — retrying without it.")
                        stripped = True

            # ── Case 2: RuleValidationException / invalidListValue ───────────
            # ADO returns customProperties.RuleValidationErrors with
            # fieldStatusFlags containing "invalidListValue" when a field
            # value is not in the project's allowed picklist.
            if not stripped:
                rule_errors = (err_body.get("customProperties") or {}).get("RuleValidationErrors") or []
                for rule_err in rule_errors:
                    flags = rule_err.get("fieldStatusFlags", "")
                    ref_name = rule_err.get("fieldReferenceName", "")
                    if "invalidListValue" in flags and ref_name:
                        bad_path = f"/fields/{ref_name}"
                        if bad_path in _REQUIRED_PATHS:
                            continue  # never strip required fields
                        before_base = len(current_base)
                        current_base = [op for op in current_base if op.get("path") != bad_path]
                        if len(current_base) < before_base:
                            print(f"   [ADO RETRY] Project rejects value for '{ref_name}' (not in allowed list) — retrying without it.")
                            stripped = True
                            break
                        # Also check custom_ops
                        before_c = len(custom_ops)
                        custom_ops = [op for op in custom_ops if op.get("path") != bad_path]
                        if len(custom_ops) < before_c:
                            print(f"   [ADO RETRY] Project rejects value for '{ref_name}' (not in allowed list) — retrying without it.")
                            stripped = True
                            break

            if not stripped:
                # 400 but nothing we can strip — return for caller to handle
                return response

            # loop and retry with reduced payload

    def create_bug_workitem(self, sp_id, sp_name, app_name, optimization_details, optimized_file_path):
        """
        Create a bug work item in ADO with optimization recommendations
        
        Args:
            sp_id: Stored procedure ID from defect tracker
            sp_name: Name of the stored procedure
            app_name: Application name
            optimization_details: Dictionary with optimization information
            optimized_file_path: Path to the optimized SQL file
            
        Returns:
            dict: Work item details including ID and URL
        """
        print(f"\n{'='*100}")
        print(f"CREATING ADO BUG WORK ITEM")
        print(f"{'='*100}")
        print(f"SP ID: {sp_id}")
        print(f"SP Name: {sp_name}")
        print(f"Application: {app_name}")
        
        try:
            # Step 1: Create the bug work item
            print(f"\n[Step 1/3] Creating bug work item in ADO...")
            work_item = self._create_bug(sp_name, app_name, optimization_details)
            
            if not work_item:
                print(f"❌ Failed to create work item")
                return None
            
            work_item_id = work_item['id']
            work_item_url = work_item.get('_links', {}).get('html', {}).get('href', 'N/A')
            
            print(f"✅ Bug work item created successfully")
            print(f"   Work Item ID: {work_item_id}")
            print(f"   URL: {work_item_url}")
            
            # Step 2: Attach optimized SQL file to the work item
            if optimized_file_path and os.path.exists(optimized_file_path):
                print(f"\n[Step 2/3] Attaching optimized SQL file to work item...")
                attachment_result = self._attach_file_to_workitem(work_item_id, optimized_file_path)
                
                if attachment_result:
                    print(f"✅ File attached successfully")
                else:
                    print(f"⚠️  Failed to attach file, but work item was created")
            else:
                print(f"\n[Step 2/3] Skipping file attachment - file not found")
            
            # Step 3: Update defect tracker with work item details
            print(f"\n[Step 3/3] Updating defect tracker with work item details...")
            self._update_defect_tracker(sp_id, work_item_id, "Active")
            print(f"✅ Defect tracker updated")
            
            print(f"\n{'='*100}")
            print(f"✅ ADO BUG WORK ITEM CREATION COMPLETE")
            print(f"{'='*100}")
            
            return {
                'success': True,
                'work_item_id': work_item_id,
                'work_item_url': work_item_url,
                'sp_id': sp_id,
                'sp_name': sp_name
            }
            
        except Exception as e:
            import traceback
            error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
            print(f"\n❌ Error creating ADO work item: {str(e)}")
            log_pipeline_error(
                error_type='ADO_API_ERROR',
                error=error_text,
                sp_id=sp_id,
                sp_name=sp_name,
            )
            return {
                'success': False,
                'error': str(e),
                'sp_id': sp_id,
                'sp_name': sp_name
            }
    
    def create_user_story(self, title="AISQLOptimization_Suggestions", description=None,
                          area_path=None, iteration_path=None):
        """
        Create or find a User Story in ADO for SQL optimization work items.
        This user story serves as the parent for all SQL optimization bugs.
        
        Args:
            title: Title of the user story (default: "AISQLOptimization_Suggestions")
            description: Description of the user story (optional)
            
        Returns:
            int: User Story work item ID, or None if failed
        """
        print(f"\n{'='*100}")
        print(f"CREATING/FINDING USER STORY")
        print(f"{'='*100}")
        print(f"User Story Title: {title}")
        
        try:
            # Step 1: Check if user story already exists
            print(f"\n[Step 1/2] Checking if user story already exists...")
            existing_story = self._find_user_story_by_title(title)
            
            if existing_story:
                story_id = existing_story['id']
                story_url = existing_story.get('_links', {}).get('html', {}).get('href', 'N/A')
                print(f"✅ User Story already exists")
                print(f"   Work Item ID: {story_id}")
                print(f"   URL: {story_url}")
                return story_id
            
            # Step 2: Create new user story if it doesn't exist
            print(f"\n[Step 2/2] Creating new user story...")
            
            # Build default description if not provided
            if not description:
                description = f"""<div>
<h2>AI-Driven SQL Optimization Suggestions</h2>

<h3>📋 Purpose</h3>
<p>This user story serves as the parent container for all AI-generated SQL optimization work items. 
All bugs related to SQL performance improvements will be linked under this user story.</p>

<h3>🎯 Objective</h3>
<p>Improve application performance by optimizing slow SQL stored procedures identified through:</p>
<ul>
<li>AppDynamics performance monitoring</li>
<li>Execution plan analysis</li>
<li>AI-powered code optimization</li>
</ul>

<h3>🤖 AI Optimization Process</h3>
<ol>
<li><strong>Detection:</strong> Slow stored procedures identified via AppDynamics</li>
<li><strong>Analysis:</strong> Execution plans analyzed for bottlenecks</li>
<li><strong>Extraction:</strong> SP code extracted from GitHub</li>
<li><strong>Optimization:</strong> Multi-agent AI system generates optimized SQL</li>
<li><strong>Tracking:</strong> Bug work items created for each optimization</li>
</ol>

<h3>📊 Expected Outcomes</h3>
<ul>
<li>Reduced query execution time</li>
<li>Lower CPU and I/O usage</li>
<li>Improved application responsiveness</li>
<li>Better index utilization</li>
<li>Enhanced overall system performance</li>
</ul>

<h3>⚙️ Automation</h3>
<p>This user story and its child bugs are automatically created by the AI SQL Optimizer system.</p>
<p><strong>Generated On:</strong> {datetime.now(_IST).strftime('%Y-%m-%d %H:%M:%S')}</p>
</div>"""
            
            # Construct work item API endpoint for User Story
            api_url = f"{self.ado_org_url}/{self.ado_project}/_apis/wit/workitems/$User Story?api-version={self.api_version}"
            
            # Construct payload using JSON Patch format.
            # NOTE: System.Tags and Microsoft.VSTS.Common.Priority are intentionally
            # NOT hardcoded here — they are supplied via ADO_CUSTOM_FIELDS (VG) so
            # they can be changed without a code deploy and will be auto-stripped on
            # projects that don't support them.
            payload = [
                {
                    "op": "add",
                    "path": "/fields/System.Title",
                    "value": title
                },
                {
                    "op": "add",
                    "path": "/fields/System.Description",
                    "value": description
                },
                {
                    "op": "add",
                    "path": "/fields/System.AreaPath",
                    "value": area_path or self.ado_project
                },
                {
                    "op": "add",
                    "path": "/fields/System.IterationPath",
                    "value": iteration_path or self.ado_project
                }
            ]
            
            print(f"   Sending request to ADO API...")
            print(f"   URL: {api_url}")

            # Use retry helper — automatically strips unsupported Custom.* fields on 400
            response = self._post_with_custom_field_retry(api_url, payload, apply_custom_fields=True)

            response.raise_for_status()
            work_item = response.json()
            
            story_id = work_item['id']
            story_url = work_item.get('_links', {}).get('html', {}).get('href', 'N/A')
            
            print(f"✅ User Story created successfully")
            print(f"   Work Item ID: {story_id}")
            print(f"   URL: {story_url}")
            
            print(f"\n{'='*100}")
            print(f"✅ USER STORY CREATION COMPLETE")
            print(f"{'='*100}")
            
            return story_id
            
        except requests.exceptions.HTTPError as e:
            import traceback
            error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
            print(f"   ❌ HTTP Error: {e.response.status_code}")
            print(f"   Response: {e.response.text}")
            log_pipeline_error(
                error_type='ADO_API_ERROR',
                error=error_text,
                sp_name='(ADO: create_user_story)',
            )
            return None
        except requests.exceptions.RequestException as e:
            import traceback
            error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
            print(f"   ❌ Request Error: {str(e)}")
            if hasattr(e, 'response') and e.response is not None:
                print(f"   Response: {e.response.text}")
            log_pipeline_error(
                error_type='ADO_API_ERROR',
                error=error_text,
                sp_name='(ADO: create_user_story)',
            )
            return None
        except Exception as e:
            import traceback
            error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
            print(f"   ❌ Error: {str(e)}")
            log_pipeline_error(
                error_type='ADO_API_ERROR',
                error=error_text,
                sp_name='(ADO: create_user_story)',
            )
            return None
    
    def _find_user_story_by_title(self, title):
        """
        Search for an existing user story by title using WIQL query
        
        Args:
            title: Title of the user story to find
            
        Returns:
            dict: Work item details if found, None otherwise
        """
        try:
            # Use WIQL (Work Item Query Language) to search
            wiql_url = f"{self.ado_org_url}/{self.ado_project}/_apis/wit/wiql?api-version={self.api_version}"
            
            # Query for User Story with exact title
            # Escape single quotes — WIQL uses single-quoted string literals;
            # an unescaped apostrophe in title or project name breaks the query
            # syntax and causes WIQL injection.
            _safe_wiql_title   = title.replace("'", "''")
            _safe_wiql_project = self.ado_project.replace("'", "''")
            wiql_query = {
                "query": f"SELECT [System.Id], [System.Title], [System.State] FROM workitems WHERE [System.WorkItemType] = 'User Story' AND [System.Title] = '{_safe_wiql_title}' AND [System.TeamProject] = '{_safe_wiql_project}'"
            }
            
            # Use application/json for WIQL queries
            wiql_headers = {
                "Content-Type": "application/json",
                "Authorization": self.headers["Authorization"]
            }
            
            self._rate_limiter.check_request()
            response = self._session.post(
            wiql_url,
            headers=wiql_headers,
            json=wiql_query,
            timeout=30
            )
            
            response.raise_for_status()
            result = response.json()
            
            # Check if any work items were found
            if result.get('workItems') and len(result['workItems']) > 0:
                work_item_id = result['workItems'][0]['id']
                
                # Get full work item details
                work_item_url = f"{self.ado_org_url}/{self.ado_project}/_apis/wit/workitems/{work_item_id}?api-version={self.api_version}"
                self._rate_limiter.check_request()
                work_item_response = self._session.get(
                    work_item_url,
                    headers=self.headers,
                    timeout=30
                )
                
                work_item_response.raise_for_status()
                return work_item_response.json()
            
            return None
            
        except requests.exceptions.HTTPError as e:
            import traceback
            error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
            print(f"   ⚠️ HTTP Error searching for user story: {e.response.status_code}")
            if hasattr(e.response, 'text'):
                print(f"   Response: {e.response.text[:200]}")
            log_pipeline_error(
                error_type='ADO_API_ERROR',
                error=error_text,
                sp_name='(ADO: find_user_story)',
            )
            return None
        except Exception as e:
            import traceback
            error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
            print(f"   ⚠️ Error searching for user story: {str(e)}")
            log_pipeline_error(
                error_type='ADO_API_ERROR',
                error=error_text,
                sp_name='(ADO: find_user_story)',
            )
            return None
    
    def create_bug_under_user_story(self, user_story_id, sp_name, app_name, optimization_details,
                                    area_path=None, iteration_path=None):
        """
        Create a bug work item under a specific user story (parent-child relationship)
        
        Args:
            user_story_id: ID of the parent user story
            sp_name: Name of the stored procedure
            app_name: Application name
            optimization_details: Dictionary with optimization information
            
        Returns:
            int: Bug work item ID, or None if failed
        """
        print(f"\n{'='*100}")
        print(f"CREATING BUG UNDER USER STORY")
        print(f"{'='*100}")
        print(f"Parent User Story ID: {user_story_id}")
        print(f"SP Name: {sp_name}")
        print(f"Application: {app_name}")
        
        try:
            # Step 1: Create the bug work item
            print(f"\n[Step 1/2] Creating bug work item...")
            work_item = self._create_bug(sp_name, app_name, optimization_details,
                                         area_path=area_path, iteration_path=iteration_path)
            
            if not work_item:
                print(f"❌ Failed to create bug work item")
                return None
            
            bug_id = work_item['id']
            bug_url = work_item.get('_links', {}).get('html', {}).get('href', 'N/A')
            
            print(f"✅ Bug work item created successfully")
            print(f"   Work Item ID: {bug_id}")
            print(f"   URL: {bug_url}")
            
            # Step 2: Link bug to user story (parent-child relationship)
            print(f"\n[Step 2/2] Linking bug to user story (parent-child)...")
            link_success = self._link_bug_to_user_story(bug_id, user_story_id)
            
            if link_success:
                print(f"✅ Bug successfully linked to User Story {user_story_id}")
            else:
                print(f"⚠️  Bug created but failed to link to User Story")
            
            print(f"\n{'='*100}")
            print(f"✅ BUG CREATION COMPLETE")
            print(f"{'='*100}")
            
            return bug_id
            
        except Exception as e:
            import traceback
            error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
            print(f"\n❌ Error creating bug under user story: {str(e)}")
            log_pipeline_error(
                error_type='ADO_API_ERROR',
                error=error_text,
                sp_name=sp_name,
            )
            return None
    
    def _link_bug_to_user_story(self, bug_id, user_story_id):
        """
        Create parent-child relationship between user story and bug
        
        Args:
            bug_id: ID of the bug work item
            user_story_id: ID of the parent user story
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # API endpoint to update the bug work item
            api_url = f"{self.ado_org_url}/{self.ado_project}/_apis/wit/workitems/{bug_id}?api-version={self.api_version}"
            
            # Create parent relationship (User Story is parent of Bug)
            payload = [
                {
                    "op": "add",
                    "path": "/relations/-",
                    "value": {
                        "rel": "System.LinkTypes.Hierarchy-Reverse",  # Bug is child
                        "url": f"{self.ado_org_url}/{self.ado_project}/_apis/wit/workitems/{user_story_id}",
                        "attributes": {
                            "comment": "Linked to AI SQL Optimization parent user story"
                        }
                    }
                }
            ]
            
            self._rate_limiter.check_request()
            response = self._session.patch(
                api_url,
                headers=self.headers,
                json=payload,
                timeout=30
            )
            
            response.raise_for_status()
            return True
            
        except requests.exceptions.HTTPError as e:
            import traceback
            error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
            print(f"   ❌ HTTP Error linking bug to user story: {e.response.status_code}")
            print(f"   Response: {e.response.text}")
            log_pipeline_error(
                error_type='ADO_API_ERROR',
                error=error_text,
                sp_name='(ADO: link_bug_to_user_story)',
            )
            return False
        except Exception as e:
            import traceback
            error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
            print(f"   ❌ Error linking bug to user story: {str(e)}")
            log_pipeline_error(
                error_type='ADO_API_ERROR',
                error=error_text,
                sp_name='(ADO: link_bug_to_user_story)',
            )
            return False
    
    def attach_content_to_work_item(self, work_item_id, file_content: bytes, filename: str):
        """
        Upload in-memory content as an attachment to a work item.
        No file on disk is required — content bytes are uploaded directly.

        Args:
            work_item_id: ADO work item ID
            file_content:  bytes to upload (e.g. report_content.encode('utf-8'))
            filename:      filename shown in ADO (e.g. 'usp_MyProc_20260430.md')

        Returns:
            bool: True if successful, False otherwise
        """
        try:
            upload_url = (f"{self.ado_org_url}/_apis/wit/attachments"
                          f"?fileName={filename}&api-version={self.api_version}")
            upload_headers = {
                "Content-Type": "application/octet-stream",
                "Authorization": self.headers["Authorization"]
            }
            self._rate_limiter.check_request()
            upload_response = self._session.post(
                upload_url, headers=upload_headers,
                data=file_content, timeout=30
            )
            upload_response.raise_for_status()
            attachment_ref = upload_response.json()
            print(f"   Report uploaded to ADO, URL: {attachment_ref['url']}")

            link_url = (f"{self.ado_org_url}/{self.ado_project}/_apis/wit/workitems"
                        f"/{work_item_id}?api-version={self.api_version}")
            link_payload = [{
                "op": "add",
                "path": "/relations/-",
                "value": {
                    "rel": "AttachedFile",
                    "url": attachment_ref['url'],
                    "attributes": {"comment": "AI-Optimized SQL report generated by SQL Optimizer"}
                }
            }]
            self._rate_limiter.check_request()
            link_response = self._session.patch(
                link_url, headers=self.headers,
                json=link_payload, timeout=30
            )
            link_response.raise_for_status()
            print(f"   Attachment linked to work item #{work_item_id}")
            return True

        except requests.exceptions.HTTPError as e:
            import traceback
            error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
            print(f"   HTTP Error attaching content: {e.response.status_code} — {e.response.text}")
            log_pipeline_error(
                error_type='ADO_API_ERROR',
                error=error_text,
                sp_name=f'(ADO: attach_content work_item#{work_item_id})',
            )
            return False
        except Exception as e:
            import traceback
            error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
            print(f"   Error attaching content: {e}")
            log_pipeline_error(
                error_type='ADO_API_ERROR',
                error=error_text,
                sp_name=f'(ADO: attach_content work_item#{work_item_id})',
            )
            return False

    def attach_file_to_work_item(self, work_item_id, file_path):
        """
        Public method to attach a file to any work item (Bug or User Story)
        
        Args:
            work_item_id: ID of the work item
            file_path: Path to the file to attach
            
        Returns:
            bool: True if successful, False otherwise
        """
        print(f"\n{'='*100}")
        print(f"ATTACHING FILE TO WORK ITEM")
        print(f"{'='*100}")
        print(f"Work Item ID: {work_item_id}")
        print(f"File Path: {file_path}")
        
        if not os.path.exists(file_path):
            print(f"❌ File not found: {file_path}")
            return False
        
        try:
            result = self._attach_file_to_workitem(work_item_id, file_path)
            
            if result:
                print(f"\n{'='*100}")
                print(f"✅ FILE ATTACHMENT COMPLETE")
                print(f"{'='*100}")
            else:
                print(f"\n{'='*100}")
                print(f"❌ FILE ATTACHMENT FAILED")
                print(f"{'='*100}")
            
            return result
            
        except Exception as e:
            import traceback
            error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
            print(f"\n❌ Error attaching file: {str(e)}")
            log_pipeline_error(
                error_type='ADO_API_ERROR',
                error=error_text,
                sp_name=f'(ADO: attach_file_to_work_item work_item#{work_item_id})',
            )
            return False
    
    def _create_bug(self, sp_name, app_name, optimization_details,
                    area_path=None, iteration_path=None):
        """
        Create bug work item with optimization details
        
        Args:
            sp_name: Stored procedure name
            app_name: Application name
            optimization_details: Optimization information
            
        Returns:
            dict: Created work item details
        """
        # Construct work item API endpoint with api-version parameter
        api_url = f"{self.ado_org_url}/{self.ado_project}/_apis/wit/workitems/$Bug?api-version={self.api_version}"
        
        # Extract optimization details
        optimized_sql = optimization_details.get('optimized_sql', 'N/A')
        usage = optimization_details.get('usage', {})
        occurrence_count = optimization_details.get('occurrence_count', 0)
        execution_plan_issues = optimization_details.get('execution_plan_issues', 'N/A')
        defect_id_history    = optimization_details.get('defect_id_history', None)
        reoptimization_count = optimization_details.get('reoptimization_count', 0)
        
        # Unique title per optimization cycle — prevents confusion across re-runs
        # Strip <, >, & — these chars break ADO's XML-based API payload (XML injection)
        _safe_title = _re.sub(r'[<>&]', '', sp_name)
        bug_timestamp = datetime.now(_IST).strftime('%d:%m:%Y:%H:%M:%S')
        title = f"SQL Optimization Required: {_safe_title}_{bug_timestamp}"
        
        # Build concise description
        description = self._build_work_item_description(
            sp_name=sp_name,
            app_name=app_name,
            occurrence_count=occurrence_count,
            execution_plan_issues=execution_plan_issues,
            optimized_sql=optimized_sql,
            usage=usage,
            defect_id_history=defect_id_history,
            reoptimization_count=reoptimization_count,
        )

        # Build acceptance criteria
        acceptance_criteria = self._build_acceptance_criteria(sp_name)
        
        # Construct payload using JSON Patch format
        payload = [
            {
                "op": "add",
                "path": "/fields/System.Title",
                "value": title
            },
            {
                # System.Description is the standard field but ADO Bug forms
                # show Microsoft.VSTS.TCM.ReproSteps as the visible "Description".
                # We write to BOTH so the content appears regardless of form config.
                "op": "add",
                "path": "/fields/System.Description",
                "value": description
            },
            {
                "op": "add",
                "path": "/fields/Microsoft.VSTS.TCM.ReproSteps",
                "value": description
            },
            {
                "op": "add",
                "path": "/fields/Microsoft.VSTS.Common.AcceptanceCriteria",
                "value": acceptance_criteria
            },
            {
                "op": "add",
                "path": "/fields/System.AreaPath",
                "value": area_path or self.ado_project
            },
            {
                "op": "add",
                "path": "/fields/System.IterationPath",
                "value": iteration_path or self.ado_project
            }
        ]
        # Append VG-configurable bug fields (Tags, Priority, Severity, etc.) from ADO_BUG_FIELDS
        # NOTE: these are passed as base_payload to _post_with_custom_field_retry so that
        # any Custom.* fields inside ADO_BUG_FIELDS are also auto-stripped on 400.
        payload += self._get_bug_field_ops()

        print(f"   Bug description preview: {description[:120].strip()!r}")

        try:
            print(f"   Sending request to ADO API...")
            print(f"   URL: {api_url}")

            # Use retry helper — Bug uses only ADO_BUG_FIELDS already in payload;
            # never apply ADO_CUSTOM_FIELDS (User Story fields) to a Bug.
            response = self._post_with_custom_field_retry(api_url, payload, apply_custom_fields=False)

            response.raise_for_status()
            work_item = response.json()
            
            return work_item
            
        except requests.exceptions.HTTPError as e:
            import traceback
            error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
            print(f"   ❌ HTTP Error: {e.response.status_code}")
            print(f"   Response: {e.response.text}")
            log_pipeline_error(
                error_type='ADO_API_ERROR',
                error=error_text,
                sp_name=sp_name,
            )
            return None
        except requests.exceptions.RequestException as e:
            import traceback
            error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
            print(f"   ❌ Request Error: {str(e)}")
            if hasattr(e, 'response') and e.response is not None:
                print(f"   Response: {e.response.text}")
            log_pipeline_error(
                error_type='ADO_API_ERROR',
                error=error_text,
                sp_name=sp_name,
            )
            return None
        except Exception as e:
            import traceback
            error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
            print(f"   ❌ Error: {str(e)}")
            log_pipeline_error(
                error_type='ADO_API_ERROR',
                error=error_text,
                sp_name=sp_name,
            )
            return None
    
    def _build_work_item_description(self, sp_name, app_name, occurrence_count,
                                     execution_plan_issues, optimized_sql, usage,
                                     defect_id_history=None, reoptimization_count=0):
        """Build concise HTML description for the Bug work item."""
        generated_on = datetime.now(_IST).strftime('%Y-%m-%d %H:%M:%S')

        # ── Previous optimization history section ────────────────────────────
        # Only shown when this SP has been optimized before (reoptimization_count > 0)
        history_html = ""
        if reoptimization_count > 0 and defect_id_history:
            history_html += (
                f"<p><strong>⚠️ Re-optimization Alert:</strong> This stored procedure has been "
                f"optimized <strong>{reoptimization_count}</strong> time(s) before. "
                f"<p><strong>Previous ADO Bugs (newest → oldest):</strong></p><ul>"
            )
            for entry in defect_id_history.split(','):
                parts = entry.strip().split('|')
                bug_id_h   = parts[0] if len(parts) > 0 else '?'
                closed_dt  = parts[1] if len(parts) > 1 else 'Unknown date'
                status_h   = parts[2] if len(parts) > 2 else 'Unknown status'
                history_html += f"<li>Bug #{bug_id_h} — closed on {closed_dt} with status: {status_h}</li>"
            history_html += "</ul>"

        description = (
            f"<div>"
            f"{history_html}"
            f"<p>Complete AI Optimization Summary report for slow running Stored Procedure: "
            f"<strong>{InputValidator.encode_for_html(sp_name)}</strong> is attached to this work item as a .md file. "
            f"Please refer, validate and proceed for Non Prod and Prod deployments.</p>"
            f"<p><strong>Generated On:</strong> {generated_on}</p>"
            f"</div>"
        )
        return description
    
    @staticmethod
    def _extract_short_description(report_content, max_chars=300):
        """Extract first meaningful paragraph from a LangChain markdown report (up to max_chars chars)."""
        for line in report_content.splitlines():
            stripped = line.strip()
            if stripped and not stripped.startswith('#') and not stripped.startswith('```') \
                    and not stripped.startswith('---') and len(stripped) > 20:
                return stripped[:max_chars]
        return report_content[:max_chars]

    def _extract_section(self, markdown_content, section_header):
        """
        Extract a section from markdown content between section_header and next ## header
        
        Args:
            markdown_content: Full markdown content
            section_header: Section header to find (e.g., "## Executive Summary")
            
        Returns:
            str: Extracted section content
        """
        try:
            import re
            
            # Find the section
            pattern = re.escape(section_header) + r'(.*?)(?=\n##|\Z)'
            match = re.search(pattern, markdown_content, re.DOTALL)
            
            if match:
                return match.group(1).strip()
            else:
                return "N/A"
                
        except Exception as e:
            return f"Error extracting section: {str(e)}"
    
    def _markdown_to_text(self, markdown_text):
        """
        Convert markdown to plain text (remove excessive markdown formatting for HTML display)
        
        Args:
            markdown_text: Markdown formatted text
            
        Returns:
            str: Cleaned text suitable for HTML <pre> tags
        """
        if not markdown_text or markdown_text == "N/A":
            return "N/A"
        
        # Remove code block markers but keep content
        text = markdown_text.replace('```sql', '').replace('```', '')
        
        # Keep the text as-is for <pre> tag (preserves formatting)
        return text.strip()
    
    def _build_acceptance_criteria(self, sp_name):
        """
        Build acceptance criteria for the work item
        """
        criteria = f"""<div>
<h3>Acceptance Criteria for {sp_name} Optimization</h3>
<ol>
<li><strong>Testing:</strong>
   <ul>
   <li>Optimized SQL tested in DEV/QA environment</li>
   <li>All functional test cases pass</li>
   <li>No regression in application functionality</li>
   </ul>
</li>
<li><strong>Performance Validation:</strong>
   <ul>
   <li>Execution time reduced compared to original</li>
   <li>CPU usage reduced or maintained</li>
   <li>I/O operations reduced or optimized</li>
   <li>Execution plan shows improvements (index seeks vs scans, etc.)</li>
   </ul>
</li>
<li><strong>Code Review:</strong>
   <ul>
   <li>Optimized SQL reviewed by DBA/Senior Developer</li>
   <li>Changes approved by technical lead</li>
   </ul>
</li>
<li><strong>Deployment:</strong>
   <ul>
   <li>Deployed to production with proper change management</li>
   <li>Post-deployment validation completed</li>
   <li>Performance metrics monitored for 24-48 hours</li>
   </ul>
</li>
<li><strong>Documentation:</strong>
   <ul>
   <li>Performance improvement metrics documented</li>
   <li>Any deviations from AI recommendations documented with reasoning</li>
   </ul>
</li>
</ol>
</div>"""
        
        return criteria
    
    def _attach_file_to_workitem(self, work_item_id, file_path):
        """
        Attach optimized SQL file to the work item
        
        Args:
            work_item_id: ID of the work item
            file_path: Path to the file to attach
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # Step 1: Upload file to ADO attachment store
            print(f"   Uploading file: {file_path}")
            
            upload_url = f"{self.ado_org_url}/_apis/wit/attachments?fileName={os.path.basename(file_path)}&api-version={self.api_version}"
            
            # Read file content
            with open(file_path, 'rb') as f:
                file_content = f.read()
            
            # Upload with octet-stream content type
            upload_headers = {
                "Content-Type": "application/octet-stream",
                "Authorization": self.headers["Authorization"]
            }
            
            self._rate_limiter.check_request()
            upload_response = self._session.post(
                upload_url,
                headers=upload_headers,
                data=file_content,
                timeout=30
            )
            
            upload_response.raise_for_status()
            attachment_ref = upload_response.json()
            
            print(f"   File uploaded, URL: {attachment_ref['url']}")
            
            # Step 2: Link the attachment to the work item
            print(f"   Linking attachment to work item {work_item_id}...")
            
            link_url = f"{self.ado_org_url}/{self.ado_project}/_apis/wit/workitems/{work_item_id}?api-version={self.api_version}"
            
            link_payload = [
                {
                    "op": "add",
                    "path": "/relations/-",
                    "value": {
                        "rel": "AttachedFile",
                        "url": attachment_ref['url'],
                        "attributes": {
                            "comment": "AI-Optimized SQL file generated by SQL Optimizer"
                        }
                    }
                }
            ]
            
            self._rate_limiter.check_request()
            link_response = self._session.patch(
                link_url,
                headers=self.headers,
                json=link_payload,
                timeout=30
            )
            
            link_response.raise_for_status()
            
            return True
            
        except requests.exceptions.HTTPError as e:
            print(f"   ❌ HTTP Error attaching file: {e.response.status_code}")
            print(f"   Response: {e.response.text}")
            return False
        except requests.exceptions.RequestException as e:
            print(f"   ❌ Request Error attaching file: {str(e)}")
            if hasattr(e, 'response') and e.response is not None:
                print(f"   Response: {e.response.text}")
            return False
        except Exception as e:
            print(f"   ❌ Error attaching file: {str(e)}")
            return False
    
    def _update_defect_tracker(self, sp_id, work_item_id, work_item_status):
        """
        Update ado_defect_tracker table with work item details.

        Before overwriting defect_id, the previous value is appended to
        defect_id_history (comma-separated) so all historical Bug IDs are
        preserved across re-optimization cycles.

        Sets defect_id, defect_id_history, defect_status, clears
        pipeline_error, and updates last_updated.
        """
        try:
            from sqlalchemy import text
            with get_session() as session:
                # ── Step 1: read current defect_id, history, reopt count ──
                row = session.execute(
                    text(
                        f'SELECT defect_id, defect_id_history, reoptimization_count, defect_status '
                        f'FROM "{DB_SCHEMA}".ado_defect_tracker '
                        f'WHERE sp_id = :sp_id'
                    ),
                    {"sp_id": sp_id},
                ).fetchone()

                new_history = None
                current_reopt_count = 0
                if row:
                    old_defect_id    = row[0]
                    existing_history = row[1]
                    current_reopt_count = row[2] or 0
                    old_status       = row[3] or 'Unknown'
                    new_bug_str = str(work_item_id)
                    if old_defect_id and old_defect_id != new_bug_str:
                        history_list = [x.strip() for x in existing_history.split(',') if x.strip()] \
                            if existing_history else []
                        # Build snapshot: "bug_id|closed_date|status" — prepend (newest-to-oldest)
                        closed_date = datetime.now(_IST).strftime('%Y-%m-%d')
                        snapshot = f"{old_defect_id}|{closed_date}|{old_status}"
                        existing_ids = {e.split('|')[0] for e in history_list}
                        if old_defect_id not in existing_ids:
                            history_list.insert(0, snapshot)
                        new_history = ','.join(history_list)
                    else:
                        new_history = existing_history

                # ── Step 2: write new defect_id, history, incremented count ─
                session.execute(
                    text(
                        f'UPDATE "{DB_SCHEMA}".ado_defect_tracker '
                        'SET defect_id = :defect_id, '
                        '    defect_id_history = CASE '
                        '        WHEN :new_history IS NOT NULL THEN :new_history '
                        '        ELSE defect_id_history END, '
                        '    reoptimization_count = :reopt_count, '
                        '    defect_status = :defect_status, '
                        '    last_updated = :last_updated '
                        'WHERE sp_id = :sp_id'
                    ),
                    {
                        "sp_id": sp_id,
                        "defect_id": str(work_item_id),
                        "new_history": new_history,
                        "reopt_count": current_reopt_count + 1,
                        "defect_status": work_item_status,
                        "last_updated": datetime.now(_IST).strftime('%Y-%m-%d %H:%M:%S'),
                    },
                )
            print(f"   Updated defect tracker record for sp_id={sp_id}")
            return True

        except Exception as e:
            import traceback
            error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
            print(f"   ❌ Error updating defect tracker: {str(e)}")
            log_pipeline_error(
                error_type='DB_ERROR',
                error=error_text,
                sp_id=sp_id,
                sp_name=f'(ADO: update_defect_tracker sp_id={sp_id})',
            )
            return False
    
    def get_work_item_status(self, work_item_id):
        """
        Get current status of a work item
        
        Args:
            work_item_id: ID of the work item
            
        Returns:
            dict: Work item details including status
        """
        try:
            api_url = f"{self.ado_org_url}/{self.ado_project}/_apis/wit/workitems/{work_item_id}?api-version={self.api_version}"
            
            self._rate_limiter.check_request()
            response = self._session.get(
                api_url,
                headers=self.headers,
                timeout=30
            )
            
            response.raise_for_status()
            work_item = response.json()
            
            return {
                'id': work_item['id'],
                'status': work_item['fields'].get('System.State', 'Unknown'),
                'title': work_item['fields'].get('System.Title', ''),
                'url': work_item.get('_links', {}).get('html', {}).get('href', '')
            }
            
        except requests.exceptions.RequestException as e:
            import traceback
            error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
            print(f"❌ Request Error getting work item status: {str(e)}")
            if hasattr(e, 'response') and e.response is not None:
                print(f"Response: {e.response.text}")
            log_pipeline_error(
                error_type='ADO_API_ERROR',
                error=error_text,
                sp_name=f'(ADO: get_work_item_status work_item#{work_item_id})',
            )
            return None
        except Exception as e:
            import traceback
            error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
            print(f"❌ Error getting work item status: {str(e)}")
            log_pipeline_error(
                error_type='ADO_API_ERROR',
                error=error_text,
                sp_name=f'(ADO: get_work_item_status work_item#{work_item_id})',
            )
            return None


if __name__ == "__main__":
    # Example usage
    print("ADO Work Item Creator for SQL Optimization")
    print("="*100)
    
    # Configuration
    ado_config = {
        'ado_org_url': 'https://dev.azure.com/your-organization',
        'ado_project': 'YourProjectName',
        'ado_pat_token': 'your_personal_access_token_here'
    }
    
    # Example: Create a bug work item
    creator = ADOWorkItemCreator(
        ado_org_url=ado_config['ado_org_url'],
        ado_project=ado_config['ado_project'],
        ado_pat_token=ado_config['ado_pat_token']
    )
    
    # Sample optimization details
    optimization_details = {
        'optimized_sql': 'CREATE PROCEDURE ...',
        'usage': {
            'prompt_tokens': 5000,
            'completion_tokens': 1500,
            'total_tokens': 6500
        },
        'occurrence_count': 5,
        'execution_plan_issues': 'HIGH: Table scan on MC_Table\nMEDIUM: Missing index...'
    }
    
    # Create work item
    result = creator.create_bug_workitem(
        sp_id=1,
        sp_name='MC_SP_GETCONFERENCEBASEDONPARTYANDDATETIME',
        app_name='Meeting Concierge',
        optimization_details=optimization_details,
        optimized_file_path='optimized_queries/MC_SP_GETCONFERENCEBASEDONPARTYANDDATETIME_optimized.sql'
    )
    
    if result and result['success']:
        print(f"\n✅ Successfully created work item {result['work_item_id']}")
        print(f"   URL: {result['work_item_url']}")
    else:
        print(f"\n❌ Failed to create work item")
