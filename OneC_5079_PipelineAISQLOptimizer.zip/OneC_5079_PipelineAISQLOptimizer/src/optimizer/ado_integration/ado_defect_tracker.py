﻿"""
ADO Defect Tracker — Scheduled Component

Runs BEFORE the main optimization pipeline.
Polls all ADO Bug IDs in ado_defect_tracker, syncs their latest state,
and detects keyword patterns in comments to update local defect_status.

Keyword rules (case-insensitive):
  "SPs default functionality"         -> defect_status = Exempt  (permanent, never re-process)
  "SPs Business Logic changed"        -> defect_status = Rejected (allow re-process next cycle)
  "Snoozing from DD:MM:YYYY to DD:MM:YYYY" -> defect_status = Deferred, parse snooze dates

ADO state sync:
  ADO state "Active"      -> defect_status = Active
  ADO state "In Progress" -> defect_status = InProgress
  ADO state "Resolved"    -> defect_status = Closed
  ADO state "Closed"      -> defect_status = Closed  (unless a keyword overrides it)

After snooze end date passes:
  defect_status = Deferred + snooze_end_date < today -> reset defect_status = NULL
  (this re-enters the SP into the optimization queue next pipeline run)
"""

import base64
import os
import re
import sys
import warnings
from datetime import datetime
from zoneinfo import ZoneInfo

import requests

_IST = ZoneInfo("Asia/Kolkata")

try:
    from ..models import get_session, DB_SCHEMA
    from ..config import get_config
    from ..utils.audit_logger import log_pipeline_error
    from ..utils.http_session import build_http_session, RateLimiter
except ImportError:
    _project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    if _project_root not in sys.path:
        sys.path.insert(0, _project_root)
    os.chdir(_project_root)
    from optimizer.models import get_session
    from optimizer.config import get_config
    from optimizer.utils.audit_logger import log_pipeline_error
    from optimizer.utils.http_session import build_http_session, RateLimiter

# Keyword patterns (case-insensitive)
KEYWORD_EXEMPT = "SPs default functionality"
KEYWORD_REJECTED = "SPs Business Logic changed"
SNOOZE_PATTERN = re.compile(
    r"Snoozing\s+from\s+(\d{2}[:/]\d{2}[:/]\d{4})\s+to\s+(\d{2}[:/]\d{2}[:/]\d{4})",
    re.IGNORECASE
)

# ADO state -> local defect_status mapping
ADO_STATE_MAP = {
    "active": "Active",
    "new": "Active",
    "proposed": "Active",
    "committed": "Active",
    "in progress": "InProgress",
    "resolved": "Closed",
    "closed": "Closed",
    "done": "Closed",
}


class ADODefectTrackerService:
    """
    Scheduled service that syncs ADO Bug states back to the local defect tracker.
    Run this on its own schedule (e.g. every 6 hours) before the main pipeline.
    """

    def __init__(self, ado_org_url: str, ado_project: str, ado_pat_token: str, verify_ssl: bool = True,
                 ado_base_url: str = 'https://devops.cognizant.com'):
        self.ado_org_url = ado_org_url.rstrip('/')
        self.ado_project = ado_project
        self.ado_base_url = ado_base_url.rstrip('/')
        # Always read ENV_REGION directly from the VG/env var — never rely on a caller passing it.
        self.env_region = os.getenv('ENV_REGION', 'DEV').upper()
        self.api_version = os.getenv('ADO_API_VERSION', '7.0')
        # Allow override via env var; constructor param takes precedence when caller passes it explicitly.
        _env_verify = os.getenv('ADO_SSL_VERIFY', 'true').lower() not in ('false', '0', 'no')
        self.verify_ssl = verify_ssl and _env_verify

        if not self.verify_ssl:
            warnings.filterwarnings('ignore', message='.*InsecureRequest.*')
            requests.packages.urllib3.disable_warnings(
                requests.packages.urllib3.exceptions.InsecureRequestWarning
            )

        auth_string = f":{ado_pat_token}"
        encoded_auth = base64.b64encode(auth_string.encode('utf-8')).decode('utf-8')
        self.headers = {
            "Content-Type": "application/json",
            "Authorization": f"Basic {encoded_auth}"
        }
        # Clear raw PAT from memory — encoded header is all we need
        del auth_string
        ado_pat_token = None
        self._session = build_http_session(verify_ssl=self.verify_ssl)
        self._rate_limiter = RateLimiter()

    def sync_all_defects(self):
        """
        Main entry point. Processes every row in ado_defect_tracker that has a defect_id.
        Steps per row:
          1. Skip if already Exempt (permanent — no need to re-check ADO)
          2. Fetch ADO bug state + comments
          3. Scan comments for keyword patterns
          4. Update defect_status (keyword rules override ADO state sync)
          5. Handle expired snooze dates
        """
        print("\n" + "="*100)
        print("ADO DEFECT TRACKER — SYNCING ALL DEFECT STATUSES")
        print("="*100)

        today = datetime.now(_IST).strftime('%Y-%m-%d')

        # Load rows directly from ado_defect_tracker table, JOINing app_config
        # to get per-app ado_collection + ado_project (same source as bug creation).
        from sqlalchemy import text
        with get_session() as session:
            result = session.execute(
                text(
                    f'SELECT dt.sp_id, dt.app_name, dt.sp_name, dt.defect_id, dt.defect_status, dt.snooze_end_date, '
                    f'       ac.ado_collection, ac.ado_project AS app_ado_project '
                    f'FROM "{DB_SCHEMA}".ado_defect_tracker dt '
                    f'LEFT JOIN "{DB_SCHEMA}".app_config ac ON ac.app_name = dt.app_name '
                    f'WHERE dt.defect_id IS NOT NULL'
                )
            )
            rows = result.fetchall()

        if not rows:
            print("   No defect records with ADO Bug IDs found.")
            return

        print(f"   Processing {len(rows)} defect record(s)...\n")

        synced = skipped = errors = 0

        for row in rows:
            sp_id, app_name, sp_name, defect_id, defect_status, snooze_end_date, ado_collection, app_ado_project = row
            sp_label = f"{app_name} / {sp_name} (Bug #{defect_id})"

            # Build per-app ADO URL — same logic as decision_gate.py PROD path.
            # Uses ADO_BASE_URL + app_config.ado_collection/ado_project from DB
            # so each bug is fetched from the correct ADO server/project.
            if self.env_region == 'PROD' and ado_collection and app_ado_project:
                from urllib.parse import quote
                effective_org_url = f"{self.ado_base_url}/{quote(ado_collection, safe='')}"
                effective_project = app_ado_project
            else:
                # DEV/SIT or app_config not populated — fall back to VG defaults
                effective_org_url = self.ado_org_url
                effective_project = self.ado_project

            # Exempt SPs never need re-checking
            if defect_status == 'Exempt':
                print(f"   SKIP (Exempt): {sp_label}")
                skipped += 1
                continue

            # Check expired snooze — reset before ADO sync
            if defect_status == 'Deferred' and snooze_end_date:
                if today > snooze_end_date:
                    self._reset_snooze(sp_id, sp_label)
                    synced += 1
                    continue

            try:
                ado_state, comments = self._fetch_bug_state_and_comments(
                    defect_id, org_url=effective_org_url, project=effective_project
                )
                if ado_state is None:
                    print(f"   WARN: Could not fetch ADO data for Bug #{defect_id} — skipping")
                    errors += 1
                    continue

                self._apply_updates_by_id(sp_id, ado_state, comments, today)
                synced += 1
                print(f"   SYNCED: {sp_label} — ADO state: {ado_state}")

            except Exception as e:
                import traceback
                error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
                print(f"   ERROR: {sp_label} — {e}")
                log_pipeline_error(
                    error_type='ADO_API_ERROR',
                    error=error_text,
                    sp_id=sp_id,
                    sp_name=sp_name,
                    app_name=app_name,
                )
                errors += 1

        print(f"\n{'='*100}")
        print(f"ADO DEFECT TRACKER SYNC COMPLETE")
        print(f"   Synced: {synced} | Skipped (Exempt): {skipped} | Errors: {errors}")
        print("="*100)

    def _fetch_bug_state_and_comments(self, defect_id: str, org_url: str = None, project: str = None):
        """Fetch ADO bug state and all comment texts. Returns (state_str, [comment_text])."""
        # Use per-app URL/project passed from sync_all_defects (built from app_config DB values),
        # falling back to instance defaults only if not provided.
        org_url = (org_url or self.ado_org_url).rstrip('/')
        project = project or self.ado_project

        # Fetch work item fields
        wi_url = (
            f"{org_url}/{project}/_apis/wit/workitems/{defect_id}"
            f"?api-version={self.api_version}"
        )
        self._rate_limiter.check_request()
        wi_resp = self._session.get(wi_url, headers=self.headers, timeout=30)
        wi_resp.raise_for_status()
        wi_data = wi_resp.json()
        ado_state = wi_data.get('fields', {}).get('System.State', '').strip()

        # Fetch comments
        comments_url = (
            f"{org_url}/{project}/_apis/wit/workitems/{defect_id}"
            f"/comments?api-version={self.api_version}-preview.3"
        )
        self._rate_limiter.check_request()
        comments_resp = self._session.get(comments_url, headers=self.headers, timeout=30)
        comment_texts = []
        if comments_resp.status_code == 200:
            for c in comments_resp.json().get('comments', []):
                text = c.get('text', '') or ''
                # Strip HTML tags for keyword matching
                clean = re.sub(r'<[^>]+>', ' ', text).strip()
                if clean:
                    comment_texts.append(clean)

        return ado_state, comment_texts

    def _apply_updates_by_id(self, sp_id: int, ado_state: str, comments: list, today: str):
        """Determine the new defect_status and persist it using sp_id."""
        new_status = None
        new_remarks = None
        new_snooze_start = None
        new_snooze_end = None

        all_comments_text = " ".join(comments)

        # Always evaluate keywords against the LATEST comment only.
        # NOTE: ADO /comments API returns comments newest-first, so index [0] is
        # the most recent comment — NOT [-1].
        latest_comment = comments[0] if comments else ""

        # Keyword check 1: Exempt (highest priority — check first)
        if KEYWORD_EXEMPT.lower() in latest_comment.lower():
            new_status = 'Exempt'
            new_remarks = latest_comment[:500]

        # Keyword check 2: Rejected / Business Logic
        elif KEYWORD_REJECTED.lower() in latest_comment.lower():
            new_status = 'Rejected'
            new_remarks = latest_comment[:500]

        # Keyword check 3: Snooze
        else:
            snooze_match = SNOOZE_PATTERN.search(latest_comment)

            if snooze_match:
                raw_start = snooze_match.group(1).replace('/', ':')
                raw_end = snooze_match.group(2).replace('/', ':')
                try:
                    snooze_start_dt = datetime.strptime(raw_start, '%d:%m:%Y')
                    snooze_end_dt = datetime.strptime(raw_end, '%d:%m:%Y')
                    new_snooze_start = snooze_start_dt.strftime('%Y-%m-%d')
                    new_snooze_end = snooze_end_dt.strftime('%Y-%m-%d')

                    if today <= new_snooze_end:
                        new_status = 'Deferred'
                        new_remarks = snooze_match.group(0)
                    else:
                        # Snooze already expired — re-enter queue
                        new_status = None
                        new_snooze_start = None
                        new_snooze_end = None
                except ValueError:
                    pass

        # If no keyword matched, sync ADO state directly
        # We need to get current defect_status for fallback
        from sqlalchemy import text
        with get_session() as session:
            result = session.execute(
                text(
                    f'SELECT defect_status FROM "{DB_SCHEMA}".ado_defect_tracker '
                    f'WHERE sp_id = :sp_id'
                ),
                {"sp_id": sp_id},
            )
            row = result.fetchone()
            if not row:
                return

            current_status = row[0]

            if new_status is None:
                new_status = ADO_STATE_MAP.get(ado_state.lower(), current_status)

            session.execute(
                text(
                    f'UPDATE "{DB_SCHEMA}".ado_defect_tracker '
                    '    SET defect_status = :defect_status, '
                    '    remarks = CASE WHEN :remarks IS NOT NULL THEN :remarks ELSE remarks END, '
                    '    snooze_start_date = CASE WHEN :snooze_start IS NOT NULL THEN :snooze_start ELSE snooze_start_date END, '
                    '    snooze_end_date = CASE WHEN :snooze_end IS NOT NULL THEN :snooze_end ELSE snooze_end_date END, '
                    '    last_updated = :last_updated '
                    'WHERE sp_id = :sp_id'
                ),
                {
                    "sp_id": sp_id,
                    "defect_status": new_status,
                    "remarks": new_remarks,
                    "snooze_start": new_snooze_start,
                    "snooze_end": new_snooze_end,
                    "last_updated": datetime.now(_IST).strftime('%Y-%m-%d %H:%M:%S'),
                },
            )

    def _reset_snooze(self, sp_id: int, sp_label: str):
        """Snooze expired — reset status to NULL so SP re-enters the optimization queue."""
        print(f"   SNOOZE EXPIRED: {sp_label} — resetting to NULL (re-enters queue)")
        from sqlalchemy import text
        with get_session() as session:
            session.execute(
                text(
                    f'UPDATE "{DB_SCHEMA}".ado_defect_tracker '
                    '    SET defect_status = NULL, '
                    '    snooze_start_date = NULL, '
                    '    snooze_end_date = NULL, '
                    '    last_updated = :last_updated '
                    'WHERE sp_id = :sp_id'
                ),
                {
                    "sp_id": sp_id,
                    "last_updated": datetime.now(_IST).strftime('%Y-%m-%d %H:%M:%S'),
                },
            )

    def _find_matching_comment(self, comments: list, keyword: str) -> str:
        """Return the first comment containing the keyword (case-insensitive)."""
        for comment in comments:
            if keyword.lower() in comment.lower():
                return comment[:500]
        return keyword


def main():
    """Entry point for the ADO Defect Tracker scheduled component."""
    config = get_config()   # Load .env into os.environ FIRST — SSL env vars are read at import time
                             # by other modules; this is safe here because ADODefectTrackerService
                             # reads ADO_SSL_VERIFY inside __init__, not at module level.

    print("\n" + "="*100)
    print("ADO DEFECT TRACKER — SCHEDULED SYNC")
    print("="*100)

    if not config.is_ado_configured():
        print("ADO credentials not configured. Check .env file.")
        return

    service = ADODefectTrackerService(
        ado_org_url=config.ADO_ORG_URL,
        ado_project=config.ADO_PROJECT,
        ado_pat_token=config.ADO_PAT_TOKEN,
        ado_base_url=getattr(config, 'ADO_BASE_URL', 'https://devops.cognizant.com'),
    )
    service.sync_all_defects()


if __name__ == "__main__":
    main()
